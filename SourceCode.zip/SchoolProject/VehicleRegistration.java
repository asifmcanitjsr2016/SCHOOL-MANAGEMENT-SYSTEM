/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;

/**
 *
 * @author ASIF
 */
public class VehicleRegistration extends javax.swing.JFrame {

    /**
     * Creates new form RegistrationDetails
     */
    private int tax=0,fit=0,inc=0;
    private boolean flag1=false,flagfit=false,flaginc=false;
    private boolean flagdate=false;
    private String nextdate,nextdate2,nextdate3;
    private ResultSet rs;
    private Statement stmt;
    private java.sql.Connection con;
    public VehicleRegistration() {
        initComponents();
        head1.setText(AdmissionOpen.arg);
        head2.setText(AdmissionOpen.arg1);
        boolean flag=false,flag0=false,flag2=false;
        String message="";
        String sysdate = NewJPanel.lbldate.getText().substring(5,15);
        try{
        con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
        }
        catch(SQLException xe){
            JOptionPane.showMessageDialog(rootPane, xe);
        }
        try{
            String regno;
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
               int sub=0,sub1=0,sub12=0;
                try{
                String str1 = "SELECT NEXTPAY_DATE FROM VEHICLE_TAX WHERE REG_NO='"+regno+"' ORDER BY NEXTPAY_DATE ASC";
                rs = stmt.executeQuery(str1);
                rs.last();
                String date = String.valueOf(rs.getDate(1));//"1992-04-03"
                String st1 = date.substring(0, 4);
                String st2 = date.substring(5, 7);
                String st3 = date.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                //Date: 01-02-2015                
                String returndate = dateSubstract(st4,sysdate);
                sub=Integer.parseInt(returndate.substring(0,2));
                String submy=returndate.substring(3, 10);
                String sysmy=sysdate.substring(3, 10).replace('/', '-');
                if(((sub<=5&&sub>0)&&flagdate==true)&&submy.equals(sysmy)){
                    flag=true;
                 }
                }
                catch(SQLException ex){
                flag=false;
            }
                try{
                String str2 = "SELECT NEXTPAY_DATE FROM VEHICLE_FITNESS WHERE REG_NO='"+regno+"' ORDER BY NEXTPAY_DATE ASC";
                rs = stmt.executeQuery(str2);
                rs.last();
                String date1 = String.valueOf(rs.getDate(1));//"1992-04-03"
                String st11 = date1.substring(0, 4);
                String st12 = date1.substring(5, 7);
                String st13 = date1.substring(8, 10);
                String st14 = st13.concat("-").concat(st12).concat("-").concat(st11);
                //Date: 01-02-2015
                String returndate1 = dateSubstract(st14,sysdate);
                sub1=Integer.parseInt(returndate1.substring(0,2));
                String submy1=returndate1.substring(3, 10);
                String sysmy1=sysdate.substring(3, 10).replace('/', '-');
                if(((sub1<=5&&sub1>0)&&flagdate==true)&&submy1.equals(sysmy1)){
                    flag0=true;
                }
                }
                catch(SQLException ex){
                flag0=false;
            }
                try{
                String str3 = "SELECT NEXTPAY_DATE FROM VEHICLE_INSURANCE WHERE REG_NO='"+regno+"' ORDER BY NEXTPAY_DATE ASC";
                rs = stmt.executeQuery(str3);
                rs.last();
                String date21 = String.valueOf(rs.getDate(1));//"1992-04-03"
                String st21 = date21.substring(0, 4);
                String st22 = date21.substring(5, 7);
                String st23 = date21.substring(8, 10);
                String st24 = st23.concat("-").concat(st22).concat("-").concat(st21);
                //Date: 01-02-2015
                String returndate12 = dateSubstract(st24,sysdate);
                sub12=Integer.parseInt(returndate12.substring(0,2));
                String submy12=returndate12.substring(3, 10);
                String sysmy12=sysdate.substring(3, 10).replace('/', '-');
                if(((sub12<=5&&sub12>0)&&flagdate==true)&&submy12.equals(sysmy12)){
                    flag2=true;
                }
                }
                catch(SQLException ex){
                flag2=false;
            }
                if(flag==true){
                   message="Tax Payment Within "+String.valueOf(sub)+" Days, Vehicle Reg No. "+regno+"\n";
                }
                if(flag0){
                  message=message+"Fitness Payment Within "+String.valueOf(sub1)+" Days, Vehicle Reg No. "+regno+"\n";  
                }
                if(flag2==true){
                    message=message+"Insurance Payment Within "+String.valueOf(sub12)+" Days, Vehicle Reg No. "+regno;
                }
                if(flag==true||flag0==true||flag2==true){
                JOptionPane.showMessageDialog(rootPane, message);
                }
                message="";
                flag=false;
                flag0=false;
                flag2=false;
            }
            }
            catch(SQLException ex){
                
            }
        txtbrname1.setEditable(false);
        txtcont1.setEditable(false);
        txtadd1.setEditable(false);
        txtbrname2.setEditable(false);
        txtcont2.setEditable(false);
        txtadd2.setEditable(false);    
        txtbrname3.setEditable(false);
        txtcont3.setEditable(false);
        txtadd3.setEditable(false);    
        jLayeredPane1.setVisible(false);
        jLayeredPane2.setVisible(false);
        jLayeredPane3.setVisible(false);
        lblvtd3.setOpaque(true);
        lblvtd1.setOpaque(true);
        lblvtd2.setOpaque(true);
        jLayeredPane1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK,1,true), "Vehicle Tax Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28)));
        jLayeredPane2.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK,1,true), "Vehicle Fitness Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28)));
        jLayeredPane3.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK,1,true), "Vehicle Insurance Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28)));
    }   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        lblvtd3 = new javax.swing.JLabel();
        lblvtd1 = new javax.swing.JLabel();
        lblvtd2 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel28 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        cmbrtp1 = new javax.swing.JComboBox();
        jLabel50 = new javax.swing.JLabel();
        cmbyy1 = new javax.swing.JComboBox();
        txttax = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        cmbmm1 = new javax.swing.JComboBox();
        txtbrname1 = new javax.swing.JTextField();
        txtnpdate1 = new javax.swing.JTextField();
        cmbdd1 = new javax.swing.JComboBox();
        jLabel36 = new javax.swing.JLabel();
        txtnpamt1 = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        cmbtpb1 = new javax.swing.JComboBox();
        jLabel55 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txtcont1 = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        txtadd1 = new javax.swing.JTextField();
        txtpaydate1 = new javax.swing.JTextField();
        btncancle1 = new javax.swing.JButton();
        btnsave1 = new javax.swing.JButton();
        btnhome1 = new javax.swing.JButton();
        jLabel57 = new javax.swing.JLabel();
        txttaxamt = new javax.swing.JTextField();
        jLabel58 = new javax.swing.JLabel();
        txtregno = new javax.swing.JTextField();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jLabel29 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        cmbrtp2 = new javax.swing.JComboBox();
        jLabel60 = new javax.swing.JLabel();
        cmbyy2 = new javax.swing.JComboBox();
        txtfitoff = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        cmbmm2 = new javax.swing.JComboBox();
        txtbrname2 = new javax.swing.JTextField();
        txtnpdate2 = new javax.swing.JTextField();
        cmbdd2 = new javax.swing.JComboBox();
        jLabel63 = new javax.swing.JLabel();
        txtnpamt2 = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        cmbtpb2 = new javax.swing.JComboBox();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        txtcont2 = new javax.swing.JTextField();
        jLabel67 = new javax.swing.JLabel();
        txtadd2 = new javax.swing.JTextField();
        txtpaydate2 = new javax.swing.JTextField();
        btncancle2 = new javax.swing.JButton();
        btnsave2 = new javax.swing.JButton();
        btnhome2 = new javax.swing.JButton();
        jLabel68 = new javax.swing.JLabel();
        txtfitamt = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        txtregno2 = new javax.swing.JTextField();
        jLayeredPane3 = new javax.swing.JLayeredPane();
        jLabel27 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        cmbrtp3 = new javax.swing.JComboBox();
        jLabel46 = new javax.swing.JLabel();
        cmbyy3 = new javax.swing.JComboBox();
        txtincoff = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        cmbmm3 = new javax.swing.JComboBox();
        txtbrname3 = new javax.swing.JTextField();
        txtnpdate3 = new javax.swing.JTextField();
        cmbdd3 = new javax.swing.JComboBox();
        jLabel33 = new javax.swing.JLabel();
        txtnpamt3 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        cmbtpb3 = new javax.swing.JComboBox();
        jLabel47 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        txtcont3 = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        txtadd3 = new javax.swing.JTextField();
        txtpaydate3 = new javax.swing.JTextField();
        btncancle3 = new javax.swing.JButton();
        btnsave3 = new javax.swing.JButton();
        btnhome3 = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        txtincamt = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        txtregno3 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        head1 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        head2 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(216, 197, 236));
        jPanel1.setPreferredSize(new java.awt.Dimension(1345, 907));
        jPanel1.setLayout(null);

        jLabel5.setBackground(new java.awt.Color(204, 51, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setOpaque(true);
        jPanel1.add(jLabel5);
        jLabel5.setBounds(0, 890, 1370, 37);

        lblvtd3.setBackground(new java.awt.Color(216, 197, 236));
        lblvtd3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblvtd3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblvtd3.setText("Vehicle Insurance Details");
        lblvtd3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblvtd3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblvtd3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblvtd3MouseClicked(evt);
            }
        });
        jPanel1.add(lblvtd3);
        lblvtd3.setBounds(780, 124, 210, 40);

        lblvtd1.setBackground(new java.awt.Color(216, 197, 236));
        lblvtd1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblvtd1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblvtd1.setText("Vehicle Tax Details");
        lblvtd1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblvtd1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblvtd1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblvtd1MouseClicked(evt);
            }
        });
        jPanel1.add(lblvtd1);
        lblvtd1.setBounds(340, 124, 170, 40);

        lblvtd2.setBackground(new java.awt.Color(216, 197, 236));
        lblvtd2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblvtd2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblvtd2.setText("Vehicle Fitness Details");
        lblvtd2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblvtd2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblvtd2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblvtd2MouseClicked(evt);
            }
        });
        jPanel1.add(lblvtd2);
        lblvtd2.setBounds(550, 124, 190, 40);

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vehicle Tax Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28))); // NOI18N

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel28.setText("Broker/Agent Name:");
        jLabel28.setBounds(60, 420, 170, 20);
        jLayeredPane1.add(jLabel28, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel35.setText("Next Due Date:");
        jLabel35.setBounds(60, 340, 118, 20);
        jLayeredPane1.add(jLabel35, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbrtp1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbrtp1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Monthly", "Quarterly", "Half Yearly", "Yearly", "LifeTime" }));
        cmbrtp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbrtp1ActionPerformed(evt);
            }
        });
        cmbrtp1.setBounds(250, 260, 100, 23);
        jLayeredPane1.add(cmbrtp1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel50.setText("Tax Period:");
        jLabel50.setBounds(60, 260, 90, 20);
        jLayeredPane1.add(jLabel50, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbyy1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbyy1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YY", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" }));
        cmbyy1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbyy1ActionPerformed(evt);
            }
        });
        cmbyy1.setBounds(400, 140, 64, 23);
        jLayeredPane1.add(cmbyy1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txttax.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txttax.setToolTipText("Use Only Character(a to z,A to Z)");
        txttax.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txttaxFocusLost(evt);
            }
        });
        txttax.setBounds(250, 100, 200, 25);
        jLayeredPane1.add(txttax, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel51.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel51.setText("Tax Amount:");
        jLabel51.setBounds(60, 220, 110, 20);
        jLayeredPane1.add(jLabel51, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel52.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel52.setText("Next Payable Amount:");
        jLabel52.setBounds(60, 300, 180, 20);
        jLayeredPane1.add(jLabel52, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbmm1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbmm1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));
        cmbmm1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbmm1ActionPerformed(evt);
            }
        });
        cmbmm1.setBounds(320, 140, 56, 23);
        jLayeredPane1.add(cmbmm1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtbrname1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtbrname1.setToolTipText("Use Only Character(a to z,A to Z)");
        txtbrname1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtbrname1FocusLost(evt);
            }
        });
        txtbrname1.setBounds(250, 420, 187, 25);
        jLayeredPane1.add(txtbrname1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpdate1.setEditable(false);
        txtnpdate1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpdate1.setToolTipText("");
        txtnpdate1.setBounds(250, 340, 120, 25);
        jLayeredPane1.add(txtnpdate1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbdd1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbdd1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cmbdd1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbdd1ActionPerformed(evt);
            }
        });
        cmbdd1.setBounds(250, 140, 48, 23);
        jLayeredPane1.add(cmbdd1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel36.setText("Road Tax Paid Upto:");
        jLabel36.setBounds(60, 180, 170, 20);
        jLayeredPane1.add(jLabel36, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpamt1.setEditable(false);
        txtnpamt1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpamt1.setToolTipText("");
        txtnpamt1.setBounds(250, 300, 120, 25);
        jLayeredPane1.add(txtnpamt1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel53.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel53.setText("Tax Office:");
        jLabel53.setBounds(60, 100, 90, 20);
        jLayeredPane1.add(jLabel53, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbtpb1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbtpb1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Broker", "Agent", "Self" }));
        cmbtpb1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtpb1ActionPerformed(evt);
            }
        });
        cmbtpb1.setBounds(250, 380, 100, 23);
        jLayeredPane1.add(cmbtpb1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel55.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel55.setText("Tax Payment By:");
        jLabel55.setBounds(60, 380, 140, 20);
        jLayeredPane1.add(jLabel55, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel37.setText("Contact No.");
        jLabel37.setBounds(60, 460, 100, 20);
        jLayeredPane1.add(jLabel37, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtcont1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcont1.setToolTipText("Use Only Digit(0-9)");
        txtcont1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcont1FocusLost(evt);
            }
        });
        txtcont1.setBounds(250, 460, 187, 25);
        jLayeredPane1.add(txtcont1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel56.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel56.setText("Address:");
        jLabel56.setBounds(60, 500, 70, 20);
        jLayeredPane1.add(jLabel56, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtadd1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtadd1.setToolTipText("");
        txtadd1.setBounds(250, 500, 187, 25);
        jLayeredPane1.add(txtadd1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtpaydate1.setEditable(false);
        txtpaydate1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtpaydate1.setToolTipText("");
        txtpaydate1.setBounds(250, 180, 120, 25);
        jLayeredPane1.add(txtpaydate1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btncancle1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancle1.setText("Clear");
        btncancle1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncancle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancle1ActionPerformed(evt);
            }
        });
        btncancle1.setBounds(298, 570, 67, 25);
        jLayeredPane1.add(btncancle1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnsave1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnsave1.setText("Save");
        btnsave1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsave1ActionPerformed(evt);
            }
        });
        btnsave1.setBounds(200, 570, 73, 25);
        jLayeredPane1.add(btnsave1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnhome1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnhome1.setText("Home");
        btnhome1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnhome1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhome1ActionPerformed(evt);
            }
        });
        btnhome1.setBounds(390, 570, 70, 25);
        jLayeredPane1.add(btnhome1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel57.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel57.setText("Payment Date:");
        jLabel57.setBounds(60, 140, 120, 20);
        jLayeredPane1.add(jLabel57, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txttaxamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txttaxamt.setToolTipText("Use Only Digit(0-9)");
        txttaxamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txttaxamtFocusLost(evt);
            }
        });
        txttaxamt.setBounds(250, 220, 120, 25);
        jLayeredPane1.add(txttaxamt, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel58.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel58.setText("Registration No.");
        jLabel58.setBounds(60, 60, 128, 20);
        jLayeredPane1.add(jLabel58, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtregno.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtregno.setToolTipText("Type Registration No. And Then Press Enter");
        txtregno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtregnoActionPerformed(evt);
            }
        });
        txtregno.setBounds(250, 60, 200, 25);
        jLayeredPane1.add(txtregno, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane1);
        jLayeredPane1.setBounds(10, 200, 180, 650);

        jLayeredPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vehicle Fitness Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28))); // NOI18N

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel29.setText("Broker/Agent Name:");
        jLabel29.setBounds(60, 420, 170, 20);
        jLayeredPane2.add(jLabel29, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel59.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel59.setText("Next Due Date:");
        jLabel59.setBounds(60, 340, 120, 20);
        jLayeredPane2.add(jLabel59, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbrtp2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbrtp2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Monthly", "Quarterly", "Half Yearly", "Yearly", "LifeTime" }));
        cmbrtp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbrtp2ActionPerformed(evt);
            }
        });
        cmbrtp2.setBounds(250, 260, 100, 23);
        jLayeredPane2.add(cmbrtp2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel60.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel60.setText("Fitness Period:");
        jLabel60.setBounds(60, 260, 120, 20);
        jLayeredPane2.add(jLabel60, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbyy2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbyy2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YY", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" }));
        cmbyy2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbyy2ActionPerformed(evt);
            }
        });
        cmbyy2.setBounds(400, 140, 64, 23);
        jLayeredPane2.add(cmbyy2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtfitoff.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfitoff.setToolTipText("Use Only Character(a to z,A to Z)");
        txtfitoff.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfitoffFocusLost(evt);
            }
        });
        txtfitoff.setBounds(250, 100, 200, 25);
        jLayeredPane2.add(txtfitoff, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel61.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel61.setText("Fitness Amount:");
        jLabel61.setBounds(60, 220, 130, 20);
        jLayeredPane2.add(jLabel61, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel62.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel62.setText("Next Payable Amount:");
        jLabel62.setBounds(60, 300, 180, 20);
        jLayeredPane2.add(jLabel62, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbmm2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbmm2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));
        cmbmm2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbmm2ActionPerformed(evt);
            }
        });
        cmbmm2.setBounds(320, 140, 56, 23);
        jLayeredPane2.add(cmbmm2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtbrname2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtbrname2.setToolTipText("Use Only Character(a to z,A to Z)");
        txtbrname2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtbrname2FocusLost(evt);
            }
        });
        txtbrname2.setBounds(250, 420, 187, 25);
        jLayeredPane2.add(txtbrname2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpdate2.setEditable(false);
        txtnpdate2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpdate2.setToolTipText("");
        txtnpdate2.setBounds(250, 340, 120, 25);
        jLayeredPane2.add(txtnpdate2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbdd2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbdd2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cmbdd2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbdd2ActionPerformed(evt);
            }
        });
        cmbdd2.setBounds(250, 140, 48, 23);
        jLayeredPane2.add(cmbdd2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel63.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel63.setText("Fitness Upto:");
        jLabel63.setBounds(60, 180, 110, 20);
        jLayeredPane2.add(jLabel63, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpamt2.setEditable(false);
        txtnpamt2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpamt2.setToolTipText("");
        txtnpamt2.setBounds(250, 300, 120, 25);
        jLayeredPane2.add(txtnpamt2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel64.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel64.setText("Fitness Office:");
        jLabel64.setBounds(60, 100, 110, 20);
        jLayeredPane2.add(jLabel64, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbtpb2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbtpb2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Broker", "Agent", "Self" }));
        cmbtpb2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtpb2ActionPerformed(evt);
            }
        });
        cmbtpb2.setBounds(250, 380, 100, 23);
        jLayeredPane2.add(cmbtpb2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel65.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel65.setText("Fitness Payment By:");
        jLabel65.setBounds(60, 380, 160, 20);
        jLayeredPane2.add(jLabel65, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel66.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel66.setText("Contact No.");
        jLabel66.setBounds(60, 460, 100, 20);
        jLayeredPane2.add(jLabel66, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtcont2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcont2.setToolTipText("Use Only Digit(0-9)");
        txtcont2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcont2FocusLost(evt);
            }
        });
        txtcont2.setBounds(250, 460, 187, 25);
        jLayeredPane2.add(txtcont2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel67.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel67.setText("Address:");
        jLabel67.setBounds(60, 500, 70, 20);
        jLayeredPane2.add(jLabel67, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtadd2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtadd2.setToolTipText("");
        txtadd2.setBounds(250, 500, 187, 25);
        jLayeredPane2.add(txtadd2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtpaydate2.setEditable(false);
        txtpaydate2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtpaydate2.setToolTipText("");
        txtpaydate2.setBounds(250, 180, 120, 25);
        jLayeredPane2.add(txtpaydate2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btncancle2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancle2.setText("Clear");
        btncancle2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncancle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancle2ActionPerformed(evt);
            }
        });
        btncancle2.setBounds(298, 570, 67, 25);
        jLayeredPane2.add(btncancle2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnsave2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnsave2.setText("Save");
        btnsave2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsave2ActionPerformed(evt);
            }
        });
        btnsave2.setBounds(200, 570, 73, 25);
        jLayeredPane2.add(btnsave2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnhome2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnhome2.setText("Home");
        btnhome2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnhome2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhome2ActionPerformed(evt);
            }
        });
        btnhome2.setBounds(390, 570, 70, 25);
        jLayeredPane2.add(btnhome2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel68.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel68.setText("Payment Date:");
        jLabel68.setBounds(60, 140, 120, 20);
        jLayeredPane2.add(jLabel68, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtfitamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfitamt.setToolTipText("Use Only Digit(0-9)");
        txtfitamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfitamtFocusLost(evt);
            }
        });
        txtfitamt.setBounds(250, 220, 120, 25);
        jLayeredPane2.add(txtfitamt, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel69.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel69.setText("Registration No.");
        jLabel69.setBounds(60, 60, 128, 20);
        jLayeredPane2.add(jLabel69, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtregno2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtregno2.setToolTipText("Type Registration No. And Then Press Enter");
        txtregno2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtregno2ActionPerformed(evt);
            }
        });
        txtregno2.setBounds(250, 60, 200, 25);
        jLayeredPane2.add(txtregno2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane2);
        jLayeredPane2.setBounds(220, 210, 510, 610);

        jLayeredPane3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vehicle Insurance Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 28))); // NOI18N

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel27.setText("Broker/Agent Name:");
        jLabel27.setBounds(60, 420, 170, 20);
        jLayeredPane3.add(jLabel27, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel32.setText("Next Due Date:");
        jLabel32.setBounds(60, 340, 120, 20);
        jLayeredPane3.add(jLabel32, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbrtp3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbrtp3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Monthly", "Quarterly", "Half Yearly", "Yearly", "LifeTime" }));
        cmbrtp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbrtp3ActionPerformed(evt);
            }
        });
        cmbrtp3.setBounds(250, 260, 100, 23);
        jLayeredPane3.add(cmbrtp3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel46.setText("Insurance Period:");
        jLabel46.setBounds(60, 260, 140, 20);
        jLayeredPane3.add(jLabel46, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbyy3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbyy3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YY", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" }));
        cmbyy3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbyy3ActionPerformed(evt);
            }
        });
        cmbyy3.setBounds(400, 140, 64, 23);
        jLayeredPane3.add(cmbyy3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtincoff.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtincoff.setToolTipText("Use Only Character(a to z,A to Z)");
        txtincoff.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtincoffFocusLost(evt);
            }
        });
        txtincoff.setBounds(250, 100, 200, 25);
        jLayeredPane3.add(txtincoff, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel39.setText("Insurance Amount:");
        jLabel39.setBounds(60, 220, 150, 20);
        jLayeredPane3.add(jLabel39, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel45.setText("Next Payable Amount:");
        jLabel45.setBounds(60, 300, 180, 20);
        jLayeredPane3.add(jLabel45, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbmm3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbmm3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));
        cmbmm3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbmm3ActionPerformed(evt);
            }
        });
        cmbmm3.setBounds(320, 140, 56, 23);
        jLayeredPane3.add(cmbmm3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtbrname3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtbrname3.setToolTipText("Use Only Character(a to z,A to Z)");
        txtbrname3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtbrname3FocusLost(evt);
            }
        });
        txtbrname3.setBounds(250, 420, 187, 25);
        jLayeredPane3.add(txtbrname3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpdate3.setEditable(false);
        txtnpdate3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpdate3.setToolTipText("");
        txtnpdate3.setBounds(250, 340, 120, 25);
        jLayeredPane3.add(txtnpdate3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbdd3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbdd3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cmbdd3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbdd3ActionPerformed(evt);
            }
        });
        cmbdd3.setBounds(250, 140, 48, 23);
        jLayeredPane3.add(cmbdd3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel33.setText("Insurance Upto:");
        jLabel33.setBounds(60, 180, 130, 20);
        jLayeredPane3.add(jLabel33, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtnpamt3.setEditable(false);
        txtnpamt3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtnpamt3.setToolTipText("");
        txtnpamt3.setBounds(250, 300, 120, 25);
        jLayeredPane3.add(txtnpamt3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel43.setText("Insurance Office:");
        jLabel43.setBounds(60, 100, 140, 20);
        jLayeredPane3.add(jLabel43, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cmbtpb3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cmbtpb3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Broker", "Agent", "Self" }));
        cmbtpb3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtpb3ActionPerformed(evt);
            }
        });
        cmbtpb3.setBounds(250, 380, 100, 23);
        jLayeredPane3.add(cmbtpb3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel47.setText("Insurance Payment By:");
        jLabel47.setBounds(60, 380, 180, 20);
        jLayeredPane3.add(jLabel47, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel34.setText("Contact No.");
        jLabel34.setBounds(60, 460, 100, 20);
        jLayeredPane3.add(jLabel34, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtcont3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcont3.setToolTipText("Use Only Digit(0-9)");
        txtcont3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcont3FocusLost(evt);
            }
        });
        txtcont3.setBounds(250, 460, 187, 25);
        jLayeredPane3.add(txtcont3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel48.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel48.setText("Address:");
        jLabel48.setBounds(60, 500, 70, 20);
        jLayeredPane3.add(jLabel48, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtadd3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtadd3.setToolTipText("");
        txtadd3.setBounds(250, 500, 187, 25);
        jLayeredPane3.add(txtadd3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtpaydate3.setEditable(false);
        txtpaydate3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtpaydate3.setToolTipText("");
        txtpaydate3.setBounds(250, 180, 120, 25);
        jLayeredPane3.add(txtpaydate3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btncancle3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancle3.setText("Clear");
        btncancle3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncancle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancle3ActionPerformed(evt);
            }
        });
        btncancle3.setBounds(298, 570, 67, 25);
        jLayeredPane3.add(btncancle3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnsave3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnsave3.setText("Save");
        btnsave3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsave3ActionPerformed(evt);
            }
        });
        btnsave3.setBounds(200, 570, 73, 25);
        jLayeredPane3.add(btnsave3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnhome3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnhome3.setText("Home");
        btnhome3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnhome3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhome3ActionPerformed(evt);
            }
        });
        btnhome3.setBounds(390, 570, 70, 25);
        jLayeredPane3.add(btnhome3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel49.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel49.setText("Insurance Date:");
        jLabel49.setBounds(60, 140, 130, 20);
        jLayeredPane3.add(jLabel49, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtincamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtincamt.setToolTipText("Use Only Digit(0-9)");
        txtincamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtincamtFocusLost(evt);
            }
        });
        txtincamt.setBounds(250, 220, 120, 25);
        jLayeredPane3.add(txtincamt, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel38.setText("Registration No.");
        jLabel38.setBounds(60, 60, 128, 20);
        jLayeredPane3.add(jLabel38, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtregno3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtregno3.setToolTipText("Type Registration No. And Then Press Enter");
        txtregno3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtregno3ActionPerformed(evt);
            }
        });
        txtregno3.setBounds(250, 60, 200, 25);
        jLayeredPane3.add(txtregno3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane3);
        jLayeredPane3.setBounds(820, 200, 530, 600);

        jPanel3.setBackground(new java.awt.Color(204, 51, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        head1.setBackground(new java.awt.Color(204, 51, 0));
        head1.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        head1.setForeground(new java.awt.Color(255, 255, 0));
        head1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head1.setText("Holistic Heritage Academy");
        head1.setOpaque(true);
        jPanel3.add(head1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 610, -1));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 0));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("(An English Medium School)");
        jLabel40.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 180, 20));

        head2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        head2.setForeground(new java.awt.Color(255, 255, 0));
        head2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head2.setText("\"Shanti Niketan\" Pali Road, Dehri-On-Sone, Rohtas (Bihar) Pin Code - 821307");
        head2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel3.add(head2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 820, 25));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setOpaque(true);
        jPanel3.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 56, 585, 2));

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1480, 110);

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
private String dateSubstract(String date1,String date2){
    int dd=0,mm=0,yy=0;
    String day,month,year;
    flagdate=true;
        String strdate1=date1;
        String strdate2=date2;
        //01-02-2016
       // 06-11-1991
        int dd1=Integer.parseInt(strdate1.substring(0,2));
        int mm1=Integer.parseInt(strdate1.substring(3,5));
        int yy1=Integer.parseInt(strdate1.substring(6,10));//2015
        int dd2=Integer.parseInt(strdate2.substring(0,2));
        int mm2=Integer.parseInt(strdate2.substring(3,5));
        int yy2=Integer.parseInt(strdate2.substring(6,10));//2016
        if(yy2<yy1){
//            JOptionPane.showMessageDialog(rootPane, "Year Less Than The Second Year! Invalid Entry");
            flagdate=false;
            yy=yy1;
}
        else{
if(dd1>=dd2){
   dd=dd1-dd2;
}
else{
    switch(mm1){
        case 1:
           dd1=dd1+31;
           dd=dd1-dd2;
           mm1--;
            break;
        case 2:
            if(yy1%4==0&&yy1%100!=0||yy1%400==0){
                dd1=dd1+29;
                dd=dd1-dd2;
                mm1--;
                break;
            }
            else{
                dd1=dd1+28;
                dd=dd1-dd2;
                mm1--;
                break;
            }
        case 3:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;
        case 4:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;
        case 5:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;
        case 6:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;
        case 7:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;    
         case 8:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;   
         case 9:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 10:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 11:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 12:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;  
    }
}
if(mm1>=mm2){
    mm=mm1;
}
else{
    mm=mm1+12;
    yy1--;
}
yy=yy1;
        }
        if(dd<=9){
            day="0"+String.valueOf(dd);
        }
        else{
            day=String.valueOf(dd);
        }
        if(mm<=9){
            month="0"+String.valueOf(mm);
        }
        else{
            month=String.valueOf(mm);
        }
        year=String.valueOf(yy);
        String date=day+"-"+month+"-"+year;
return(date);
}
    private void txtincoffFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtincoffFocusLost
        // TODO add your handling code here:
        if (txtincoff.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtincoff.setText("");
        }
    }//GEN-LAST:event_txtincoffFocusLost

    private void txtbrname3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtbrname3FocusLost
        // TODO add your handling code here:
        if (txtbrname3.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtbrname3.setText("");
        }
    }//GEN-LAST:event_txtbrname3FocusLost

    private void txtcont3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcont3FocusLost
        // TODO add your handling code here:
        if (txtcont3.getText().matches("\\d*") || txtcont3.getText().matches("[+]\\d*")) {
        } else {
            txtcont3.setText("+91");
        }
        if (txtcont3.getText().length() != 13) {
            txtcont3.setText("+91");
            }
    }//GEN-LAST:event_txtcont3FocusLost

    private void btnsave3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsave3ActionPerformed
        // TODO add your handling code here:
        boolean flag=false,flag2=false,flag3=false;
        String nextdate1="";
        if (txtregno3.getText().equals("") || txtincoff.getText().equals("") || cmbdd3.getSelectedIndex() == 0 || cmbmm3.getSelectedIndex() == 0 || cmbyy3.getSelectedIndex() == 0 || txtincamt.getText().equals("")|| txtnpamt3.getText().equals("")|| txtnpdate3.getText().equals("") || txtpaydate3.getText().equals("")|| cmbrtp3.getSelectedIndex() == 0||cmbtpb3.getSelectedIndex() == 0||txtbrname3.isEditable()&&txtbrname3.getText().equals("")||txtcont3.isEditable()==true&&(txtcont3.getText().equals("")||txtcont3.getText().equals("+91"))||txtadd3.isEditable()==true&&txtadd3.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup The All Fields", "Registration_Details", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            String dd1 = String.valueOf(cmbdd3.getSelectedItem());
            String mm1 = String.valueOf(cmbmm3.getSelectedItem());
            String yy1 = String.valueOf(cmbyy3.getSelectedItem());
            String authdate1 = dd1.concat("-").concat(mm1).concat("-").concat(yy1);
            try{
            String regno=txtregno3.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flag==true){
            try{
            String regno=txtregno3.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT NEXTPAY_DATE FROM VEHICLE_INSURANCE WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            rs.last();
          String npdate=String.valueOf(rs.getDate(1));
          nextdate1=SchoolStaff.date(npdate);
            flag2=true;                            
            }
            catch(SQLException ex){
                flag2=false;
            }
            }
            if(flag==false){
                JOptionPane.showMessageDialog(rootPane, "Registration No. Does Not Exist");
            }
            else if(flaginc==true&&(nextdate3.equals(authdate1))){
                flag3=true;
            }
            else if((flag==true&&flag2==true)&&(nextdate1.equals(authdate1))){
                flag3=true;
            }
            else if(flag==true&&flag2==false){
                flag3=true;
            }
            else{
                JOptionPane.showMessageDialog(rootPane, "Payment Date Does Not Match With Next Due Date");
            }
            if(flag3==true){
            String regno1=txtregno3.getText();
            String taxoff=txtincoff.getText();
            String taxamt=txtincamt.getText();
            String taxperiod=String.valueOf(cmbrtp3.getSelectedItem());
            String nextpaydate=txtnpdate3.getText();
            String taxpayby=String.valueOf(cmbtpb3.getSelectedItem());
            String brname=txtbrname3.getText();
            String cont=txtcont3.getText();
            String add=txtadd3.getText();
            String curdate = NewJPanel.lbldate.getText().substring(5, 15);
            String entrydate = NewAdmPanel.date(curdate);
            String time = NewJPanel.lbltime.getText();
            String entrytime = time.substring(5, 16);
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String str = ("INSERT INTO VEHICLE_INSURANCE VALUES('" + regno1 + "','" + taxoff + "','" + authdate1 + "','" + taxamt + "','" + taxperiod + "','" + nextpaydate + "','" + taxpayby + "','" + brname + "','" + cont + "','" + add + "','" + entrydate + "','" + entrytime + "')");
                stmt = con.createStatement();
                stmt.executeUpdate(str);
                JOptionPane.showMessageDialog(this, "Data Saved Successfully");
                clear2();
                stmt.close();
//                con.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, ex.getMessage(), "VEHICLE_INSURANCE", JOptionPane.INFORMATION_MESSAGE, null);
            }
        }
        }
    }//GEN-LAST:event_btnsave3ActionPerformed

    private void txtincamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtincamtFocusLost
        // TODO add your handling code here:
        if (txtincamt.getText().matches("\\d+")) {
        } else {
            txtincamt.setText("");
        }
        if (txtincamt.getText().length() > 8) {
            txtincamt.setText("");
        }
        if (txtincamt.getText().equals("")) {
        } else {
            long amt = Long.parseLong(txtincamt.getText());
            if (amt <= 0) {
                txtincamt.setText("");
            }
            else{
                txtnpamt3.setText(txtincamt.getText());
            }
        }
    }//GEN-LAST:event_txtincamtFocusLost
private void search2(){
  boolean  flag=false;
        if (txtregno3.getText().equals("")) {
            txtregno3.grabFocus();
        } else {
            String str2 = txtregno3.getText();
        try {
            flaginc=false;
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT * FROM VEHICLE_INSURANCE WHERE UPPER(REG_NO)='"+str2+"' OR LOWER(REG_NO)='"+str2+"'";
            rs = stmt.executeQuery(str);
            rs.last();
                txtregno3.setText(rs.getString(1));
                txtincoff.setText(rs.getString(2));
                String st = String.valueOf(rs.getDate(3));
                String slm = SchoolStaff.date(st);
                String stc1 = slm.substring(0, 2);
                String stc2 = slm.substring(3, 6);
                String stc3 = slm.substring(7, 11);
                cmbdd3.setSelectedItem(stc1);
                cmbmm3.setSelectedItem(stc2);
                cmbyy3.setSelectedItem(stc3);
                txtpaydate3.setText(slm);
                txtincamt.setText(rs.getString(4));
                cmbrtp3.setSelectedItem(rs.getString(5));
                txtnpamt3.setText(txtincamt.getText());
                String st1 = String.valueOf(rs.getDate(6));
                nextdate3 = SchoolStaff.date(st1);
                txtnpdate3.setText(nextdate3);
                cmbtpb3.setSelectedItem(rs.getString(7));
                txtbrname3.setText(rs.getString(8));
                txtcont3.setText(rs.getString(9));
                txtadd3.setText(rs.getString(10));
                txtregno3.setEditable(false);
                txtincoff.grabFocus();
                flaginc=true;
            stmt.close();
            rs.close();
//            con.close();
        } catch (Exception Exc) {
            flaginc=false;
            try{
            String regno=txtregno3.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                txtincoff.grabFocus();
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flaginc==false&&flag==false){
                JOptionPane.showMessageDialog(rootPane, "No Data Found");
                clear2();
            }
        }
    }
}
    private void txtregno3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtregno3ActionPerformed
        // TODO add your handling code here:
        search2();
        
    }//GEN-LAST:event_txtregno3ActionPerformed

    private void lblvtd1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblvtd1MouseClicked
        // TODO add your handling code here:
        if(fit==1){
            jLayeredPane2.setVisible(false);
        }
        if(inc==1){
            jLayeredPane3.setVisible(false);
        }
        if(tax==0){
        jLayeredPane1.setBounds(340, 200, 690, 620);
        jLayeredPane1.setVisible(true);
        txtregno.grabFocus();
        tax=1;
        inc=0;
        fit=0;
        }
        lblvtd1.setBackground(Color.LIGHT_GRAY);
        lblvtd3.setBackground(new java.awt.Color(216,197,236));
        lblvtd2.setBackground(new java.awt.Color(216,197,236));
    }//GEN-LAST:event_lblvtd1MouseClicked

    private void txttaxFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txttaxFocusLost
        // TODO add your handling code here:
        if (txttax.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txttax.setText("");
        }
    }//GEN-LAST:event_txttaxFocusLost

    private void txtbrname1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtbrname1FocusLost
        // TODO add your handling code here:
        if (txtbrname1.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtbrname1.setText("");
        }
    }//GEN-LAST:event_txtbrname1FocusLost

    private void txtcont1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcont1FocusLost
        // TODO add your handling code here:
        if (txtcont1.getText().matches("\\d*") || txtcont1.getText().matches("[+]\\d*")) {
        } else {
            txtcont1.setText("+91");
        }
        if (txtcont1.getText().length() != 13) {
            txtcont1.setText("+91");
            }
    }//GEN-LAST:event_txtcont1FocusLost

    private void btnsave1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsave1ActionPerformed
        // TODO add your handling code here:
        boolean flag=false,flag2=false,flag3=false;
        String nextdate1="";
        if (txtregno.getText().equals("") || txttax.getText().equals("") || cmbdd1.getSelectedIndex() == 0 || cmbmm1.getSelectedIndex() == 0 || cmbyy1.getSelectedIndex() == 0 || txttaxamt.getText().equals("")|| txtnpamt1.getText().equals("")|| txtnpdate1.getText().equals("") || txtpaydate1.getText().equals("")|| cmbrtp1.getSelectedIndex() == 0||cmbtpb1.getSelectedIndex() == 0||txtbrname1.isEditable()&&txtbrname1.getText().equals("")||txtcont1.isEditable()==true&&(txtcont1.getText().equals("")||txtcont1.getText().equals("+91"))||txtadd1.isEditable()==true&&txtadd1.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup The All Fields", "Registration_Details", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            String dd1 = String.valueOf(cmbdd1.getSelectedItem());
            String mm1 = String.valueOf(cmbmm1.getSelectedItem());
            String yy1 = String.valueOf(cmbyy1.getSelectedItem());
            String authdate1 = dd1.concat("-").concat(mm1).concat("-").concat(yy1);
            try{
            String regno=txtregno.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flag==true){
            try{
            String regno=txtregno.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT NEXTPAY_DATE FROM VEHICLE_TAX WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            rs.last();
          String npdate=String.valueOf(rs.getDate(1));
          nextdate1=SchoolStaff.date(npdate);
            flag2=true;                            
            }
            catch(SQLException ex){
                flag2=false;
            }
            }
            if(flag==false){
                JOptionPane.showMessageDialog(rootPane, "Registration No. Does Not Exist");
            }
            else if(flag1==true&&(nextdate.equals(authdate1))){
                flag3=true;
            }
            else if((flag==true&&flag2==true)&&(nextdate1.equals(authdate1))){
                flag3=true;
            }
            else if(flag==true&&flag2==false){
                flag3=true;
            }
            else{
                JOptionPane.showMessageDialog(rootPane, "Payment Date Does Not Match With Next Due Date");
            }
            if(flag3==true){
            String regno1=txtregno.getText();
            String taxoff=txttax.getText();
            String taxamt=txttaxamt.getText();
            String taxperiod=String.valueOf(cmbrtp1.getSelectedItem());
            String nextpaydate=txtnpdate1.getText();
            String taxpayby=String.valueOf(cmbtpb1.getSelectedItem());
            String brname=txtbrname1.getText();
            String cont=txtcont1.getText();
            String add=txtadd1.getText();
            String curdate = NewJPanel.lbldate.getText().substring(5, 15);
            String entrydate = NewAdmPanel.date(curdate);
            String time = NewJPanel.lbltime.getText();
            String entrytime = time.substring(5, 16);
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String str = ("INSERT INTO VEHICLE_TAX VALUES('" + regno1 + "','" + taxoff + "','" + authdate1 + "','" + taxamt + "','" + taxperiod + "','" + nextpaydate + "','" + taxpayby + "','" + brname + "','" + cont + "','" + add + "','" + entrydate + "','" + entrytime + "')");
                stmt = con.createStatement();
                stmt.executeUpdate(str);
                JOptionPane.showMessageDialog(this, "Data Saved Successfully");
                clear();
                stmt.close();
//                con.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, ex.getMessage(), "VEHICLE_TAX", JOptionPane.INFORMATION_MESSAGE, null);
            }
        }
        }
    }//GEN-LAST:event_btnsave1ActionPerformed

    private void txttaxamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txttaxamtFocusLost
        // TODO add your handling code here:
        if (txttaxamt.getText().matches("\\d+")) {
        } else {
            txttaxamt.setText("");
        }
        if (txttaxamt.getText().length() > 8) {
            txttaxamt.setText("");
        }
        if (txttaxamt.getText().equals("")) {
        } else {
            long amt = Long.parseLong(txttaxamt.getText());
            if (amt <= 0) {
                txttaxamt.setText("");
            }
            else{
                txtnpamt1.setText(txttaxamt.getText());
            }
        }
    }//GEN-LAST:event_txttaxamtFocusLost
private void search(){
  boolean  flag=false;
        if (txtregno.getText().equals("")) {
            txtregno.grabFocus();
        } else {
            String str2 = txtregno.getText();
        try {
            flag1=false;
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT * FROM VEHICLE_TAX WHERE UPPER(REG_NO)='"+str2+"' OR LOWER(REG_NO)='"+str2+"'";
            rs = stmt.executeQuery(str);
            rs.last();
                txtregno.setText(rs.getString(1));
                txttax.setText(rs.getString(2));
                String st = String.valueOf(rs.getDate(3));
                String slm = SchoolStaff.date(st);
                String stc1 = slm.substring(0, 2);
                String stc2 = slm.substring(3, 6);
                String stc3 = slm.substring(7, 11);
                cmbdd1.setSelectedItem(stc1);
                cmbmm1.setSelectedItem(stc2);
                cmbyy1.setSelectedItem(stc3);
                txtpaydate1.setText(slm);
                txttaxamt.setText(rs.getString(4));
                cmbrtp1.setSelectedItem(rs.getString(5));
                txtnpamt1.setText(txttaxamt.getText());
                String st1 = String.valueOf(rs.getDate(6));
                nextdate = SchoolStaff.date(st1);
                txtnpdate1.setText(nextdate);
                cmbtpb1.setSelectedItem(rs.getString(7));
                txtbrname1.setText(rs.getString(8));
                txtcont1.setText(rs.getString(9));
                txtadd1.setText(rs.getString(10));
                txtregno.setEditable(false);
                txttax.grabFocus();
                flag1=true;
            stmt.close();
            rs.close();
//            con.close();
        } catch (Exception Exc) {
            flag1=false;
            try{
            String regno=txtregno.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                txttax.grabFocus();
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flag1==false&&flag==false){
                JOptionPane.showMessageDialog(rootPane, "No Data Found");
                clear();
            }
        }
    }
}
    private void txtregnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtregnoActionPerformed
        // TODO add your handling code here:
        search();
    }//GEN-LAST:event_txtregnoActionPerformed

    private void txtfitoffFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfitoffFocusLost
        // TODO add your handling code here:
        if (txtfitoff.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtfitoff.setText("");
        }
    }//GEN-LAST:event_txtfitoffFocusLost

    private void txtbrname2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtbrname2FocusLost
        // TODO add your handling code here:
        if (txtbrname2.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtbrname2.setText("");
        }
    }//GEN-LAST:event_txtbrname2FocusLost

    private void txtcont2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcont2FocusLost
        // TODO add your handling code here:
        if (txtcont2.getText().matches("\\d*") || txtcont2.getText().matches("[+]\\d*")) {
        } else {
            txtcont2.setText("+91");
        }
        if (txtcont2.getText().length() != 13) {
            txtcont2.setText("+91");
            }
    }//GEN-LAST:event_txtcont2FocusLost

    private void btnsave2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsave2ActionPerformed
        // TODO add your handling code here:
        boolean flag=false,flag2=false,flag3=false;
        String nextdate1="";
        if (txtregno2.getText().equals("") || txtfitoff.getText().equals("") || cmbdd2.getSelectedIndex() == 0 || cmbmm2.getSelectedIndex() == 0 || cmbyy2.getSelectedIndex() == 0 || txtfitamt.getText().equals("")|| txtnpamt2.getText().equals("")|| txtnpdate2.getText().equals("") || txtpaydate2.getText().equals("")|| cmbrtp2.getSelectedIndex() == 0||cmbtpb2.getSelectedIndex() == 0||txtbrname2.isEditable()&&txtbrname2.getText().equals("")||txtcont2.isEditable()==true&&(txtcont2.getText().equals("")||txtcont2.getText().equals("+91"))||txtadd2.isEditable()==true&&txtadd2.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup The All Fields", "Registration_Details", JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            String dd1 = String.valueOf(cmbdd2.getSelectedItem());
            String mm1 = String.valueOf(cmbmm2.getSelectedItem());
            String yy1 = String.valueOf(cmbyy2.getSelectedItem());
            String authdate1 = dd1.concat("-").concat(mm1).concat("-").concat(yy1);
            try{
            String regno=txtregno2.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flag==true){
            try{
            String regno=txtregno2.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT NEXTPAY_DATE FROM VEHICLE_FITNESS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            rs.last();
          String npdate=String.valueOf(rs.getDate(1));
          nextdate1=SchoolStaff.date(npdate);
            flag2=true;                            
            }
            catch(SQLException ex){
                flag2=false;
            }
            }
            if(flag==false){
                JOptionPane.showMessageDialog(rootPane, "Registration No. Does Not Exist");
            }
            else if(flagfit==true&&(nextdate2.equals(authdate1))){
                flag3=true;
            }
            else if((flag==true&&flag2==true)&&(nextdate1.equals(authdate1))){
                flag3=true;
            }
            else if(flag==true&&flag2==false){
                flag3=true;
            }
            else{
                JOptionPane.showMessageDialog(rootPane, "Payment Date Does Not Match With Next Due Date");
            }
            if(flag3==true){
            String regno1=txtregno2.getText();
            String taxoff=txtfitoff.getText();
            String taxamt=txtfitamt.getText();
            String taxperiod=String.valueOf(cmbrtp2.getSelectedItem());
            String nextpaydate=txtnpdate2.getText();
            String taxpayby=String.valueOf(cmbtpb2.getSelectedItem());
            String brname=txtbrname2.getText();
            String cont=txtcont2.getText();
            String add=txtadd2.getText();
            String curdate = NewJPanel.lbldate.getText().substring(5, 15);
            String entrydate = NewAdmPanel.date(curdate);
            String time = NewJPanel.lbltime.getText();
            String entrytime = time.substring(5, 16);
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String str = ("INSERT INTO VEHICLE_FITNESS VALUES('" + regno1 + "','" + taxoff + "','" + authdate1 + "','" + taxamt + "','" + taxperiod + "','" + nextpaydate + "','" + taxpayby + "','" + brname + "','" + cont + "','" + add + "','" + entrydate + "','" + entrytime + "')");
                stmt = con.createStatement();
                stmt.executeUpdate(str);
                JOptionPane.showMessageDialog(this, "Data Saved Successfully");
                clear1();
                stmt.close();
//                con.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, ex.getMessage(), "VEHICLE_FITNESS", JOptionPane.INFORMATION_MESSAGE, null);
            }
        }
        }
    }//GEN-LAST:event_btnsave2ActionPerformed

    private void txtfitamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfitamtFocusLost
        // TODO add your handling code here:
        if (txtfitamt.getText().matches("\\d+")) {
        } else {
            txtfitamt.setText("");
        }
        if (txtfitamt.getText().length() > 8) {
            txtfitamt.setText("");
        }
        if (txtfitamt.getText().equals("")) {
        } else {
            long amt = Long.parseLong(txtfitamt.getText());
            if (amt <= 0) {
                txtfitamt.setText("");
            }
            else{
                txtnpamt2.setText(txtfitamt.getText());
            }
        }
    }//GEN-LAST:event_txtfitamtFocusLost

    private void lblvtd2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblvtd2MouseClicked
        // TODO add your handling code here:
        if(tax==1){
            jLayeredPane1.setVisible(false);
        }
        if(inc==1){
            jLayeredPane3.setVisible(false);
        }
        if(fit==0){
        jLayeredPane2.setBounds(340, 200, 690, 620);
        jLayeredPane2.setVisible(true);
        txtregno2.grabFocus();
        fit=1;
        tax=0;
        inc=0;
        }
        lblvtd2.setBackground(Color.LIGHT_GRAY);
        lblvtd1.setBackground(new java.awt.Color(216,197,236));
        lblvtd3.setBackground(new java.awt.Color(216,197,236));
    }//GEN-LAST:event_lblvtd2MouseClicked

    private void lblvtd3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblvtd3MouseClicked
        // TODO add your handling code here:
        if(tax==1){
            jLayeredPane1.setVisible(false);
        }
        if(fit==1){
            jLayeredPane2.setVisible(false);
        }
        if(inc==0){
        jLayeredPane3.setBounds(340, 200, 690, 620);
        jLayeredPane3.setVisible(true);
        txtregno3.grabFocus();
        inc=1;
        tax=0;
        fit=0;
        }
        lblvtd3.setBackground(Color.LIGHT_GRAY);
        lblvtd1.setBackground(new java.awt.Color(216,197,236));
        lblvtd2.setBackground(new java.awt.Color(216,197,236));
    }//GEN-LAST:event_lblvtd3MouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        AdmissionOpen.jmi30.setEnabled(true);
        AdmissionOpen.count23 = 0;
    }//GEN-LAST:event_formWindowClosing

    private void btnhome1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhome1ActionPerformed
        // TODO add your handling code here:
         clear();
         jLayeredPane1.setVisible(false);
         tax=0;
    }//GEN-LAST:event_btnhome1ActionPerformed

    private void btnhome2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhome2ActionPerformed
        // TODO add your handling code here:
        clear1();
        jLayeredPane2.setVisible(false);
        fit=0;
//        AdmissionOpen.jmi30.setEnabled(true);
//        dispose();
//        AdmissionOpen.count23 = 0;
    }//GEN-LAST:event_btnhome2ActionPerformed

    private void btnhome3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhome3ActionPerformed
        // TODO add your handling code here:
        clear2();
        jLayeredPane3.setVisible(false);
        inc=0;
    }//GEN-LAST:event_btnhome3ActionPerformed
private void clear(){
    txtregno.setText("");
    txttax.setText("");
    cmbdd1.setSelectedIndex(0);
    cmbmm1.setSelectedIndex(0);
    cmbyy1.setSelectedIndex(0);
    txtpaydate1.setText("");
    txttaxamt.setText("");
    cmbrtp1.setSelectedIndex(0);
    txtnpamt1.setText("");                
    txtnpdate1.setText("");
    cmbtpb1.setSelectedIndex(0);
    txtbrname1.setText("");
    txtcont1.setText("");
    txtadd1.setText("");
    txtregno.setEditable(true);
    txtregno.grabFocus();
    flag1=false;
}
    private void btncancle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancle1ActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_btncancle1ActionPerformed
private String payUpto(){
       String dd1= String.valueOf(cmbdd1.getSelectedItem());
       String mm1= String.valueOf(cmbmm1.getSelectedItem());
       String yy1= String.valueOf(cmbyy1.getSelectedItem());
       String date=dd1+"-"+mm1+"-"+yy1;
       txtpaydate1.setText(date);
       return(date);
}
    private void cmbdd1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbdd1ActionPerformed
        // TODO add your handling code here:
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0){            
            txtpaydate1.setText("");
        }
        else{
       payUpto();
        }
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0||cmbrtp1.getSelectedIndex()==0){            
            txtnpdate1.setText("");
        }
        else{
       String date=payUpto();
       int period=cmbrtp1.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate1.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbdd1ActionPerformed
private String nextDueDate(String date1,int perd){
    int month1=0;
    int year1=0;
    String monthly;
    String setdate1="";
       String dd1= date1.substring(0,2);
       String yy1= date1.substring(7,11);//02-jan-2015
       String format=NewAdmPanel.dateFormat(date1);
       String mm=format.substring(3,5);//01-02-2015
       int month=Integer.parseInt(mm);
       int year=Integer.parseInt(yy1);
       int period=perd;
       if(period==5){
           setdate1="Life Time";
       }
       else if(period==1){
           month1=month+1;
           year1=year;
           if(month1>12){
               month1=1;
               year1=year+1;
           }
       }
       else if(period==2){
           month1=month+3;
           year1=year;
               if(month1==13){
                   month1=1;
                   year1=year+1;
               }
               else if(month1==14){
                   month1=2;
                   year1=year+1;
               }
               else if(month1==15){
                   month1=3;
                   year1=year+1;
               }
       }
       else if(period==3){
           month1=month+6;
           year1=year;
           if(month1==13){
                   month1=1;
                   year1=year+1;
               }
               else if(month1==14){
                   month1=2;
                   year1=year+1;
               }
               else if(month1==15){
                   month1=4;
                   year1=year+1;
               }
               else if(month1==16){
                   month1=4;
                   year1=year+1;
               }
               else if(month1==17){
                   month1=5;
                   year1=year+1;
               }
               else if(month1==18){
                   month1=6;
                   year1=year+1;
               }
       }
       else if(period==4){
           month1=month;
           year1=year+1;
       }
       if(period==1||period==2||period==3||period==4){
           if(month1<10){
               monthly="0"+String.valueOf(month1);
           }
           else{
               monthly=String.valueOf(month1);
           }
           String setdate=dd1+"-"+String.valueOf(monthly)+"-"+String.valueOf(year1);
           setdate1=NewAdmPanel.date(setdate);
//           txtnpdate1.setText(setdate1);
       }
       else if(period==0){
           setdate1="";
//           txtnpdate1.setText("");
       }
       return(setdate1);
}
    private void cmbrtp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbrtp1ActionPerformed
        // TODO add your handling code here:
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0||cmbrtp1.getSelectedIndex()==0){            
            txtnpdate1.setText("");
        }
        else{
       String date=payUpto();
       int period=cmbrtp1.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate1.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbrtp1ActionPerformed

    private void cmbmm1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbmm1ActionPerformed
        // TODO add your handling code here:
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0){            
            txtpaydate1.setText("");
        }
        else{
       payUpto();
        }
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0||cmbrtp1.getSelectedIndex()==0){            
            txtnpdate1.setText("");
        }
        else{
       String date=payUpto();
       int period=cmbrtp1.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate1.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbmm1ActionPerformed

    private void cmbyy1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbyy1ActionPerformed
        // TODO add your handling code here:
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0){            
            txtpaydate1.setText("");
        }
        else{
       payUpto();
        }
        if(cmbdd1.getSelectedIndex()==0||cmbmm1.getSelectedIndex()==0||cmbyy1.getSelectedIndex()==0||cmbrtp1.getSelectedIndex()==0){            
            txtnpdate1.setText("");
        }
        else{
       String date=payUpto();
       int period=cmbrtp1.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate1.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbyy1ActionPerformed

    private void cmbtpb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtpb1ActionPerformed
        // TODO add your handling code here:
        if(cmbtpb1.getSelectedIndex()==0||cmbtpb1.getSelectedIndex()==3){
            txtbrname1.setEditable(false);
            txtcont1.setEditable(false);
            txtadd1.setEditable(false);
            txtcont1.setText("");
        }
        else{
            txtbrname1.setEditable(true);
            txtcont1.setEditable(true);
            txtadd1.setEditable(true);
            txtcont1.setText("+91");
        }
    }//GEN-LAST:event_cmbtpb1ActionPerformed
private void search1(){
  boolean  flag=false;
        if (txtregno2.getText().equals("")) {
            txtregno2.grabFocus();
        } else {
            String str2 = txtregno2.getText();
        try {
            flagfit=false;
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT * FROM VEHICLE_FITNESS WHERE UPPER(REG_NO)='"+str2+"' OR LOWER(REG_NO)='"+str2+"'";
            rs = stmt.executeQuery(str);
            rs.last();
                txtregno2.setText(rs.getString(1));
                txtfitoff.setText(rs.getString(2));
                String st = String.valueOf(rs.getDate(3));
                String slm = SchoolStaff.date(st);
                String stc1 = slm.substring(0, 2);
                String stc2 = slm.substring(3, 6);
                String stc3 = slm.substring(7, 11);
                cmbdd2.setSelectedItem(stc1);
                cmbmm2.setSelectedItem(stc2);
                cmbyy2.setSelectedItem(stc3);
                txtpaydate2.setText(slm);
                txtfitamt.setText(rs.getString(4));
                cmbrtp2.setSelectedItem(rs.getString(5));
                txtnpamt2.setText(txtfitamt.getText());
                String st1 = String.valueOf(rs.getDate(6));
                nextdate2 = SchoolStaff.date(st1);
                txtnpdate2.setText(nextdate2);
                cmbtpb2.setSelectedItem(rs.getString(7));
                txtbrname2.setText(rs.getString(8));
                txtcont2.setText(rs.getString(9));
                txtadd2.setText(rs.getString(10));
                txtregno2.setEditable(false);
                txtfitoff.grabFocus();
                flagfit=true;
            stmt.close();
            rs.close();
//            con.close();
        } catch (Exception Exc) {
            flagfit=false;
            try{
            String regno=txtregno2.getText();
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str = "SELECT REG_NO FROM VEHICLES_DETAILS WHERE UPPER(REG_NO)='"+regno+"' OR LOWER(REG_NO)='"+regno+"'";
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                regno=rs.getString(1);
                txtfitoff.grabFocus();
                flag=true;
                break;
            }
            }
            catch(SQLException ex){
                flag=false;
            }
            if(flagfit==false&&flag==false){
                JOptionPane.showMessageDialog(rootPane, "No Data Found");
                clear1();
            }
        }
    }
}
    private void txtregno2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtregno2ActionPerformed
        // TODO add your handling code here:
        search1();
    }//GEN-LAST:event_txtregno2ActionPerformed
private String payUpto1(){
       String dd1= String.valueOf(cmbdd2.getSelectedItem());
       String mm1= String.valueOf(cmbmm2.getSelectedItem());
       String yy1= String.valueOf(cmbyy2.getSelectedItem());
       String date=dd1+"-"+mm1+"-"+yy1;
       txtpaydate2.setText(date);
       return(date);
}
    private void cmbdd2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbdd2ActionPerformed
        // TODO add your handling code here:
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0){            
            txtpaydate2.setText("");
        }
        else{
       payUpto1();
        }
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0||cmbrtp2.getSelectedIndex()==0){            
            txtnpdate2.setText("");
        }
        else{
       String date=payUpto1();
       int period=cmbrtp2.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate2.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbdd2ActionPerformed

    private void cmbmm2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbmm2ActionPerformed
        // TODO add your handling code here:
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0){            
            txtpaydate2.setText("");
        }
        else{
       payUpto1();
        }
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0||cmbrtp2.getSelectedIndex()==0){            
            txtnpdate2.setText("");
        }
        else{
       String date=payUpto1();
       int period=cmbrtp2.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate2.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbmm2ActionPerformed

    private void cmbyy2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbyy2ActionPerformed
        // TODO add your handling code here:
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0){            
            txtpaydate2.setText("");
        }
        else{
       payUpto1();
        }
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0||cmbrtp2.getSelectedIndex()==0){            
            txtnpdate2.setText("");
        }
        else{
       String date=payUpto1();
       int period=cmbrtp2.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate2.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbyy2ActionPerformed

    private void cmbrtp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbrtp2ActionPerformed
        // TODO add your handling code here:
        if(cmbdd2.getSelectedIndex()==0||cmbmm2.getSelectedIndex()==0||cmbyy2.getSelectedIndex()==0||cmbrtp2.getSelectedIndex()==0){            
            txtnpdate2.setText("");
        }
        else{
       String date=payUpto1();
       int period=cmbrtp2.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate2.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbrtp2ActionPerformed

    private void cmbtpb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtpb2ActionPerformed
        // TODO add your handling code here:
        if(cmbtpb2.getSelectedIndex()==0||cmbtpb2.getSelectedIndex()==3){
            txtbrname2.setEditable(false);
            txtcont2.setEditable(false);
            txtadd2.setEditable(false);
            txtcont2.setText("");
        }
        else{
            txtbrname2.setEditable(true);
            txtcont2.setEditable(true);
            txtadd2.setEditable(true);
            txtcont2.setText("+91");
        }
    }//GEN-LAST:event_cmbtpb2ActionPerformed
private void clear1(){
    txtregno2.setText("");
    txtfitoff.setText("");
    cmbdd2.setSelectedIndex(0);
    cmbmm2.setSelectedIndex(0);
    cmbyy2.setSelectedIndex(0);
    txtpaydate2.setText("");
    txtfitamt.setText("");
    cmbrtp2.setSelectedIndex(0);
    txtnpamt2.setText("");                
    txtnpdate2.setText("");
    cmbtpb2.setSelectedIndex(0);
    txtbrname2.setText("");
    txtcont2.setText("");
    txtadd2.setText("");
    txtregno2.setEditable(true);
    txtregno2.grabFocus();
    flagfit=false;
}
    private void btncancle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancle2ActionPerformed
        // TODO add your handling code here:
        clear1();
    }//GEN-LAST:event_btncancle2ActionPerformed
private String payUpto2(){
       String dd1= String.valueOf(cmbdd3.getSelectedItem());
       String mm1= String.valueOf(cmbmm3.getSelectedItem());
       String yy1= String.valueOf(cmbyy3.getSelectedItem());
       String date=dd1+"-"+mm1+"-"+yy1;
       txtpaydate3.setText(date);
       return(date);
}
    private void cmbdd3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbdd3ActionPerformed
        // TODO add your handling code here:
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0){            
            txtpaydate3.setText("");
        }
        else{
       payUpto2();
        }
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0||cmbrtp3.getSelectedIndex()==0){            
            txtnpdate3.setText("");
        }
        else{
       String date=payUpto2();
       int period=cmbrtp3.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate3.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbdd3ActionPerformed

    private void cmbmm3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbmm3ActionPerformed
        // TODO add your handling code here:
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0){            
            txtpaydate3.setText("");
        }
        else{
       payUpto2();
        }
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0||cmbrtp3.getSelectedIndex()==0){            
            txtnpdate3.setText("");
        }
        else{
       String date=payUpto2();
       int period=cmbrtp3.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate3.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbmm3ActionPerformed

    private void cmbyy3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbyy3ActionPerformed
        // TODO add your handling code here:
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0){            
            txtpaydate3.setText("");
        }
        else{
       payUpto2();
        }
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0||cmbrtp3.getSelectedIndex()==0){            
            txtnpdate3.setText("");
        }
        else{
       String date=payUpto2();
       int period=cmbrtp3.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate3.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbyy3ActionPerformed

    private void cmbrtp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbrtp3ActionPerformed
        // TODO add your handling code here:
        if(cmbdd3.getSelectedIndex()==0||cmbmm3.getSelectedIndex()==0||cmbyy3.getSelectedIndex()==0||cmbrtp3.getSelectedIndex()==0){            
            txtnpdate3.setText("");
        }
        else{
       String date=payUpto2();
       int period=cmbrtp3.getSelectedIndex();
       String nextDueDate = nextDueDate(date,period);
       txtnpdate3.setText(nextDueDate);
        }
    }//GEN-LAST:event_cmbrtp3ActionPerformed
private void clear2(){
    txtregno3.setText("");
    txtincoff.setText("");
    cmbdd3.setSelectedIndex(0);
    cmbmm3.setSelectedIndex(0);
    cmbyy3.setSelectedIndex(0);
    txtpaydate3.setText("");
    txtincamt.setText("");
    cmbrtp3.setSelectedIndex(0);
    txtnpamt3.setText("");                
    txtnpdate3.setText("");
    cmbtpb3.setSelectedIndex(0);
    txtbrname3.setText("");
    txtcont3.setText("");
    txtadd3.setText("");
    txtregno3.setEditable(true);
    txtregno3.grabFocus();
    flaginc=false;
}
    private void btncancle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancle3ActionPerformed
        // TODO add your handling code here:
        clear2();
    }//GEN-LAST:event_btncancle3ActionPerformed

    private void cmbtpb3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtpb3ActionPerformed
        // TODO add your handling code here:
        if(cmbtpb3.getSelectedIndex()==0||cmbtpb3.getSelectedIndex()==3){
            txtbrname3.setEditable(false);
            txtcont3.setEditable(false);
            txtadd3.setEditable(false);
            txtcont3.setText("");
        }
        else{
            txtbrname3.setEditable(true);
            txtcont3.setEditable(true);
            txtadd3.setEditable(true);
            txtcont3.setText("+91");
        }
    }//GEN-LAST:event_cmbtpb3ActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VehicleRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VehicleRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VehicleRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VehicleRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new VehicleRegistration().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncancle1;
    private javax.swing.JButton btncancle2;
    private javax.swing.JButton btncancle3;
    private javax.swing.JButton btnhome1;
    private javax.swing.JButton btnhome2;
    private javax.swing.JButton btnhome3;
    private javax.swing.JButton btnsave1;
    private javax.swing.JButton btnsave2;
    private javax.swing.JButton btnsave3;
    private javax.swing.JComboBox cmbdd1;
    private javax.swing.JComboBox cmbdd2;
    private javax.swing.JComboBox cmbdd3;
    private javax.swing.JComboBox cmbmm1;
    private javax.swing.JComboBox cmbmm2;
    private javax.swing.JComboBox cmbmm3;
    private javax.swing.JComboBox cmbrtp1;
    private javax.swing.JComboBox cmbrtp2;
    private javax.swing.JComboBox cmbrtp3;
    private javax.swing.JComboBox cmbtpb1;
    private javax.swing.JComboBox cmbtpb2;
    private javax.swing.JComboBox cmbtpb3;
    private javax.swing.JComboBox cmbyy1;
    private javax.swing.JComboBox cmbyy2;
    private javax.swing.JComboBox cmbyy3;
    public static javax.swing.JLabel head1;
    private javax.swing.JLabel head2;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    public static javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JLayeredPane jLayeredPane3;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblvtd1;
    private javax.swing.JLabel lblvtd2;
    private javax.swing.JLabel lblvtd3;
    public static javax.swing.JTextField txtadd1;
    public static javax.swing.JTextField txtadd2;
    public static javax.swing.JTextField txtadd3;
    public static javax.swing.JTextField txtbrname1;
    public static javax.swing.JTextField txtbrname2;
    public static javax.swing.JTextField txtbrname3;
    public static javax.swing.JTextField txtcont1;
    public static javax.swing.JTextField txtcont2;
    public static javax.swing.JTextField txtcont3;
    public static javax.swing.JTextField txtfitamt;
    public static javax.swing.JTextField txtfitoff;
    public static javax.swing.JTextField txtincamt;
    public static javax.swing.JTextField txtincoff;
    public static javax.swing.JTextField txtnpamt1;
    public static javax.swing.JTextField txtnpamt2;
    public static javax.swing.JTextField txtnpamt3;
    public static javax.swing.JTextField txtnpdate1;
    public static javax.swing.JTextField txtnpdate2;
    public static javax.swing.JTextField txtnpdate3;
    public static javax.swing.JTextField txtpaydate1;
    public static javax.swing.JTextField txtpaydate2;
    public static javax.swing.JTextField txtpaydate3;
    public static javax.swing.JTextField txtregno;
    public static javax.swing.JTextField txtregno2;
    public static javax.swing.JTextField txtregno3;
    public static javax.swing.JTextField txttax;
    public static javax.swing.JTextField txttaxamt;
    // End of variables declaration//GEN-END:variables
}
