/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author ASIF
 */
public class StudentsFee extends javax.swing.JFrame {

    /**
     * Creates new form StudentsFee
     */
    private Statement stmt;
    private ResultSet rs;
    private int amt = 0;
    private int chamt = 0;
    private int regfee=0,da=0;
    private boolean flag2=false,flag1,adm2=false,smart2=false,sport2=false,pipul2=false,lib2=false,libf2=false,hostel2=false,exam2=false,schdev2=false,session2=false;
    private String admno,paymonth,paymonth1,paydate,monthly,admfee,smartfee,sportfee,pipulfee,libfee,libfine,hostelfee,exam1,schdevfee,sessionfee;
    private int Indices=1,totalamount=0,curmonth,oldmonth,totmonth;
    private int grandtotal,totalamt,total,tutfee,trans,tutamt,transfee,countmonth=0,admcountmonth,smartcountmonth,sportcountmonth,pipulcountmonth,libcountmonth,libfcountmonth,hostcountmonth,examcountmonth,schdevcountmonth,sessioncountmonth,tot1=0,tot2=0,tot3=0,tot4=0,tot5=0,tot6=0,tot7=0,tot8=0,tot9=0,tot10=0;
//    private String setyear="";
    //private Object[] loi ={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    private java.sql.Connection con;
    Object[] admobj,smartobj,sportobj,pipulobj,libobj,libfobj,hostobj,examination,schooldevfee,sessionobj;
    ArrayList<String> admlist,smartlist,sportlist,liblist,libflist,pipullist,hostlist,examlist,schdevlist,sessionlist;
    public StudentsFee() {
        initComponents();
        head1.setText(AdmissionOpen.arg);
        head2.setText(AdmissionOpen.arg1);
        cbreg.setVisible(false);
        cbadm.setVisible(false);
        cbtuit.setVisible(false);
        cbcomp.setVisible(false);
        cbelect.setVisible(false);
        cbsmart.setVisible(false);
        cbsport.setVisible(false);
        cbpupil.setVisible(false);
        cblib.setVisible(false);
        cblibfine.setVisible(false);
        cbtrans.setVisible(false);
        cbhostel.setVisible(false);
        cbschdev.setVisible(false);
        cbexam.setVisible(false);
        cbsession.setVisible(false);
        cbcaut.setVisible(false);
        lblregfee.setVisible(false);
        lbladmfee.setVisible(false);
        lblcaut.setVisible(false);
        lbltufee.setVisible(false);
        lblelectfee.setVisible(false);
        lblcompfee.setVisible(false);
        lblsmart.setVisible(false);
        lblsport.setVisible(false);
        lbllibfee.setVisible(false);
        lbllibfine.setVisible(false);
        lblpupil.setVisible(false);
        lbltransfee.setVisible(false);
        lblhostelfee.setVisible(false);
        lblschdevfee.setVisible(false);
        lblexamfee.setVisible(false);
        lblsessionfee.setVisible(false);
        try{
        con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
        }
        catch(SQLException xe){
            JOptionPane.showMessageDialog(rootPane, xe);
        }
        txtac.setBackground(Color.WHITE);
        txtacamt.setBackground(Color.WHITE);
        txtamt.setBackground(Color.WHITE);
        txtchamt.setBackground(Color.WHITE);
        txtchno.setBackground(Color.WHITE);
        txtbkname.setBackground(Color.WHITE);
        txtmisc.setBackground(Color.WHITE);
        enabled();
        selected();
        feepermonth();
//        int yearno=Integer.parseInt(NewJPanel.year);
//        int yearno1=yearno+1;
//        setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
//        txtroll.setText("HHA 2016-2017 / 009");
        jlist.setEnabled(false);
    }
    Object[] examination(String exam)
    {
        countmonth=0;
        char sdvf[]=exam.toCharArray();
                    char sdv[]=new char[3];
                    Object obj[]=new Object[12];
                    int k=0;
                    for(int i=1;i<sdvf.length;i++)
                    {
                        if(sdvf[i]!=' ')
                        {
                         if(sdvf[i]!=','&& i!=sdvf.length-1)
                        {
                            sdv[k++]=sdvf[i];
                        }
                         else
                        {
                            String st=String.valueOf(sdv);
                            obj[countmonth++]=st;
                            k=0;
                        }
                        }
                    }
                    Object[] obj1=new Object[countmonth];
                    System.arraycopy(obj, 0, obj1, 0, countmonth);
                    return obj1;
    }
private void fillData(){
    try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1="SELECT * FROM FEE_DETAILS WHERE CLASS='"+txtclass.getText()+"'";
                rs=stmt.executeQuery(str1);
                while(rs.next()){
//                    lblregfee.setText(rs.getString(2));
//                    lbladmfee.setText(rs.getString(3));
//                    lbltufee.setText(rs.getString(4));
//                    lblcompfee.setText(rs.getString(5));
//                    lblelectfee.setText(rs.getString(6));
//                    lblsmart.setText(rs.getString(7));
//                    lblsport.setText(rs.getString(8));
//                    lblpupil.setText(rs.getString(9));
//                    lbllibfee.setText(rs.getString(10));
//                    lbllibfine.setText(rs.getString(11));
////                    lbltransfee.setText(rs.getString(12));
//                    lblhostelfee.setText(rs.getString(13));
//                    lblschdevfee.setText(rs.getString(14));
//                    lblexamfee.setText(rs.getString(15));
//                    lblsessionfee.setText(rs.getString(16));
//                    lblcaut.setText(rs.getString(17));
                    String reg=rs.getString(2);
                    String adm=rs.getString(3);
                    admfee=adm.substring(adm.lastIndexOf("/")+1, adm.length());
                    
                    if(admfee.startsWith("["))
                    {
                        admobj=examination(admfee);
                        admcountmonth=countmonth;
                    }
                    String tut=rs.getString(4);
                    String comp=rs.getString(5);
                    String elect=rs.getString(6);
                    String smart=rs.getString(7);
                    smartfee=smart.substring(smart.lastIndexOf("/")+1, smart.length());
                    
                    if(smartfee.startsWith("["))
                    {
                        smartobj=examination(smartfee);
                        smartcountmonth=countmonth;
                    }
                    String sport=rs.getString(8);
                    sportfee=sport.substring(sport.lastIndexOf("/")+1, sport.length());
                    
                    if(sportfee.startsWith("["))
                    {
                        sportobj=examination(sportfee);
                        sportcountmonth=countmonth;
                    }
                    String pipul=rs.getString(9);
                    pipulfee=pipul.substring(pipul.lastIndexOf("/")+1, pipul.length());
                    
                    if(pipulfee.startsWith("["))
                    {
                        pipulobj=examination(pipulfee);
                        pipulcountmonth=countmonth;
                    }
                    String lib=rs.getString(10);
                    libfee=lib.substring(lib.lastIndexOf("/")+1, lib.length());
                    
                    if(libfee.startsWith("["))
                    {
                        libobj=examination(libfee);
                        libcountmonth=countmonth;
                    }
                    String libf=rs.getString(11);
                    libfine=libf.substring(libf.lastIndexOf("/")+1, libf.length());
                    
                    if(libfine.startsWith("["))
                    {
                        libfobj=examination(libfine);
                        libfcountmonth=countmonth;
                    }
                    String hostel=rs.getString(13);
                    hostelfee=hostel.substring(hostel.lastIndexOf("/")+1, hostel.length());
                    
                    if(hostelfee.startsWith("["))
                    {
                        hostobj=examination(hostelfee);
                        hostcountmonth=countmonth;
                    }
                    String schdev=rs.getString(14);
                    schdevfee=schdev.substring(schdev.lastIndexOf("/")+1, schdev.length());
                    
                    if(schdevfee.startsWith("["))
                    {
                        schooldevfee=examination(schdevfee);
                        schdevcountmonth=countmonth;
                    }
                    String exam=rs.getString(15);
                    exam1=exam.substring(exam.lastIndexOf("/")+1, exam.length());
                    if(exam1.startsWith("["))
                    {
                        examination = examination(exam1);
                        examcountmonth=countmonth;
                    }
                    String session=rs.getString(16);
                    sessionfee=schdev.substring(session.lastIndexOf("/")+1, session.length());
                    
                    if(sessionfee.startsWith("["))
                    {
                        sessionobj=examination(sessionfee);
                        sessioncountmonth=countmonth;
                    }
                    String caut=rs.getString(17);
                    lblregfee.setText(rs.getString(2).substring(0, reg.lastIndexOf("/")));
                    lbladmfee.setText(rs.getString(3).substring(0, adm.lastIndexOf("/")));
                    lbltufee.setText(rs.getString(4).substring(0, tut.lastIndexOf("/")));
                    lblcompfee.setText(rs.getString(5).substring(0, comp.lastIndexOf("/")));
                    lblelectfee.setText(rs.getString(6).substring(0, elect.lastIndexOf("/")));
                    lblsmart.setText(rs.getString(7).substring(0, smart.lastIndexOf("/")));
                    lblsport.setText(rs.getString(8).substring(0, sport.lastIndexOf("/")));
                    lblpupil.setText(rs.getString(9).substring(0, pipul.lastIndexOf("/")));
                    lbllibfee.setText(rs.getString(10).substring(0, lib.lastIndexOf("/")));
                    lbllibfine.setText(rs.getString(11).substring(0, libf.lastIndexOf("/")));
                    //lbltransfee.setText(rs.getString(12));
                    lblhostelfee.setText(rs.getString(13).substring(0, hostel.lastIndexOf("/")));
                    lblschdevfee.setText(rs.getString(14).substring(0, schdev.lastIndexOf("/")));
                    lblexamfee.setText(rs.getString(15).substring(0, exam.lastIndexOf("/")));
                    lblsessionfee.setText(rs.getString(16).substring(0, session.lastIndexOf("/")));
                    lblcaut.setText(rs.getString(17).substring(0, caut.lastIndexOf("/")));
                }
                stmt.close();
                rs.close();
//                con.close();
                } catch (SQLException ex) {
                    lblregfee.setText("0");
                    lbladmfee.setText("0");
                    lbltufee.setText("0");
                    lblcompfee.setText("0");
                    lblelectfee.setText("0");
                    lblsmart.setText("0");
                    lblsport.setText("0");
                    lblpupil.setText("0");
                    lbllibfee.setText("0");
                    lbllibfine.setText("0");
//                    lbltransfee.setText("0");
                    lblhostelfee.setText("0");
                    lblschdevfee.setText("0");
                    lblexamfee.setText("0");
                    lblsessionfee.setText("0");
                    lblcaut.setText("0");
                JOptionPane.showMessageDialog(rootPane, ex);
            }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        txttpa = new javax.swing.JTextField();
        txtda = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        rbcash = new javax.swing.JRadioButton();
        rbcheque = new javax.swing.JRadioButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        txtclass = new javax.swing.JTextField();
        txtroll = new javax.swing.JTextField();
        txtsection = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        txttcac = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        txttchac = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        txtamt = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        txtchamt = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        txtac = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtbkname = new javax.swing.JTextField();
        btnsave = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        btnpws = new javax.swing.JButton();
        btnprint = new javax.swing.JButton();
        cmbdd = new javax.swing.JComboBox();
        cmbmm = new javax.swing.JComboBox();
        cmbyy = new javax.swing.JComboBox();
        lblslno = new javax.swing.JLabel();
        cbp = new javax.swing.JCheckBox();
        cbf = new javax.swing.JCheckBox();
        btnsearch = new javax.swing.JButton();
        btncancle = new javax.swing.JButton();
        lblslno1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbcomp = new javax.swing.JCheckBox();
        cbtuit = new javax.swing.JCheckBox();
        cbadm = new javax.swing.JCheckBox();
        cbelect = new javax.swing.JCheckBox();
        cbsport = new javax.swing.JCheckBox();
        cblib = new javax.swing.JCheckBox();
        cbsmart = new javax.swing.JCheckBox();
        cbpupil = new javax.swing.JCheckBox();
        cbreg = new javax.swing.JCheckBox();
        cblibfine = new javax.swing.JCheckBox();
        cbtrans = new javax.swing.JCheckBox();
        cbhostel = new javax.swing.JCheckBox();
        cbschdev = new javax.swing.JCheckBox();
        cbexam = new javax.swing.JCheckBox();
        cbsession = new javax.swing.JCheckBox();
        lblsessionfee = new javax.swing.JLabel();
        lblregfee = new javax.swing.JLabel();
        lbladmfee = new javax.swing.JLabel();
        lbltufee = new javax.swing.JLabel();
        lblcompfee = new javax.swing.JLabel();
        lblelectfee = new javax.swing.JLabel();
        lblsmart = new javax.swing.JLabel();
        lblsport = new javax.swing.JLabel();
        lblpupil = new javax.swing.JLabel();
        lbllibfee = new javax.swing.JLabel();
        lbllibfine = new javax.swing.JLabel();
        lbltransfee = new javax.swing.JLabel();
        lblhostelfee = new javax.swing.JLabel();
        lblschdevfee = new javax.swing.JLabel();
        lblexamfee = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        txtselect = new javax.swing.JTextField();
        cbcaut = new javax.swing.JCheckBox();
        lblcaut = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        txtchno = new javax.swing.JTextField();
        jcbac = new javax.swing.JCheckBox();
        txtacamt = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtmisc = new javax.swing.JTextField();
        cbmisc = new javax.swing.JCheckBox();
        jLabel38 = new javax.swing.JLabel();
        txtroll1 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtvill = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jlist = new javax.swing.JList();
        jPanel3 = new javax.swing.JPanel();
        head1 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        head2 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        txtcurd = new javax.swing.JTextField();
        lblview2 = new javax.swing.JLabel();
        lblview1 = new javax.swing.JLabel();

        buttonGroup1.add(cbf);
        buttonGroup1.add(cbp);

        buttonGroup2.add(rbcash);
        buttonGroup2.add(rbcheque);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Student Fee");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(217, 227, 251));
        jPanel1.setMinimumSize(new java.awt.Dimension(1380, 1167));
        jPanel1.setPreferredSize(new java.awt.Dimension(1345, 1227));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txttpa.setEditable(false);
        txttpa.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txttpa, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 550, 110, 25));

        txtda.setEditable(false);
        txtda.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtda, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 430, 110, 25));

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel30.setText("Total Payable Amount:");
        jPanel1.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 550, 183, 25));

        rbcash.setBackground(new java.awt.Color(255, 255, 255));
        rbcash.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        rbcash.setText("Cash Payment");
        rbcash.setNextFocusableComponent(rbcheque);
        rbcash.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbcashItemStateChanged(evt);
            }
        });
        rbcash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbcashActionPerformed(evt);
            }
        });
        jPanel1.add(rbcash, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 900, -1, -1));

        rbcheque.setBackground(new java.awt.Color(255, 255, 255));
        rbcheque.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        rbcheque.setText("Cheque Payment");
        rbcheque.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbchequeItemStateChanged(evt);
            }
        });
        rbcheque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbchequeActionPerformed(evt);
            }
        });
        jPanel1.add(rbcheque, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 900, -1, -1));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel26.setText("Enter Admission No.");
        jPanel1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, -1, 25));

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel27.setText("Class:");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, 50, 25));

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel29.setText("Previous Dues:");
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, 120, 25));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel23.setText("Student Name:");
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 120, 25));

        txtname.setEditable(false);
        txtname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtnameFocusLost(evt);
            }
        });
        jPanel1.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 350, 200, 25));

        txtclass.setEditable(false);
        txtclass.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtclass, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 270, 110, 25));

        txtroll.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtroll.setToolTipText("");
        txtroll.setNextFocusableComponent(btnsearch);
        txtroll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrollActionPerformed(evt);
            }
        });
        txtroll.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtrollKeyReleased(evt);
            }
        });
        jPanel1.add(txtroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 190, 140, 25));

        txtsection.setEditable(false);
        txtsection.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtsection, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, 110, 25));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel28.setText("Section:");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 70, 25));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel36.setText("Total Cash Amount Collected:");
        jPanel1.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 1030, -1, 25));

        txttcac.setEditable(false);
        txttcac.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txttcac, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 1030, 120, 25));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel37.setText("Total Cheque Amount Collected:");
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 1070, -1, 25));

        txttchac.setEditable(false);
        txttchac.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txttchac, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 1070, 120, 25));

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel31.setText("Amount:");
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 950, -1, 20));

        txtamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtamt.setToolTipText("Use Only Digit(0-9)");
        txtamt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtamtActionPerformed(evt);
            }
        });
        txtamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtamtFocusLost(evt);
            }
        });
        jPanel1.add(txtamt, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 950, 110, 25));

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel32.setText("Cheque Amount:");
        jPanel1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 950, -1, 20));

        txtchamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtchamt.setToolTipText("Use Only Digit(0-9)");
        txtchamt.setNextFocusableComponent(txtchno);
        txtchamt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtchamtActionPerformed(evt);
            }
        });
        txtchamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtchamtFocusLost(evt);
            }
        });
        jPanel1.add(txtchamt, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 950, 110, 25));

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel33.setText("Cheque No:");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 990, -1, 20));

        txtac.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtac.setToolTipText("Use Only Digit(0-9)");
        txtac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtacActionPerformed(evt);
            }
        });
        txtac.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtacFocusLost(evt);
            }
        });
        jPanel1.add(txtac, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 760, 180, 25));

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel34.setText("Cheque Date:");
        jPanel1.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 1030, -1, 20));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel35.setText("Bank Name:");
        jPanel1.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 1070, -1, 20));

        txtbkname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtbkname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtbkname.setNextFocusableComponent(btnsave);
        txtbkname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbknameActionPerformed(evt);
            }
        });
        txtbkname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtbknameFocusLost(evt);
            }
        });
        jPanel1.add(txtbkname, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1070, 200, 25));

        btnsave.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnsave.setText("Save");
        btnsave.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave.setNextFocusableComponent(btnclear);
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        jPanel1.add(btnsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 1130, -1, -1));

        btnclear.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnclear.setText("Clear");
        btnclear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnclear.setNextFocusableComponent(btncancle);
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        jPanel1.add(btnclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 1130, -1, -1));

        btnpws.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnpws.setText("Print With SMS");
        btnpws.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnpws.setNextFocusableComponent(btnprint);
        jPanel1.add(btnpws, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 1130, -1, -1));

        btnprint.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnprint.setText("Print");
        btnprint.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        jPanel1.add(btnprint, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 1130, -1, -1));

        cmbdd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbdd.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cmbdd.setNextFocusableComponent(cmbmm);
        jPanel1.add(cmbdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1030, -1, -1));

        cmbmm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbmm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));
        cmbmm.setNextFocusableComponent(cmbyy);
        jPanel1.add(cmbmm, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 1030, -1, -1));

        cmbyy.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbyy.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YY", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" }));
        cmbyy.setNextFocusableComponent(txtbkname);
        jPanel1.add(cmbyy, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1030, -1, -1));

        lblslno.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblslno.setText(" MLC/F 001");
        jPanel1.add(lblslno, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 112, 140, 27));

        cbp.setBackground(new java.awt.Color(255, 255, 255));
        cbp.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        cbp.setText("Part Payment");
        cbp.setNextFocusableComponent(rbcash);
        cbp.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbpItemStateChanged(evt);
            }
        });
        cbp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpActionPerformed(evt);
            }
        });
        jPanel1.add(cbp, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 800, -1, -1));

        cbf.setBackground(new java.awt.Color(255, 255, 255));
        cbf.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        cbf.setText("Full Payment");
        cbf.setNextFocusableComponent(cbp);
        cbf.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbfItemStateChanged(evt);
            }
        });
        cbf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbfActionPerformed(evt);
            }
        });
        jPanel1.add(cbf, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 800, -1, -1));

        btnsearch.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnsearch.setText("Search");
        btnsearch.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, -1, -1));

        btncancle.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancle.setText("Home");
        btncancle.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncancle.setNextFocusableComponent(btnpws);
        btncancle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancleActionPerformed(evt);
            }
        });
        jPanel1.add(btncancle, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 1130, -1, -1));

        lblslno1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblslno1.setText("SL_NO.");
        lblslno1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(lblslno1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 112, 210, 27));

        jLabel5.setBackground(new java.awt.Color(204, 51, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setOpaque(true);
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 1190, 1380, 37));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 36)); // NOI18N
        jLabel1.setText("Student's Fee Collection Form");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 115, 430, 40));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setOpaque(true);
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 155, 465, 2));

        cbcomp.setBackground(new java.awt.Color(217, 227, 251));
        cbcomp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbcomp.setText("Computer Fee");
        cbcomp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbcompActionPerformed(evt);
            }
        });
        jPanel1.add(cbcomp, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 350, -1, -1));

        cbtuit.setBackground(new java.awt.Color(217, 227, 251));
        cbtuit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbtuit.setText("Tuition Fee");
        cbtuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbtuitActionPerformed(evt);
            }
        });
        jPanel1.add(cbtuit, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 310, -1, -1));

        cbadm.setBackground(new java.awt.Color(217, 227, 251));
        cbadm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbadm.setText("Admission/Re-Admission Fee");
        cbadm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbadmActionPerformed(evt);
            }
        });
        jPanel1.add(cbadm, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 230, -1, -1));

        cbelect.setBackground(new java.awt.Color(217, 227, 251));
        cbelect.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbelect.setText("Electric/Generator Charge");
        cbelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbelectActionPerformed(evt);
            }
        });
        jPanel1.add(cbelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 390, -1, -1));

        cbsport.setBackground(new java.awt.Color(217, 227, 251));
        cbsport.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsport.setText("Sports Fee");
        cbsport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsportActionPerformed(evt);
            }
        });
        jPanel1.add(cbsport, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 470, -1, -1));

        cblib.setBackground(new java.awt.Color(217, 227, 251));
        cblib.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cblib.setText("Library Fee");
        cblib.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cblibActionPerformed(evt);
            }
        });
        jPanel1.add(cblib, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 230, -1, -1));

        cbsmart.setBackground(new java.awt.Color(217, 227, 251));
        cbsmart.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsmart.setText("Smart Class Fee");
        cbsmart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsmartActionPerformed(evt);
            }
        });
        jPanel1.add(cbsmart, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 430, -1, -1));

        cbpupil.setBackground(new java.awt.Color(217, 227, 251));
        cbpupil.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbpupil.setText("Pupil Fund");
        cbpupil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpupilActionPerformed(evt);
            }
        });
        jPanel1.add(cbpupil, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 190, -1, -1));

        cbreg.setBackground(new java.awt.Color(217, 227, 251));
        cbreg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbreg.setText("Registration Fee");
        cbreg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbregActionPerformed(evt);
            }
        });
        jPanel1.add(cbreg, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, 125, -1));

        cblibfine.setBackground(new java.awt.Color(217, 227, 251));
        cblibfine.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cblibfine.setText("Library Fine");
        cblibfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cblibfineActionPerformed(evt);
            }
        });
        jPanel1.add(cblibfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 270, -1, -1));

        cbtrans.setBackground(new java.awt.Color(217, 227, 251));
        cbtrans.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbtrans.setText("Transport Fee");
        cbtrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbtransActionPerformed(evt);
            }
        });
        jPanel1.add(cbtrans, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 310, -1, -1));

        cbhostel.setBackground(new java.awt.Color(217, 227, 251));
        cbhostel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbhostel.setText("Hostel Fee");
        cbhostel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbhostelActionPerformed(evt);
            }
        });
        jPanel1.add(cbhostel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 350, -1, -1));

        cbschdev.setBackground(new java.awt.Color(217, 227, 251));
        cbschdev.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbschdev.setText("School Development Fee");
        cbschdev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbschdevActionPerformed(evt);
            }
        });
        jPanel1.add(cbschdev, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 390, -1, -1));

        cbexam.setBackground(new java.awt.Color(217, 227, 251));
        cbexam.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbexam.setText("Examination Fee");
        cbexam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbexamActionPerformed(evt);
            }
        });
        jPanel1.add(cbexam, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 430, -1, -1));

        cbsession.setBackground(new java.awt.Color(217, 227, 251));
        cbsession.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsession.setText("Session Fee");
        cbsession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsessionActionPerformed(evt);
            }
        });
        jPanel1.add(cbsession, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 470, -1, -1));

        lblsessionfee.setBackground(new java.awt.Color(255, 255, 255));
        lblsessionfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsessionfee.setOpaque(true);
        jPanel1.add(lblsessionfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 470, 70, 23));

        lblregfee.setBackground(new java.awt.Color(255, 255, 255));
        lblregfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblregfee.setOpaque(true);
        jPanel1.add(lblregfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 190, 70, 23));

        lbladmfee.setBackground(new java.awt.Color(255, 255, 255));
        lbladmfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbladmfee.setOpaque(true);
        jPanel1.add(lbladmfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 230, 70, 23));

        lbltufee.setBackground(new java.awt.Color(255, 255, 255));
        lbltufee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbltufee.setOpaque(true);
        jPanel1.add(lbltufee, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 310, 70, 23));

        lblcompfee.setBackground(new java.awt.Color(255, 255, 255));
        lblcompfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblcompfee.setOpaque(true);
        jPanel1.add(lblcompfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 350, 70, 23));

        lblelectfee.setBackground(new java.awt.Color(255, 255, 255));
        lblelectfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblelectfee.setOpaque(true);
        jPanel1.add(lblelectfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 390, 70, 23));

        lblsmart.setBackground(new java.awt.Color(255, 255, 255));
        lblsmart.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsmart.setOpaque(true);
        jPanel1.add(lblsmart, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 430, 70, 23));

        lblsport.setBackground(new java.awt.Color(255, 255, 255));
        lblsport.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsport.setOpaque(true);
        jPanel1.add(lblsport, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 470, 70, 23));

        lblpupil.setBackground(new java.awt.Color(255, 255, 255));
        lblpupil.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblpupil.setOpaque(true);
        jPanel1.add(lblpupil, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 190, 70, 23));

        lbllibfee.setBackground(new java.awt.Color(255, 255, 255));
        lbllibfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbllibfee.setOpaque(true);
        jPanel1.add(lbllibfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 230, 70, 23));

        lbllibfine.setBackground(new java.awt.Color(255, 255, 255));
        lbllibfine.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbllibfine.setOpaque(true);
        jPanel1.add(lbllibfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 270, 70, 23));

        lbltransfee.setBackground(new java.awt.Color(255, 255, 255));
        lbltransfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbltransfee.setOpaque(true);
        jPanel1.add(lbltransfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 310, 70, 23));

        lblhostelfee.setBackground(new java.awt.Color(255, 255, 255));
        lblhostelfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblhostelfee.setOpaque(true);
        jPanel1.add(lblhostelfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 350, 70, 23));

        lblschdevfee.setBackground(new java.awt.Color(255, 255, 255));
        lblschdevfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblschdevfee.setOpaque(true);
        jPanel1.add(lblschdevfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 390, 70, 23));

        lblexamfee.setBackground(new java.awt.Color(255, 255, 255));
        lblexamfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblexamfee.setOpaque(true);
        jPanel1.add(lblexamfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 430, 70, 23));

        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel41.setText("Enter Account Number:");
        jPanel1.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 760, 190, 25));

        txtselect.setEditable(false);
        txtselect.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtselect, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 510, 110, 25));

        cbcaut.setBackground(new java.awt.Color(217, 227, 251));
        cbcaut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbcaut.setText("Caution Money(Refundable)");
        cbcaut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbcautActionPerformed(evt);
            }
        });
        jPanel1.add(cbcaut, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 270, -1, -1));

        lblcaut.setBackground(new java.awt.Color(255, 255, 255));
        lblcaut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblcaut.setOpaque(true);
        jPanel1.add(lblcaut, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 270, 70, 23));

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel42.setText("Selected Month's Amount:");
        jPanel1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 510, 210, 25));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel43.setText("Select Month:");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 590, 110, 25));

        txtchno.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtchno.setToolTipText("Use Character(a to z,A to Z) or Digit(0-9)");
        txtchno.setNextFocusableComponent(cmbdd);
        txtchno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtchnoActionPerformed(evt);
            }
        });
        txtchno.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtchnoFocusLost(evt);
            }
        });
        jPanel1.add(txtchno, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 990, 220, 25));

        jcbac.setBackground(new java.awt.Color(255, 255, 255));
        jcbac.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jcbac.setText("Account Payment");
        jcbac.setNextFocusableComponent(cbf);
        jcbac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbacActionPerformed(evt);
            }
        });
        jPanel1.add(jcbac, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 710, 130, -1));

        txtacamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtacamt.setToolTipText("Use Only Digit(0-9)");
        txtacamt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtacamtActionPerformed(evt);
            }
        });
        txtacamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtacamtFocusLost(evt);
            }
        });
        jPanel1.add(txtacamt, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 800, 110, 25));

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel44.setText("Amount:");
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 800, -1, 25));

        txtmisc.setEditable(false);
        txtmisc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmisc.setToolTipText("Use Only Digit(0-9)");
        txtmisc.setNextFocusableComponent(jcbac);
        txtmisc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtmiscMouseClicked(evt);
            }
        });
        txtmisc.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtmiscFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmiscFocusLost(evt);
            }
        });
        jPanel1.add(txtmisc, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 510, 110, 25));

        cbmisc.setBackground(new java.awt.Color(217, 227, 251));
        cbmisc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbmisc.setText("Late Fine");
        cbmisc.setNextFocusableComponent(txtmisc);
        cbmisc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbmiscActionPerformed(evt);
            }
        });
        jPanel1.add(cbmisc, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 510, -1, -1));

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel38.setText("Roll No.");
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, -1, 25));

        txtroll1.setEditable(false);
        txtroll1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtroll1.setToolTipText("Use Only Digit(0-9)");
        txtroll1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtroll1ActionPerformed(evt);
            }
        });
        jPanel1.add(txtroll1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 230, 110, 25));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel24.setText("Village :");
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 70, 25));

        txtvill.setEditable(false);
        txtvill.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtvill.setToolTipText("Use Only Character (a-z, A-Z)");
        txtvill.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtvillFocusLost(evt);
            }
        });
        jPanel1.add(txtvill, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 390, 160, 25));

        jlist.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jlist.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jlist.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jlistValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(jlist);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 590, 80, 80));

        jPanel3.setBackground(new java.awt.Color(204, 51, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        head1.setBackground(new java.awt.Color(204, 51, 0));
        head1.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        head1.setForeground(new java.awt.Color(255, 255, 0));
        head1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head1.setText("Holistic Heritage Academy");
        head1.setOpaque(true);
        jPanel3.add(head1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 610, -1));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 0));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("(An English Medium School)");
        jLabel40.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 180, 20));

        head2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        head2.setForeground(new java.awt.Color(255, 255, 0));
        head2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head2.setText("\"Shanti Niketan\" Pali Road, Dehri-On-Sone, Rohtas (Bihar) Pin Code - 821307");
        head2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel3.add(head2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 820, 25));

        jLabel48.setBackground(new java.awt.Color(255, 255, 255));
        jLabel48.setOpaque(true);
        jPanel3.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 56, 585, 2));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1420, 110));

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel45.setText("Current Dues:");
        jPanel1.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 470, 140, 25));

        txtcurd.setEditable(false);
        txtcurd.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtcurd, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, 110, 25));

        lblview2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblview2.setForeground(new java.awt.Color(51, 51, 255));
        lblview2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblview2.setText("<html> <u> View </u> <font color=\"RED\"> </font>");
        lblview2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblview2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblview2MouseClicked(evt);
            }
        });
        jPanel1.add(lblview2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 550, 30, 20));

        lblview1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblview1.setForeground(new java.awt.Color(51, 51, 255));
        lblview1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblview1.setText("<html> <u> View </u> <font color=\"RED\"> </font>");
        lblview1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblview1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblview1MouseClicked(evt);
            }
        });
        jPanel1.add(lblview1, new org.netbeans.lib.awtextra.AbsoluteConstraints(622, 512, 30, 20));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selected() {
        jcbac.setEnabled(false);
        txtac.setEditable(false);
        txtacamt.setEditable(false);
        rbcash.setEnabled(false);
        rbcheque.setEnabled(false);
        txtamt.setEditable(false);
        txtchamt.setEditable(false);
        txtchno.setEditable(false);
        cmbdd.setEnabled(false);
        cmbmm.setEnabled(false);
        cmbyy.setEnabled(false);
        txtbkname.setEditable(false);
        cbf.setEnabled(false);
        cbp.setEnabled(false);
    }

    private void feepermonth() {
        try {
//            java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
//            String str1 = "SELECT COUNT(*) FROM STUDENT_FEE";
//            rs = stmt.executeQuery(str1);
//            rs.next();
//            int rowCount = rs.getInt(1);
//            ++rowCount;
//            String str3 = String.valueOf(rowCount);
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT SL_NO FROM STUDENT_FEE ORDER BY SL_NO ASC";
            rs = stmt.executeQuery(str1);
            rs.last();
            String slno1 = rs.getString(1);//HHA/F 001
            String serial1=slno1.substring(6,slno1.length());
            int a = Integer.parseInt(serial1);
            ++a;
            String str3 = String.valueOf(a);
            if (a < 10) {
                lblslno.setText(" HHA/F 00".concat(str3));
            } else if (a > 9 && a < 100) {
                lblslno.setText(" HHA/F 0".concat(str3));
            } else {
                lblslno.setText(" HHA/F ".concat(str3));
            }
            amountCollectedValue();
        } catch (SQLException e) {
            lblslno.setText(" HHA/F 001");
            //JOptionPane.showMessageDialog(this, e.getMessage(), "StudentFee", 0);
        }
    }
    private void txtnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtnameFocusLost
        // TODO add your handling code here:
        if (txtname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtname.setText("");
        }
        if (txtname.getText().length() > 30) {
            txtname.setText("");
        }
    }//GEN-LAST:event_txtnameFocusLost
private void enabled(){
    if(flag2==true){
        //cbreg.setEnabled(true);
        //cbadm.setEnabled(true);
        cbtuit.setEnabled(true);
        cbcomp.setEnabled(true);
        cbelect.setEnabled(true);
        //cbsmart.setEnabled(true);
        cbsport.setEnabled(true);
        //cbpupil.setEnabled(true);
        //cblib.setEnabled(true);
        //cblibfine.setEnabled(true);
        cbtrans.setEnabled(true);
        cbhostel.setEnabled(true);
        //cbschdev.setEnabled(true);
        cbexam.setEnabled(true);
        //cbsession.setEnabled(true);
        //cbcaut.setEnabled(true);
        cbmisc.setEnabled(true);
        txtmisc.setText("0");
    }
    else{
        cbreg.setEnabled(false);
        cbadm.setEnabled(false);
        cbtuit.setEnabled(false);
        cbcomp.setEnabled(false);
        cbelect.setEnabled(false);
        cbsmart.setEnabled(false);
        cbsport.setEnabled(false);
        cbpupil.setEnabled(false);
        cblib.setEnabled(false);
        cblibfine.setEnabled(false);
        cbtrans.setEnabled(false);
        cbhostel.setEnabled(false);
        cbschdev.setEnabled(false);
        cbexam.setEnabled(false);
        cbsession.setEnabled(false);
        cbcaut.setEnabled(false);
        jcbac.setEnabled(false);
        cbf.setEnabled(false);
        cbp.setEnabled(false);
        rbcash.setEnabled(false);
        rbcheque.setEnabled(false);
        cbmisc.setEnabled(false);
        txtmisc.setText("");
    }    
}    
private void totalPaymentMade(int k){                       
                Calendar cal = Calendar.getInstance();        
                String curdate = String.format("%1$tm", cal);
                String month=paymonth;                
                String dateFormat;
                String s="";
                int[] admf=new int[admcountmonth];int[] smartf=new int[smartcountmonth];int[] sportf=new int[sportcountmonth];int[] pipulf=new int[pipulcountmonth];int[] lib=new int[libcountmonth];int[] libf=new int[libfcountmonth];int[] hostf=new int[hostcountmonth];int[] examfee=new int[examcountmonth];int[] schdev1=new int[schdevcountmonth];int[] sessionf=new int[sessioncountmonth];                
                admlist=new ArrayList<>();smartlist=new ArrayList<>();sportlist=new ArrayList<>();pipullist=new ArrayList<>();liblist=new ArrayList<>();libflist=new ArrayList<>();hostlist=new ArrayList<>();examlist=new ArrayList<>();schdevlist=new ArrayList<>();sessionlist=new ArrayList<>();
                tot1=0;tot2=0;tot3=0;tot4=0;tot5=0;tot6=0;tot7=0;tot8=0;tot9=0;tot10=0;
                if(flag1==true){
                if(month.length()==7){
                 month=month.substring(4,7);
                 dateFormat = NewAdmPanel.dateFormat(month);
                }
                else{
                    dateFormat = NewAdmPanel.dateFormat(month);
                }
                }
                else{
                    dateFormat=paymonth1;
                }
                String olddate=dateFormat;
                totmonth=Integer.parseInt(monthSub(curdate,olddate));                                            
                tutamt=Integer.parseInt(lbltufee.getText())*totmonth;  
                transfee=Integer.parseInt(lbltransfee.getText())*totmonth;
                if(!(admfee.equals("Select"))){                                    
                    for(int i=0;i<admcountmonth;i++)                    
                        admf[i]=Integer.parseInt(NewAdmPanel.dateFormat(admobj[i].toString()));                    
                }
                if(!(smartfee.equals("Select"))){
                    
                    for(int i=0;i<smartcountmonth;i++)                    
                        smartf[i]=Integer.parseInt(NewAdmPanel.dateFormat(smartobj[i].toString()));                    
                }
                if(!(sportfee.equals("Select"))){                    
                    for(int i=0;i<sportcountmonth;i++)                    
                        sportf[i]=Integer.parseInt(NewAdmPanel.dateFormat(sportobj[i].toString()));                    
                }
                if(!(pipulfee.equals("Select"))){                    
                    for(int i=0;i<pipulcountmonth;i++)                    
                        pipulf[i]=Integer.parseInt(NewAdmPanel.dateFormat(pipulobj[i].toString()));                    
                }
                if(!(libfee.equals("Select"))){                    
                    for(int i=0;i<libcountmonth;i++)                    
                        lib[i]=Integer.parseInt(NewAdmPanel.dateFormat(libobj[i].toString()));                    
                }
                if(!(libfine.equals("Select"))){                    
                    for(int i=0;i<libfcountmonth;i++)                    
                        libf[i]=Integer.parseInt(NewAdmPanel.dateFormat(libfobj[i].toString()));                    
                }
                if(!(hostelfee.equals("Select"))){                    
                    for(int i=0;i<hostcountmonth;i++)                    
                        hostf[i]=Integer.parseInt(NewAdmPanel.dateFormat(hostobj[i].toString()));                    
                }                              
                if(!(exam1.equals("Select"))){                    
                    for(int i=0;i<examcountmonth;i++)                    
                        examfee[i]=Integer.parseInt(NewAdmPanel.dateFormat(examination[i].toString()));                    
                }
                if(!(schdevfee.equals("Select"))){                    
                    for(int i=0;i<schdevcountmonth;i++)                    
                        schdev1[i]=Integer.parseInt(NewAdmPanel.dateFormat(schooldevfee[i].toString()));                   
                }
                if(!(sessionfee.equals("Select"))){                    
                    for(int i=0;i<sessioncountmonth;i++)                    
                        sessionf[i]=Integer.parseInt(NewAdmPanel.dateFormat(sessionobj[i].toString()));                    
                }         
                oldmonth=Integer.parseInt(olddate);
                curmonth=Integer.parseInt(curdate);                                                
                grandtotal=tutamt+transfee+da;
                if(curmonth<oldmonth){
                    for(int i=0;i<admcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(admf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbladmfee.getText());
                         tot1=tot1+Integer.parseInt(lbladmfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         admlist.add(NewAdmPanel.date(s));
                       adm2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<admcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(admf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbladmfee.getText());
                       tot1=tot1+Integer.parseInt(lbladmfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         admlist.add(NewAdmPanel.date(s));
                       adm2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<smartcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(smartf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsmart.getText());
                       tot2=tot2+Integer.parseInt(lblsmart.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         smartlist.add(NewAdmPanel.date(s));
                       smart2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<smartcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(smartf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsmart.getText());
                       tot2=tot2+Integer.parseInt(lblsmart.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         smartlist.add(NewAdmPanel.date(s));
                       smart2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<sportcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(sportf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsport.getText());
                       tot3=tot3+Integer.parseInt(lblsport.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sportlist.add(NewAdmPanel.date(s));
                       sport2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<sportcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(examfee[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsport.getText());
                       tot3=tot3+Integer.parseInt(lblsport.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sportlist.add(NewAdmPanel.date(s));
                       sport2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<pipulcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(pipulf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblpupil.getText());
                       tot4=tot4+Integer.parseInt(lblpupil.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         pipullist.add(NewAdmPanel.date(s));
                       pipul2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<pipulcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(pipulf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblpupil.getText());
                       tot4=tot4+Integer.parseInt(lblpupil.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         pipullist.add(NewAdmPanel.date(s));
                       pipul2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<libcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(lib[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfee.getText());
                       tot5=tot5+Integer.parseInt(lbllibfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         liblist.add(NewAdmPanel.date(s));
                       lib2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<libcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(lib[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfee.getText());
                       tot5=tot5+Integer.parseInt(lbllibfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         liblist.add(NewAdmPanel.date(s));
                       lib2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<libfcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(libf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfine.getText());
                       tot6=tot6+Integer.parseInt(lbllibfine.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         libflist.add(NewAdmPanel.date(s));
                       libf2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<libfcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(libf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfine.getText());
                       tot6=tot6+Integer.parseInt(lbllibfine.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         libflist.add(NewAdmPanel.date(s));
                       libf2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<hostcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(hostf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblhostelfee.getText());
                       tot7=tot7+Integer.parseInt(lblhostelfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         hostlist.add(NewAdmPanel.date(s));
                       hostel2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<hostcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(hostf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblhostelfee.getText());
                       tot7=tot7+Integer.parseInt(lblhostelfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         hostlist.add(NewAdmPanel.date(s));
                       hostel2=true;                      
                    }
                    }
                    }                    
                    for(int i=0;i<examcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(examfee[i]==j){                       
                       grandtotal+=Integer.parseInt(lblexamfee.getText());
                       tot8=tot8+Integer.parseInt(lblexamfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         examlist.add(NewAdmPanel.date(s));
                       exam2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<examcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(examfee[i]==j){                       
                       grandtotal+=Integer.parseInt(lblexamfee.getText());
                       tot8=tot8+Integer.parseInt(lblexamfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         examlist.add(NewAdmPanel.date(s));
                       exam2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<schdevcountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                    if(schdev1[i]==j){
                        grandtotal+=Integer.parseInt(lblschdevfee.getText());
                        tot9=tot9+Integer.parseInt(lblschdevfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         schdevlist.add(NewAdmPanel.date(s));
                        schdev2=true;                        
                    }
                    
                        }
                    }
                    for(int i=0;i<schdevcountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                    if(schdev1[i]==j){
                        grandtotal+=Integer.parseInt(lblschdevfee.getText());
                        tot9=tot9+Integer.parseInt(lblschdevfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         schdevlist.add(NewAdmPanel.date(s));
                        schdev2=true;                        
                    }   
                    }
                    }
                    for(int i=0;i<sessioncountmonth;i++)
                    {
                    for(int j=oldmonth+1;j<=12;j++)
                    {
                        if(sessionf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsessionfee.getText());
                       tot10=tot10+Integer.parseInt(lblsessionfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sessionlist.add(NewAdmPanel.date(s));
                       session2=true;                      
                    }
                    }
                    }
                    for(int i=0;i<sessioncountmonth;i++)
                    {
                    for(int j=1; j<=curmonth; j++)
                    {
                     if(sessionf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsessionfee.getText());
                       tot10=tot10+Integer.parseInt(lblsessionfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sessionlist.add(NewAdmPanel.date(s));
                       session2=true;                      
                    }
                    }
                    }
                    }
                else
                {
                    for(int i=0;i<admcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(admf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbladmfee.getText());
                       tot1=tot1+Integer.parseInt(lbladmfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         admlist.add(NewAdmPanel.date(s));
                       adm2=true;                      
                    }
                    }
                    }                    
                    for(int i=0;i<smartcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(smartf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsmart.getText());
                       tot2=tot2+Integer.parseInt(lblsmart.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         smartlist.add(NewAdmPanel.date(s));
                       smart2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<sportcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(examfee[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsport.getText());
                       tot3=tot3+Integer.parseInt(lblsport.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sportlist.add(NewAdmPanel.date(s));
                       sport2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<pipulcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(pipulf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblpupil.getText());
                       tot4=tot4+Integer.parseInt(lblpupil.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         pipullist.add(NewAdmPanel.date(s));
                       pipul2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<libcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(lib[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfee.getText());
                       tot5=tot5+Integer.parseInt(lbllibfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         liblist.add(NewAdmPanel.date(s));
                       lib2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<libfcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(libf[i]==j){                       
                       grandtotal+=Integer.parseInt(lbllibfine.getText());
                       tot6=tot6+Integer.parseInt(lbllibfine.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         libflist.add(NewAdmPanel.date(s));
                       libf2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<hostcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(hostf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblhostelfee.getText());
                       tot7=tot7+Integer.parseInt(lblhostelfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         hostlist.add(NewAdmPanel.date(s));
                       hostel2=true;                      
                    }
                    }
                    }                    
                    
                    for(int i=0;i<examcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(examfee[i]==j){                       
                       grandtotal+=Integer.parseInt(lblexamfee.getText());
                       tot8=tot8+Integer.parseInt(lblexamfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         examlist.add(NewAdmPanel.date(s));
                       exam2=true;                      
                    }
                    }
                    }
                    
                    for(int i=0;i<schdevcountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                    if(schdev1[i]==j){
                        grandtotal+=Integer.parseInt(lblschdevfee.getText());
                        tot9=tot9+Integer.parseInt(lblschdevfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         schdevlist.add(NewAdmPanel.date(s));
                        schdev2=true;                        
                    }   
                    }
                    }
                    
                    for(int i=0;i<sessioncountmonth;i++)
                    {
                    for(int j=oldmonth+1; j<=curmonth; j++)
                    {
                     if(sessionf[i]==j){                       
                       grandtotal+=Integer.parseInt(lblsessionfee.getText());
                       tot10=tot10+Integer.parseInt(lblsessionfee.getText());
                         if(j<10)
                          s="0"+String.valueOf(j);
                         else
                             s=String.valueOf(j);
                         sessionlist.add(NewAdmPanel.date(s));
                       session2=true;                      
                    }
                    }
                    }
                    
                }
                txttpa.setText(String.valueOf(grandtotal));
                if(txttpa.getText().equals("0")||txttpa.getText().equals("")){
                    cbmisc.setEnabled(false);
                    jlist.setEnabled(false);
                }
                else{
                    cbmisc.setEnabled(true);
                    jlist.setEnabled(true);
                }
                if(k==0)
                {
                if(exam2)
                {
                    ViewPanel.lblexamf.setText("  Examination Fee: "+"("+examlist.toString().substring(1, examlist.toString().length()-1) +")"+" * "+Integer.parseInt(lblexamfee.getText()));
                    ViewPanel.lblexamfee.setText(String.valueOf(tot8));
                }
                if(schdev2)
                {
                    ViewPanel.lblscvdevf.setText("  School Development Fee: "+"("+schdevlist.toString().substring(1, schdevlist.toString().length()-1) +")"+" * "+Integer.parseInt(lblschdevfee.getText()));
                    ViewPanel.lblschdevfee.setText(String.valueOf(tot9));
                }
                }
    }
private String monthSub(String r,String s){
        int month1=Integer.parseInt(r);//07/2016
        int month2=Integer.parseInt(s);//04/2016
        int retvalue;             
        if(month1>=month2){
           retvalue = month1-month2;
        }
        else{
            month1=month1+12;
            retvalue = month1-month2;
        }
        return String.valueOf(retvalue);
        }
private void search() {
        flag1 = false;       
        if (txtroll.getText().equals("")||txtroll.isEditable() == false) {
            txtroll.grabFocus();
        }else {
            txtselect.setText("0");
            txtroll.setText(txtroll.getText().toUpperCase());
            String str = txtroll.getText();
            try {
//                java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String str1 = "SELECT STUDENT_NAME,ROLL_NO,CLASS,SECTION,ADMISSION_NO,VILLAGE,TRANS_FEE,ADMISSION_DATE,TOTAL_ADM_FEE FROM NEWADMISSION WHERE ADMISSION_NO='" + str + "'";
                rs = stmt.executeQuery(str1);
                while (rs.next()) {
                    txtname.setText(rs.getString(1));
                    txtroll1.setText(rs.getString(2));
                    txtclass.setText(rs.getString(3));
                    txtsection.setText(rs.getString(4));
                    admno=rs.getString(5);
                    txtvill.setText(rs.getString(6));
                    lbltransfee.setText(rs.getString(7));
                    String date=String.valueOf(rs.getDate(8));//2016-07-20
                    String d1 = date.substring(0, 4);
                    paydate=d1;
                    paymonth1=date.substring(5,7);
                    paymonth=NewAdmPanel.date(paymonth1);
                    total=Integer.parseInt(rs.getString(9));
                    txtroll.setEditable(false);
                    txtroll.setBackground(Color.WHITE);
                    jcbac.setEnabled(true);
                    cbf.setEnabled(true);
                    cbp.setEnabled(true);
                    rbcash.setEnabled(true);
                    rbcheque.setEnabled(true);
                    //rbcash.setEnabled(true);
                    //rbcheque.setEnabled(true);
                    jlist.setEnabled(true);
                    flag2=true;
                    enabled();
                    fillData();                    
                    if(rbcheque.isSelected()&&cbf.isSelected()){
                        txtchno.setEditable(true);
                        cmbdd.setEnabled(true);
                        cmbmm.setEnabled(true);
                        cmbyy.setEnabled(true);
                        txtbkname.setEditable(true);
                        rbcheque.setEnabled(true);
                        rbcash.setEnabled(true);
                    }
                    else if(rbcheque.isSelected()&&cbp.isSelected()){
                        txtchamt.setEditable(true);
                        txtchno.setEditable(true);
                        cmbdd.setEnabled(true);
                        cmbmm.setEnabled(true);
                        cmbyy.setEnabled(true);
                        txtbkname.setEditable(true);
                        rbcheque.setEnabled(true);
                        rbcash.setEnabled(true);
                    }
                    break;
                }
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String str2 = "SELECT DA,PAY_MONTH,PAY_DATE,CASH_AMOUNT,CHEK_AMT FROM STUDENT_FEE WHERE ADMISSION_NO='" + str + "' ORDER BY SL_NO ASC";
                rs = stmt.executeQuery(str2);
                rs.last();
                txtda.setText(rs.getString(1));
                da=Integer.parseInt(txtda.getText());
                paymonth=rs.getString(2);
//                if(paymonth==null){
//                    paymonth="";
//                }
                String date = String.valueOf(rs.getDate(3));
                String d1 = date.substring(0, 4);
                paydate=d1;
                String cash=rs.getString(4);
                String chek=rs.getString(5);
                total=Integer.parseInt(cash)+Integer.parseInt(chek);
//                int da1=Integer.parseInt(String.valueOf(txtda.getText()));
//                int select=0,total=0;
//                if(txtselect.getText().equals("")){
//                    select=0;
//                }
//                else{
//                    select=Integer.parseInt(String.valueOf(txtselect.getText()));
//                }
                flag1 = true;
                totalPaymentMade(1);
//                total=da1+select;
//                txttpa.setText(String.valueOf(total));                
            } catch (SQLException e) {
                flag1=false;
                //JOptionPane.showMessageDialog(rootPane, e); 
            }
            if (flag1 == false && flag2 == true) {
                txtda.setText("0");
                totalPaymentMade(1);
//                paymonth="";
//                paydate="";
            }
        }
        txtcurd.setText("0");
    }
    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        // TODO add your handling code here:
        search();
    }//GEN-LAST:event_btnsearchActionPerformed
    private void clearField() {
        txtroll.setEditable(true);
        txtroll.grabFocus();
        jlist.clearSelection();
        txtroll1.setText("");
        txtclass.setText("");
        txtsection.setText("");
        txtname.setText("");
        txtvill.setText("");
        txtda.setText("");
        txtcurd.setText("");
        txtselect.setText("");
        txttpa.setText("");
        txtacamt.setText("");
        txtamt.setText("");
        txtamt.setEditable(false);
        txtchamt.setText("");
        txtchamt.setEditable(false);
        jcbac.setSelected(false);
        txtac.setText("");
        txtac.setEditable(false);
        txtacamt.setEditable(false);
        lblregfee.setText("");
        lbladmfee.setText("");
        lblcaut.setText("");
        lbltufee.setText("");
        lblcompfee.setText("");
        lblelectfee.setText("");
        lblsmart.setText("");
        lblsport.setText("");
        lblpupil.setText("");
        lbllibfee.setText("");
        lbllibfine.setText("");
        lbltransfee.setText("");
        lblhostelfee.setText("");
        lblschdevfee.setText("");
        lblexamfee.setText("");
        lblsessionfee.setText("");
        txtmisc.setText("");
        txtmisc.setEditable(false);
        cbmisc.setSelected(false);
        cbmisc.setEnabled(false);
        txtchno.setText("");
        txtchno.setEditable(false);
        cmbdd.setSelectedIndex(0);
        cmbmm.setSelectedIndex(0);
        cmbyy.setSelectedIndex(0);
        cmbdd.setEnabled(false);
        cmbmm.setEnabled(false);
        cmbyy.setEnabled(false);
        txtbkname.setText("");
        txtbkname.setEditable(false);
        cbreg.setSelected(false);
        cbadm.setSelected(false);
        cbtuit.setSelected(false);
        cbcomp.setSelected(false);
        cbelect.setSelected(false);
        cbsmart.setSelected(false);
        cbsport.setSelected(false);
        cbpupil.setSelected(false);
        cblib.setSelected(false);
        cblibfine.setSelected(false);
        cbtrans.setSelected(false);
        cbhostel.setSelected(false);
        cbschdev.setSelected(false);
        cbexam.setSelected(false);
        cbsession.setSelected(false);
        cbcaut.setSelected(false);
        jlist.setEnabled(false);
        Indices=1;
        flag2=false;
        enabled();
    }
    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        clearField();
    }//GEN-LAST:event_btnclearActionPerformed

    private void txtrollActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrollActionPerformed
        // TODO add your handling code here:
        search();
    }//GEN-LAST:event_txtrollActionPerformed
    private void collectedAmount() {
        int tcac;
        int tchac;
        String curdate = NewJPanel.lbldate.getText().substring(5, 15);
        String curdate1 = NewAdmPanel.date(curdate);
        try {
//            java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT TCAC,TCHAC FROM AMOUNT_COLLECT WHERE COLLECTED_DATE='"+curdate1+"'";
            rs = stmt.executeQuery(str1);
            rs.first();            
                int amc = Integer.parseInt(rs.getString(1));
                int chkamtc = Integer.parseInt(rs.getString(2));
                tcac = amc + amt;
                tchac = chkamtc + chamt;
                String update = "UPDATE AMOUNT_COLLECT SET TCAC='" + tcac + "',TCHAC='" + tchac + "' WHERE COLLECTED_DATE='" + curdate1 + "'";
                stmt.executeQuery(update);
                con.setAutoCommit(true);
        } catch (SQLException e) {
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String query = ("insert into AMOUNT_COLLECT values('" + amt + "','" + chamt + "','" + curdate1 + "')");
                stmt = con.createStatement();
                stmt.executeUpdate(query);
                con.setAutoCommit(true);
                } catch (SQLException f) {
            }
        }
    }

    private void amountCollectedValue() {
        try {
            String curdate = NewJPanel.lbldate.getText().substring(5, 15);
            String curdate1 = NewAdmPanel.date(curdate);
//            java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT TCAC,TCHAC,COLLECTED_DATE FROM AMOUNT_COLLECT WHERE COLLECTED_DATE='"+curdate1+"'";
            rs = stmt.executeQuery(str1);
            rs.first();
            txttcac.setText(rs.getString(1));
            txttchac.setText(rs.getString(2));
            stmt.close();
            rs.close();
//            con.close();
        } catch (SQLException f) {
            txttcac.setText("");
            txttchac.setText("");
        }
    }
    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        // TODO add your handling code here:
        String pay_type;
        boolean flag=false,flag1=false,chk=true,checkamt=false,selectionfalse=false;
        String chkno = "", chkdate = "", bkname = "",month="",acno="";
        String pm1="";
        int k=1;
        int tpamt = 0,regamt=0,admamt=0,cautamt=0,tuamt=0,compamt=0,electamt=0,smartamt=0,sportamt=0,pupilamt=0,libfee=0,libfine=0,transamt=0,hostelamt=0,schdevamt=0,examamt=0,sessionamt=0,misc=0;
        String curdate = NewJPanel.lbldate.getText().substring(5, 15);
        String curdate1 = NewAdmPanel.date(curdate);
        String time = NewJPanel.lbltime.getText();
        String time1 = time.substring(5, 16);//Time:12:42:36 AM
        month=monthly;
        String yearno=NewJPanel.year;
        if (txttpa.getText().equals("")) {
        } else {
            tpamt = Integer.parseInt(txttpa.getText());
        }
        if (jcbac.isSelected()&&jcbac.isEnabled()) {
            if (txtacamt.getText().equals("")) {
                txtacamt.grabFocus();
            } else {
                long amount = Long.parseLong(txtacamt.getText());
                if (amount > tpamt) {
                    txtacamt.setText("");
                    txtacamt.grabFocus();
                }
            }

        }
       else if (rbcash.isSelected()&&rbcash.isEnabled()) {
            if (txtamt.getText().equals("")) {
                txtamt.grabFocus();
            } else {
                long amount = Long.parseLong(txtamt.getText());
                if (amount > tpamt) {
                    txtamt.setText("");
                    txtamt.grabFocus();
                }
            }

        } else if(rbcheque.isSelected()&&rbcheque.isEnabled()) {
            if (txtchamt.getText().equals("")) {
                txtchamt.grabFocus();
            } else {
                long chamount = Long.parseLong(txtchamt.getText());
                if (chamount > tpamt) {
                    txtchamt.setText("");
                    txtchamt.grabFocus();
                }
            }
        }
       if (txtvill.getText().equals("")||txtroll1.getText().equals("") ||txtroll.getText().equals("") || txtclass.getText().equals("") || txtsection.getText().equals("") || txtname.getText().equals("") || txtda.getText().equals("") || txttpa.getText().equals("") || txttpa.getText().equals("0")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup The All Fields");
            chk=false;
        } 
        else if(jcbac.isSelected()==false&&cbf.isSelected()==false&&cbp.isSelected()==false){
            JOptionPane.showMessageDialog(rootPane, "Please Select One of These Payment");
            chk=false;
    }
        else if (jcbac.isSelected() && txtac.getText().equals("")||jcbac.isSelected() && txtacamt.getText().equals("") || (rbcash.isSelected()&&rbcash.isEnabled()) && txtamt.getText().equals("") || (rbcheque.isSelected()&&rbcheque.isEnabled()) && txtchamt.getText().equals("") || (rbcheque.isSelected()&&rbcheque.isEnabled()) && txtchno.getText().equals("") || (rbcheque.isSelected()&&rbcheque.isEnabled()) && cmbdd.getSelectedIndex() == 0 || (rbcheque.isSelected()&&rbcheque.isEnabled()) && cmbmm.getSelectedIndex() == 0 || (rbcheque.isSelected()&&rbcheque.isEnabled()) && cmbyy.getSelectedIndex() == 0 || (rbcheque.isSelected()&&rbcheque.isEnabled()) && txtbkname.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Fillup The All Fields");
            chk=false;
        }
       else if(txtselect.getText().equals("")||txtselect.getText().equals("0")||cbf.isSelected()||cbp.isSelected()||jcbac.isSelected()){                
            String d[]=new java.util.Date().toString().split(" ");
        //String today = d[2]+"-"+d[1]+"-"+d[5];
            String curmonth1 =d[1];
            if(paymonth.length()==3){
                if(curmonth1.equals(paymonth)){
                    month=curmonth1;
                }
                else{
               int dig=Integer.parseInt(NewAdmPanel.dateFormat(paymonth));
               dig++;
               String mn=NewAdmPanel.date("0"+dig);
               month=mn+"-"+curmonth1;
                }
            }
            else{
               pm1=paymonth.substring(4, 7);
               if(pm1.equals(curmonth1)){
                   month=curmonth1;
               }
               else{
               int dig=Integer.parseInt(NewAdmPanel.dateFormat(pm1));
               dig++;
               String mn=NewAdmPanel.date("0"+dig);
               month=mn+"-"+curmonth1;
               }        
            }
                flag=true;
            }
//        else if(paymonth.equals("")||paydate.equals("")){     
////        jlist.setSelectionInterval(0, jlist.getMaxSelectionIndex());
//        month=monthly;
//        flag=true;
//        }
//        else if(paymonth.equals(month)&&yearno.equals(paydate)){
//                flag=false;
//            }
//                else if(paymonth.length()>=3){//jan-apr
//                    if(paymonth.length()==3){
//                        pm1=paymonth;
//                    }
//                    else{
//                pm1=paymonth.substring(4, 7);
//                    }
//                for(int i=0;i<loi.length;i++){
//                    if(loi[i].equals(pm1)&& yearno.equals(paydate)||loi[i].equals(pm1)&& Integer.parseInt(yearno)>Integer.parseInt(paydate)){
//                        if(jlist.getMaxSelectionIndex()>i){
//                            if(jlist.getMinSelectionIndex()<=i){
//                               selectionfalse=true;                              
//                            }
//                            else{
//                                selectionfalse=false;
//                                flag=true;
//                            }
//                        jlist.setSelectionInterval(i+1, jlist.getMaxSelectionIndex());
//                        month=monthly;
//                        flag1=true;
//                        break;
//                }
//                        else{
//                        flag=false;
//                        break;
//                    }
//            }
//        }
//                }
        if(chk==false){
            
        }
        else{
//        if(flag==false&&flag1==false) {
//            JOptionPane.showMessageDialog(rootPane, "Fee Allready Paid For This Month");
//        }
//         if(flag1==true&&selectionfalse==true){
//            k = JOptionPane.showConfirmDialog(rootPane, "Fee Allready Paid Up To " + pm1 + " Do You Want To Paid " + monthly, "Fee_Payment", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (jcbac.isSelected()&&jcbac.isEnabled()) {
            if (txtacamt.getText().equals("")) {
                txtacamt.grabFocus();
                checkamt=true;
            } else {
                long amount = Long.parseLong(txtacamt.getText());
                long ttp=Long.parseLong(txttpa.getText());
                if (amount > ttp || amount > 30000) {
                    txtacamt.setText("");
                    txtacamt.grabFocus();
                    checkamt=true;
                }
            }

        }
       else if (rbcash.isSelected()&&rbcash.isEnabled()) {
            if (txtamt.getText().equals("")) {
                txtamt.grabFocus();
                checkamt=true;
            } else {
                long amount = Long.parseLong(txtamt.getText());
                long ttp=Long.parseLong(txttpa.getText());
                if (amount > ttp) {
                    txtamt.setText("");
                    txtamt.grabFocus();
                    checkamt=true;
                }
            }

        } else if(rbcheque.isSelected()&&rbcheque.isEnabled()) {
            if (txtchamt.getText().equals("")) {
                txtchamt.grabFocus();
                checkamt=true;
            } else {
                long chamount = Long.parseLong(txtchamt.getText());
                long ttp=Long.parseLong(txttpa.getText());
                if (chamount > ttp) {
                    txtchamt.setText("");
                    txtchamt.grabFocus();
                    checkamt=true;
                }
            }
        }
//        }
        if(checkamt==true){
            JOptionPane.showMessageDialog(rootPane, "Please Enter Valid Amount");
        }
       else if (k == JOptionPane.YES_OPTION||flag==true) {
            String slno = lblslno.getText().trim();
            int roll = Integer.parseInt(txtroll1.getText());
            String class1 =txtclass.getText();
            String section = txtsection.getText();
            String name = txtname.getText();
            String vill = txtvill.getText();
            int da;
            int tpa = Integer.parseInt(txttpa.getText());
            misc=Integer.parseInt(txtmisc.getText());
            
//            if(cbreg.isSelected()){
//                regamt=Integer.parseInt(lblregfee.getText());
//            }
//            if(cbadm.isSelected()){
//                admamt=Integer.parseInt(lbladmfee.getText());
//            }
//            if(cbcaut.isSelected()){
//                cautamt=Integer.parseInt(lblcaut.getText());
//            }
                int tutfee=Integer.parseInt(lbltufee.getText());
                tuamt=tutfee*totmonth;                           
//            if(cbcomp.isSelected()){
//                int compfee=Integer.parseInt(lblcompfee.getText());
//                compamt=Indices*compfee;
//            }
//            if(cbelect.isSelected()){
//                int electfee=Integer.parseInt(lblelectfee.getText());
//                electamt=Indices*electfee;
//            }
//            if(cbsmart.isSelected()){
//                smartamt=Integer.parseInt(lblsmart.getText());
//            }
//            if(sport2==true){
//                sportamt=Integer.parseInt(lblsport.getText());
//            }
//            if(cbpupil.isSelected()){
//                pupilamt=Integer.parseInt(lblpupil.getText());
//            }
//            if(cblib.isSelected()){
//                libfee=Integer.parseInt(lbllibfee.getText());
//            }
//            if(cblibfine.isSelected()){
//                libfine=Integer.parseInt(lbllibfine.getText());
//            }           
                int transfee=Integer.parseInt(lbltransfee.getText());
                transamt=transfee*totmonth;                          
            
//            if(cbhostel.isSelected()){
//                int hostfee=Integer.parseInt(lblhostelfee.getText());
//                hostelamt=Indices*hostfee;
//            }
                totalPaymentMade(1);
            if(schdev2==true&&totmonth!=0){
                schdevamt=tot9;
            }
            if(exam2==true&&totmonth!=0){
                examamt=tot8;
            }
//            if(cbsession.isSelected()){
//                sessionamt=Integer.parseInt(lblsessionfee.getText());
//            }
//            if(cbmisc.isSelected()){
//                int miscfee=Integer.parseInt(txtmisc.getText());
//                misc=Indices*miscfee;
//            }
            if (rbcash.isSelected()&&rbcash.isEnabled()) {
                pay_type = rbcash.getText();
                amt = Integer.parseInt(txtamt.getText());
                da = tpa - amt;
            } else if(rbcheque.isSelected()&&rbcheque.isEnabled()) {
                pay_type = rbcheque.getText();
                chamt = Integer.parseInt(txtchamt.getText());
                da = tpa - chamt;
                chkno = txtchno.getText().toUpperCase();
                String dd = String.valueOf(cmbdd.getSelectedItem());
                String mm = String.valueOf(cmbmm.getSelectedItem());
                String yy = String.valueOf(cmbyy.getSelectedItem());
                chkdate = dd.concat("-").concat(mm).concat("-").concat(yy);
                bkname = txtbkname.getText().toUpperCase();
            }
            else{
                pay_type=jcbac.getText();
                acno=txtac.getText();
                amt=Integer.parseInt(txtacamt.getText());
                da=tpa-amt;
            }
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String query = ("INSERT INTO STUDENT_FEE VALUES('" + slno + "','" + roll + "','" + class1 + "','" + section + "','" + name + "','" + regamt + "','" + admamt + "','"+cautamt+"','" + tuamt + "','" + misc + "','" + compamt + "','" + electamt + "','" + smartamt + "','" + sportamt + "','" + pupilamt + "','" + libfee + "','" + libfine + "','" + transamt + "','" + hostelamt + "','" + schdevamt + "','" + examamt + "','" + sessionamt + "','" + da + "','" + tpa + "','" + pay_type + "','" + amt + "','" + curdate1 + "','" + chamt + "','" + chkno + "','" + chkdate + "','" + bkname + "','" + acno + "','" + time1 + "','" + month + "','"+admno+"','"+vill+"')");
                stmt = con.createStatement();
                stmt.executeUpdate(query);
                con.setAutoCommit(true);
                collectedAmount();
                amountCollectedValue();
                JOptionPane.showMessageDialog(this.getParent(), "Data Successfully Inserted");                
                feepermonth();                
                getData(txtroll.getText().toUpperCase(),slno);
                clearField();
                selected();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "StudentFee", 0);
            }
        }
        }
    }//GEN-LAST:event_btnsaveActionPerformed

    private void txtamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtamtFocusLost
        // TODO add your handling code here:
        if (txtamt.getText().matches("\\d+")) {            
            int acr=Integer.parseInt(txtamt.getText());
            int late=Integer.parseInt(txtmisc.getText());
            int total=Integer.parseInt(txttpa.getText());
            int totalam=acr+late;
            if(totalam>total){
                txtamt.setText("");
                txtcurd.setText("0");
            }else{                
                txtcurd.setText(String.valueOf(total-totalam));
            }              
        
        } else {
            txtamt.setText("");
        }
    }//GEN-LAST:event_txtamtFocusLost

    private void txtchamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtchamtFocusLost
        // TODO add your handling code here:
        if (txtchamt.getText().matches("\\d+")) {
            int acr=Integer.parseInt(txtchamt.getText());
            int late=Integer.parseInt(txtmisc.getText());
            int total=Integer.parseInt(txttpa.getText());
            int totalam=acr+late;
            if(totalam>total){
                txtchamt.setText("");
                txtcurd.setText("0");
            }else{                
                txtcurd.setText(String.valueOf(total-totalam));
            }  
        } else {
            txtchamt.setText("");
        }
    }//GEN-LAST:event_txtchamtFocusLost

    private void txtbknameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtbknameFocusLost
        // TODO add your handling code here:
        if (txtbkname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtbkname.setText("");
        }
    }//GEN-LAST:event_txtbknameFocusLost

    private void btncancleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancleActionPerformed
        // TODO add your handling code here:
        NewJPanel.lblfee.setEnabled(true);
        AdmissionOpen.jmi1.setEnabled(true);
        AdmissionOpen.count3 = 0;
        dispose();
        
    }//GEN-LAST:event_btncancleActionPerformed
    private void getData(String rollno, String sln) {
        String month="";
        try {
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "SELECT SL_NO,ROLL_NO,CLASS,SECTION,STD_NAME,REG_FEE,ADM_FEE,CAUTION_MONEY,TUT_FEE,MISC,COMPUTER,ELECT_FEE,SMART_FEE,SPORTS_FEE,PUPIL_FUND,LIB_FEE,LIB_FINE,TRANS_FEE,HOSTEL_FEE,SCHOOLDEV_FEE,EXAM_FEE,SESSION_FEE,TPA,PAY_DATE,PAY_TIME,PAY_MONTH,ADMISSION_NO,VILL,DA,CASH_AMOUNT,CHEK_AMT FROM STUDENT_FEE WHERE ADMISSION_NO='" + rollno + "' OR SL_NO='"+sln+"' ORDER BY SL_NO ASC";
            rs = stmt.executeQuery(str);
            rs.last();
            String slno = rs.getString(1);
            String roll = rs.getString(27);
            if (rollno.equalsIgnoreCase(roll)||sln.equalsIgnoreCase(slno)) {
                prd = new PrintDialog(this,true);
                PrintDialog.lblslno.setText(slno);
                PrintDialog.lblroll.setText(rs.getString(2));
                PrintDialog.lblclass.setText(rs.getString(3));
                PrintDialog.lblsection.setText(rs.getString(4));
                PrintDialog.lblname.setText(rs.getString(5));
                PrintDialog.lblvill.setText(rs.getString(28));
                String regfee1=rs.getString(6);
                if(regfee1.equals("0")){
                    PrintDialog.lblregfee.setText("");
                }
                else{
                    PrintDialog.lblregfee.setText(regfee1);
                }
                String admfee=rs.getString(7);
                if(admfee.equals("0")){
                    PrintDialog.lbladmfee.setText("");
                }
                else{
                    PrintDialog.lbladmfee.setText(admfee);
                }
                String cautamt=rs.getString(8);
                if(cautamt.equals("0")){
                    PrintDialog.lblcaut.setText("");
                }
                else{
                    PrintDialog.lblcaut.setText(cautamt);
                }
                String tutfee=rs.getString(9);
                if(tutfee.equals("0")){
                    PrintDialog.lbltufee.setText("");
                    PrintDialog.lblmonth.setText("");
                }
                else{
                    PrintDialog.lbltufee.setText(tutfee);
                    month=rs.getString(26);
                    PrintDialog.lblmonth.setText("( "+month+" )");
                }
                String misc=rs.getString(10);
                if(misc.equals("0")){
                    PrintDialog.lblmisc.setText("");
                }
                else{
                    PrintDialog.lblmisc.setText(misc);
                }
                String compfee=rs.getString(11);
                if(compfee.equals("0")){
                    PrintDialog.lblcompfee.setText("");
                }
                else{
                    PrintDialog.lblcompfee.setText(compfee);
                }
                String electfee=rs.getString(12);
                if(electfee.equals("0")){
                    PrintDialog.lblelectfee.setText("");
                }
                else{
                    PrintDialog.lblelectfee.setText(electfee);
                }
//                String smartfee=rs.getString(13);
//                if(smartfee.equals("0")){
//                    PrintDialog.lblsmartfee.setText("");
//                }
//                else{
//                    PrintDialog.lblsmartfee.setText(smartfee);
//                }
                String sportfee=rs.getString(14);
                if(sportfee.equals("0")){
                    PrintDialog.lblsportfee.setText("");
                }
                else{
                    PrintDialog.lblsportfee.setText(sportfee);
                }
//                String pupil=rs.getString(15);
//                if(pupil.equals("0")){
//                    PrintDialog.lblpupil.setText("");
//                }
//                else{
//                    PrintDialog.lblpupil.setText(pupil);
//                }
                String libfee=rs.getString(16);
                if(libfee.equals("0")){
                    PrintDialog.lbllibfee.setText("");
                }
                else{
                    PrintDialog.lbllibfee.setText(libfee);
                }
                String libfine=rs.getString(17);
                if(libfine.equals("0")){
                    PrintDialog.lbllibfine.setText("");
                }
                else{
                    PrintDialog.lbllibfine.setText(libfine);
                }
                String transfee=rs.getString(18);
                if(transfee.equals("0")){
                    PrintDialog.lbltransfee.setText("");
                }
                else{
                    PrintDialog.lbltransfee.setText(transfee);                    
                    PrintDialog.lblmonth1.setText("( "+month+" )");
                }
                String hostelfee=rs.getString(19);
                if(hostelfee.equals("0")){
                    PrintDialog.lblhostelfee.setText("");
                }
                else{
                    PrintDialog.lblhostelfee.setText(hostelfee);                   
                }
                String schdevfee1=rs.getString(20);
                if(schdevfee1.equals("0")){
                    PrintDialog.lblschdevfee.setText("");
                }
                else{
                    PrintDialog.lblschdevfee.setText(schdevfee1);
                }
                String examfee=rs.getString(21);
                if(examfee.equals("0")){
                    PrintDialog.lblexamfee.setText("");
                }
                else{
                    PrintDialog.lblexamfee.setText(examfee);
                }
                String sessionfee=rs.getString(22);
                if(sessionfee.equals("0")){
                    PrintDialog.lblsessionfee.setText("");
                }
                else{
                    PrintDialog.lblsessionfee.setText(sessionfee);
                }
                //SL_NO,ROLL_NO,CLASS,SECTION,STD_NAME,REG_FEE,ADM_FEE,CAUTION_MONEY
                //,TUT_FEE,MISC,COMPUTER,ELECT_FEE,SMART_FEE,SPORTS_FEE,PUPIL_FUND
                //,LIB_FEE,LIB_FINE,TRANS_FEE,HOSTEL_FEE,SCHOOLDEV_FEE,EXAM_FEE,
                //SESSION_FEE,TPA,PAY_DATE,PAY_TIME,PAY_MONTH,ADMISSION_NO,VILL,DA,CASH_AMOUNT,CHEK_AMT
                PrintDialog.lbltotalamt.setText(rs.getString(23));
                PrintDialog.lbldues.setText(rs.getString(29));
                String totalamt;
                String cash=rs.getString(30);
                String check=rs.getString(31);
                if(cash.equals("0")){
                    totalamt=check;
                }
                else{
                totalamt=cash;
            }
                //PrintDialog.lblpaidamt.setText(rs.getString(30));                
                PrintDialog.lblpaidamt.setText(totalamt);
       if(PrintDialog.lblpaidamt.getText().equals("")||PrintDialog.lblpaidamt.getText().equals("0")){
            
        }
        else{
            int len=totalamt.length();
            String ucresult = AdmissionOpen.convertDigit(len, totalamt);
            String getresult=ucresult+"Rupees"+" "+"Only";
            PrintDialog.lblword.setText(getresult);
                }               
                String date = String.valueOf(rs.getDate(24));
                String d1 = date.substring(0, 4);
                String d2 = date.substring(5, 7);
                String d3 = date.substring(8, 10);
                String d4 = d3.concat("/").concat(d2).concat("/").concat(d1);
                String d5 = NewAdmPanel.date(d4);
                PrintDialog.lbldate.setText(PrintDialog.lbldate.getText().concat(" ").concat(d5));
                PrintDialog.lbltime.setText(PrintDialog.lbltime.getText().concat(" ").concat(rs.getString(25)));                
                PrintDialog.lbladmno.setText(roll);
                PrintDialog.jLabel47.setText("Session Fee");
                prd.setVisible(true);
                prd.setBounds(300, 20, 630, 600);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this.getParent(), "Please Enter a Valid ADMISSION NO. or Slip NO.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        // TODO add your handling code here:
        String r = "";
//        int yearno=Integer.parseInt(NewJPanel.year);
//        int yearno1=yearno+1;
//        String setyear1=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
//        String chk="HHA ".concat(setyear1).concat(" / ");
        if (txtroll.getText().equals("")) {
                r = JOptionPane.showInputDialog(this.getParent(), "Please Enter ADMISSION NO. or Slip NO.");               
            if(r==null){
            }
            else{
            if (r.equals("")){
            } else {
                getData(r.toUpperCase(),r.toUpperCase());
            }
        }
    }
        else {
            r = txtroll.getText().toUpperCase();
            getData(r,r);
        }
    }//GEN-LAST:event_btnprintActionPerformed

    private void txtacFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtacFocusLost
        // TODO add your handling code here:
        if (txtac.getText().matches("\\d+")) {
        } else {
            txtac.setText("");
        }
    }//GEN-LAST:event_txtacFocusLost

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        AdmissionOpen.jmi1.setEnabled(true);
        NewJPanel.lblfee.setEnabled(true);
        AdmissionOpen.count3 = 0;
    }//GEN-LAST:event_formWindowClosing
private void duesAmount(){
        da=0;
        if(txtda.getText().equals("")){
            da=0;
        }
        else{
            da=Integer.parseInt(txtda.getText());
        }
}
private void selected1(){
    if(txtselect.getText().equals("")||txtselect.getText().equals("0")){
                txtselect.setText(String.valueOf(regfee));
                //txttpa.setText(String.valueOf(regfee+da));
                    int total=(regfee*Indices)+da;
                    txttpa.setText(String.valueOf(total));
                    if(jcbac.isSelected()){
                txtacamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(String.valueOf(total));
            }
            }
            else{
                int select=Integer.parseInt(txtselect.getText());
                int total1=select+regfee;
                txtselect.setText(String.valueOf(total1));
//                int tpa=Integer.parseInt(txttpa.getText());
//                int total2=tpa+regfee;
                int total=(total1*Indices)+da;
                txttpa.setText(String.valueOf(total));
                if(jcbac.isSelected()){
                txtacamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(String.valueOf(total));
            }
            }
}
private void deselected(){
    if(txtselect.getText().equals("")||txtselect.getText().equals("0")){
                txtselect.setText("0");
            }
            else{
                int select=Integer.parseInt(txtselect.getText());
                int total1=select-regfee;
                txtselect.setText(String.valueOf(total1));
//                int tpa=Integer.parseInt(txttpa.getText());
//                int total2=tpa-(regfee*Indices);
                int total=(total1*Indices)+da;
                txttpa.setText(String.valueOf(total));
                if(jcbac.isSelected()){
                txtacamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(String.valueOf(total));
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(String.valueOf(total));
            }
            }
}
private void fill(){
    if(cbf.isSelected()&&rbcash.isSelected()){
            txtamt.setText(txttpa.getText());
        }
        else if(cbf.isSelected()&&rbcheque.isSelected()){
            txtchamt.setText(txttpa.getText());
        }
}
    private void cbregActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbregActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblregfee.getText());
        duesAmount();
        if(cbreg.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbregActionPerformed

    private void cbadmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbadmActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lbladmfee.getText());
        duesAmount();
        if(cbadm.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbadmActionPerformed

    private void cbtuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbtuitActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lbltufee.getText());
        duesAmount();
        if(cbtuit.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbtuitActionPerformed

    private void cbcompActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbcompActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblcompfee.getText());
        duesAmount();
        if(cbcomp.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbcompActionPerformed

    private void cbelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbelectActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblelectfee.getText());
        duesAmount();
        if(cbelect.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbelectActionPerformed

    private void cbsmartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsmartActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblsmart.getText());
        duesAmount();
        if(cbsmart.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbsmartActionPerformed

    private void cbsportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsportActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblsport.getText());
        duesAmount();
        if(cbsport.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbsportActionPerformed

    private void cbpupilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpupilActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblpupil.getText());
        duesAmount();
        if(cbpupil.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbpupilActionPerformed

    private void cblibActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cblibActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lbllibfee.getText());
        duesAmount();
        if(cblib.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cblibActionPerformed

    private void cblibfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cblibfineActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lbllibfine.getText());
        duesAmount();
        if(cblibfine.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cblibfineActionPerformed

    private void cbtransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbtransActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lbltransfee.getText());
        duesAmount();
        if(cbtrans.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbtransActionPerformed

    private void cbhostelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbhostelActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblhostelfee.getText());
        duesAmount();
        if(cbhostel.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbhostelActionPerformed

    private void cbschdevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbschdevActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblschdevfee.getText());
        duesAmount();
        if(cbschdev.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbschdevActionPerformed

    private void cbexamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbexamActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblexamfee.getText());
        duesAmount();
        if(cbexam.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbexamActionPerformed

    private void cbsessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsessionActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblsessionfee.getText());
        duesAmount();
        if(cbsession.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbsessionActionPerformed

    private void cbcautActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbcautActionPerformed
        // TODO add your handling code here:
        regfee=Integer.parseInt(lblcaut.getText());
        duesAmount();
        if(cbcaut.isSelected()){
            selected1();
        }
        else{
            deselected();
        }
        fill();
    }//GEN-LAST:event_cbcautActionPerformed

    private void txtchnoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtchnoFocusLost
        // TODO add your handling code here:
        if (txtchno.getText().matches("[a-zA-Z-0-9]*")) {
        } else {
            txtchno.setText("");
        }
    }//GEN-LAST:event_txtchnoFocusLost

    private void jcbacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbacActionPerformed
        // TODO add your handling code here:
        if(jcbac.isSelected()){
            txtac.setEditable(true);
            txtacamt.setEditable(true);
            txtac.grabFocus();
            //txtacamt.setEnabled(false);
            cbf.setEnabled(false);
            cbp.setEnabled(false);
            rbcash.setEnabled(false);
            rbcheque.setEnabled(false);
            txtamt.setText("");
            txtchamt.setText("");
            txtchno.setText("");
            cmbdd.setSelectedIndex(0);
            cmbmm.setSelectedIndex(0);
            cmbyy.setSelectedIndex(0);
            txtbkname.setText("");
            txtchno.setEditable(false);
            cmbdd.setEnabled(false);
            cmbmm.setEnabled(false);
            cmbyy.setEnabled(false);
            txtbkname.setEditable(false);
        }
        else{
            if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(txttpa.getText());
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(txttpa.getText());
                txtchno.grabFocus();
            txtchno.setEditable(true);
            cmbdd.setEnabled(true);
            cmbmm.setEnabled(true);
            cmbyy.setEnabled(true);
            txtbkname.setEditable(true);
            }
            if(cbp.isSelected()&&rbcash.isSelected()){
                txtamt.setText("");
                txtamt.grabFocus();
            }
            else if(cbp.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText("");
                txtchamt.grabFocus();
                txtchno.setEditable(true);
            cmbdd.setEnabled(true);
            cmbmm.setEnabled(true);
            cmbyy.setEnabled(true);
            txtbkname.setEditable(true);
            }
            txtacamt.setText("");
            txtac.setText("");
            jcbac.setSelected(false);
            txtac.setEditable(false);
            cbf.setEnabled(true);
            cbp.setEnabled(true);
            rbcash.setEnabled(true);
            rbcheque.setEnabled(true);
        }
    }//GEN-LAST:event_jcbacActionPerformed

    private void cbfItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbfItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cbfItemStateChanged

    private void rbcashItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbcashItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_rbcashItemStateChanged

    private void rbchequeItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbchequeItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_rbchequeItemStateChanged

    private void cbpItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbpItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cbpItemStateChanged

    private void txtacamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtacamtFocusLost
        // TODO add your handling code here:
        if (txtacamt.getText().matches("\\d+")) {
            int acr=Integer.parseInt(txtacamt.getText());
            int late=Integer.parseInt(txtmisc.getText());
            int total=Integer.parseInt(txttpa.getText());
            int totalam=acr+late;
            if(totalam>total){
                txtacamt.setText("");
                txtcurd.setText("0");
            }else{                
                txtcurd.setText(String.valueOf(total-totalam));
            }            
        } else {
            txtacamt.setText("");
        }
    }//GEN-LAST:event_txtacamtFocusLost
private void totalamount(){
    int reg=0,adm=0,caut=0,tut=0,comp=0,elect=0,smart=0,sport=0,pupil=0,lib=0,lab=0,trans=0,host=0,schdev=0,exam=0,session=0;
    if(cbreg.isSelected()){
        reg=Integer.parseInt(lblregfee.getText());
    }
    if(cbadm.isSelected()){
        adm=Integer.parseInt(lbladmfee.getText());
    }
    if(cbcaut.isSelected()){
        caut=Integer.parseInt(lblcaut.getText());
    }
    if(cbtuit.isSelected()){
        tut=Integer.parseInt(lbltufee.getText());
    }
    if(cbcomp.isSelected()){
        comp=Integer.parseInt(lblcompfee.getText());
    }
    if(cbelect.isSelected()){
        elect=Integer.parseInt(lblelectfee.getText());
    }
    if(cbsmart.isSelected()){
        smart=Integer.parseInt(lblsmart.getText());
    }
    if(cbsport.isSelected()){
        sport=Integer.parseInt(lblsport.getText());
    }
    if(cbpupil.isSelected()){
        pupil=Integer.parseInt(lblpupil.getText());
    }
    if(cblib.isSelected()){
        lib=Integer.parseInt(lbllibfee.getText());
    }
    if(cblibfine.isSelected()){
        lab=Integer.parseInt(lbllibfine.getText());
    }
    if(cbtrans.isSelected()){
        trans=Integer.parseInt(lbltransfee.getText());
    }
    if(cbhostel.isSelected()){
        host=Integer.parseInt(lblhostelfee.getText());
    }
    if(cbexam.isSelected()){
        exam=Integer.parseInt(lblexamfee.getText());
    }
    if(cbschdev.isSelected()){
        schdev=Integer.parseInt(lblschdevfee.getText());
    }
    if(cbsession.isSelected()){
        session=Integer.parseInt(lblsessionfee.getText());
    }
    int misc=Integer.parseInt(txtmisc.getText());
    int total=reg+adm+caut+tut+comp+elect+smart+sport+pupil+lib+lab+trans+host+schdev+exam+session+misc;
    txtselect.setText(String.valueOf(total));
    int select=Integer.parseInt(txtselect.getText());
    int totalpamt=(select*Indices)+da;
                    txttpa.setText(String.valueOf(totalpamt));
                    if(jcbac.isSelected()){
                txtacamt.setText(String.valueOf(totalpamt));
            }
            else if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(String.valueOf(totalpamt));
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(String.valueOf(totalpamt));
            }
}
    private void txtmiscFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmiscFocusLost
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            //totalamount();               
        } else {
            txtmisc.setText("0");
        }
    }//GEN-LAST:event_txtmiscFocusLost

    private void cbmiscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbmiscActionPerformed
        // TODO add your handling code here:
        int latefine=0;
        if (cbmisc.isSelected() == false) {
//            txtmisc.setText("0");
            //totalamount();
            txtmisc.setEditable(false);
            if(txtmisc.getText().equals("")||txtmisc.getText().equals("0")){
                txttpa.setText(String.valueOf(grandtotal));
                txtselect.setText(String.valueOf(totalamt));
            }
            else{
                latefine=Integer.parseInt(txtmisc.getText());
                txttpa.setText(String.valueOf(grandtotal+latefine));
                txtselect.setText(String.valueOf(totalamt+latefine));
            }              
        } else {
            //totalamount();
            txtmisc.setEditable(true);
            txtmisc.grabFocus();
        }
    }//GEN-LAST:event_cbmiscActionPerformed

    private void rbchequeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbchequeActionPerformed
        // TODO add your handling code here:
        if (rbcheque.isSelected() && cbf.isSelected()) {
            txtchamt.setText(txttpa.getText());
            txtchno.setEditable(true);
            txtchno.grabFocus();
            cmbdd.setEnabled(true);
            cmbmm.setEnabled(true);
            cmbyy.setEnabled(true);
            txtbkname.setEditable(true);
            txtchamt.setEditable(false);
            txtamt.setText("");
        } else if (rbcheque.isSelected() && cbp.isSelected()) {            
            //txtchamt.setText(txtselect.getText());
            txtchamt.setEditable(true);
            txtchamt.grabFocus();
            txtamt.setText("");
            txtchno.setEditable(true);
            cmbdd.setEnabled(true);
            cmbmm.setEnabled(true);
            cmbyy.setEnabled(true);
            txtbkname.setEditable(true);
        } else {
            txtchamt.setText("");
            txtchamt.setEditable(false);
            txtchno.setEditable(false);
            cmbdd.setEnabled(false);
            cmbmm.setEnabled(false);
            cmbyy.setEnabled(false);
            txtbkname.setEditable(false);
        }
    }//GEN-LAST:event_rbchequeActionPerformed

    private void rbcashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbcashActionPerformed
        // TODO add your handling code here:
        if (rbcash.isSelected() && cbf.isSelected()) {
            txtamt.setText(txttpa.getText());
            txtamt.grabFocus();
            txtchamt.setText("");
            txtamt.setEditable(false);
        } else if (rbcash.isSelected() && cbp.isSelected()) {
//            txtamt.setText(txtselect.getText());
            txtchamt.setText("");
            txtamt.setEditable(true);
            txtamt.grabFocus();
            txtamt.setText("");
            txtchamt.setText("");
            txtchamt.setEditable(false);
            txtchno.setEditable(false);
            cmbdd.setEnabled(false);
            cmbmm.setEnabled(false);
            cmbyy.setEnabled(false);
            txtbkname.setEditable(false);
        } else {
            txtamt.setText("");
            txtamt.setEditable(false);
        }
    }//GEN-LAST:event_rbcashActionPerformed

    private void cbfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbfActionPerformed
        // TODO add your handling code here:
        if (cbf.isSelected()) {
            rbcash.setEnabled(true);
            rbcheque.setEnabled(true);
        }
        if (cbf.isSelected() && rbcash.isSelected()) {
            txtamt.setEditable(false);
            txtamt.setText(txttpa.getText());
        } else if (cbf.isSelected() && rbcheque.isSelected()) {
            txtchamt.setEditable(false);
            txtchno.grabFocus();
            txtchamt.setText(txttpa.getText());
        }
    }//GEN-LAST:event_cbfActionPerformed

    private void cbpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpActionPerformed
        // TODO add your handling code here:
        if (cbp.isSelected()) {
            rbcash.setEnabled(true);
            rbcheque.setEnabled(true);
        }
        if (cbp.isSelected() && rbcash.isSelected()) {
//            txtamt.setText(txtselect.getText());
            txtamt.setEditable(true);
            txtamt.grabFocus();
            txtamt.setText("");
        } else if (cbp.isSelected() && rbcheque.isSelected()) {
//            txtchamt.setText(txtselect.getText());
            txtchamt.setEditable(true);
            txtchamt.grabFocus();
            txtchamt.setText("");
        }
    }//GEN-LAST:event_cbpActionPerformed

    private void txtroll1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtroll1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtroll1ActionPerformed

    private void txtacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtacActionPerformed
        // TODO add your handling code here:
        txtacamt.grabFocus();
    }//GEN-LAST:event_txtacActionPerformed

    private void txtacamtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtacamtActionPerformed
        // TODO add your handling code here:
        btnsave.grabFocus();
    }//GEN-LAST:event_txtacamtActionPerformed

    private void txtamtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtamtActionPerformed
        // TODO add your handling code here:
        btnsave.grabFocus();
    }//GEN-LAST:event_txtamtActionPerformed

    private void txtchamtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtchamtActionPerformed
        // TODO add your handling code here:
        txtchno.grabFocus();
    }//GEN-LAST:event_txtchamtActionPerformed

    private void txtchnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtchnoActionPerformed
        // TODO add your handling code here:
        cmbdd.grabFocus();
    }//GEN-LAST:event_txtchnoActionPerformed

    private void txtbknameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbknameActionPerformed
        // TODO add your handling code here:
        btnsave.grabFocus();
    }//GEN-LAST:event_txtbknameActionPerformed

    private void txtvillFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtvillFocusLost
        // TODO add your handling code here:
if (txtvill.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtvill.setText("");
        }
if (txtvill.getText().length() > 30) {
            txtvill.setText("");
        }
    }//GEN-LAST:event_txtvillFocusLost

    private void txtmiscMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtmiscMouseClicked
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            int misc=Integer.parseInt(txtmisc.getText());
        if(misc<=0){
            txtmisc.setText("");
        }
        }
        else{
            txtmisc.setText("0");
        }
    }//GEN-LAST:event_txtmiscMouseClicked

    private void txtrollKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtrollKeyReleased
        // TODO add your handling code here:
//        if(txtroll.getText().equals("")||txtroll.getText().equals("HHA ".concat(setyear).concat(" /"))){        
//        txtroll.setText("HHA ".concat(setyear).concat(" / "));
//        }
    }//GEN-LAST:event_txtrollKeyReleased

    private void jlistValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jlistValueChanged
        // TODO add your handling code here:        
        String sll = jlist.getSelectedValuesList().toString();//[Jan, Feb, Mar, Apr]
        totalamount=0;
        int totalamt1=0;
        totalamt=0;
        if(jlist.getSelectedValuesList().isEmpty()){            
        }
        else{
        Object[] loi1 = jlist.getSelectedValuesList().toArray();
        for(int i=0;i<examcountmonth;i++)
        {
        for(int j=0;j<loi1.length;j++){
//            if(loi1[i].equals(sport1)){
//                totalamount+=Integer.parseInt(lblsport.getText());
//                sport2=true;
//            }
            if(loi1[j].equals(examination[i])){
                totalamount+=Integer.parseInt(lblexamfee.getText());
                exam2=true;                
            }
        }
        }
        for(int i=0;i<schdevcountmonth;i++)
        {
        for(int j=0;j<loi1.length;j++){
            if(loi1[j].equals(schooldevfee[i])){
                totalamount+=Integer.parseInt(lblschdevfee.getText());
                schdev2=true;
            }
        }
        }
        String m1=sll.substring(1, 4);
        String m2=sll.substring(sll.length()-4, sll.length()-1);
        monthly=sll.substring(1, sll.length()-1);
        //String d[]=new java.util.Date().toString().split(" ");
        //String today = d[2]+"-"+d[1]+"-"+d[5];
        //String curmonth1 =d[1];
//        if(loi1.length>1){
//        monthly=m1.concat("-").concat(m2);
//        }
//        else{
//            monthly=m1;
//        }
        
        }
        Indices = jlist.getSelectedIndices().length;
        tutfee=Integer.parseInt(lbltufee.getText())*Indices;
        trans=Integer.parseInt(lbltransfee.getText())*Indices;
        totalamt1=tutfee+trans+totalamount+Integer.parseInt(txtmisc.getText());       
        totalamt=tutfee+trans+totalamount;
        txtselect.setText(String.valueOf(totalamt1));
        //txtcurd.setText(String.valueOf(tpa-totalamt1));
        
        if(txttpa.getText().equals("")||txttpa.getText().equals("0")){            
        }
        else if(txtselect.getText().equals("")||txtselect.getText().equals("0")){
        }
        else{            
//            int select=Integer.parseInt(txtselect.getText());
//            int total=(select*Indices)+da;
            //txttpa.setText(String.valueOf(total));
            if(cbf.isSelected()&&rbcash.isSelected()){
                txtamt.setText(txttpa.getText());
            }
            else if(cbf.isSelected()&&rbcheque.isSelected()){
                txtchamt.setText(txttpa.getText());
            }            
        }
//       if(paymonth.equals("")||paydate.equals("")){     
//        jlist.setSelectionInterval(0, jlist.getMaxSelectionIndex());
//        if(txtselect.getText().equals("")){
//            
//        }
//        else{
//        
//         slamt=Integer.parseInt(txtselect.getText());
//         slamt1=slamt*Indices;
//        txtselect.setText(String.valueOf(slamt1));
//        txttpa.setText(String.valueOf(da+slamt1));
//        
//        }
//        }
//        else if(paymonth.length()>3){//jan-apr                
//               String pm1=paymonth.substring(4, 7);
//                for(int i=0;i<loi.length;i++){
//                    if(loi[i].equals(pm1)&& yearno.equals(paydate)){
//                        if(jlist.getMaxSelectionIndex()>i){
//                        jlist.setSelectionInterval(i+1, jlist.getMaxSelectionIndex());
//        if(txtselect.getText().equals("")){
//            
//        }
//        else{
//         slamt=Integer.parseInt(txtselect.getText());
//         slamt1=slamt*Indices;
//        txtselect.setText(String.valueOf(slamt1));
//        txttpa.setText(String.valueOf(da+slamt1));
//        
//        }
//                        break;
//                }
//            }
//        }
//                }
    }//GEN-LAST:event_jlistValueChanged

    private void txtmiscFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmiscFocusGained
        // TODO add your handling code here:
        if(txtmisc.getText().equals("0")){
            txtmisc.setText("");
        }
    }//GEN-LAST:event_txtmiscFocusGained

    private void lblview1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblview1MouseClicked
        // TODO add your handling code here:
        if(txtmisc.getText().equals("")){
                txtmisc.setText("0");
            }
        if(flag1==true&&Integer.parseInt(txtselect.getText())!=0){
            vp=new ViewPanel(this,true);
            ViewPanel.lbladmno.setText(txtroll.getText());
            ViewPanel.lblname.setText(txtname.getText());
            ViewPanel.lblclass.setText("Class- "+txtclass.getText());
            ViewPanel.lblroll.setText("Roll- "+txtroll1.getText());
            if(paymonth.length()==3){
                ViewPanel.lbllastmonth.setText(paymonth+"-"+paydate);
            }
            else{
                String ld=paymonth.substring(4, 7);
                ViewPanel.lbllastmonth.setText(ld+"-"+paydate);
            }            
            ViewPanel.lbllastamt.setText(String.valueOf(total));
            ViewPanel.lbldues.setText(txtda.getText());
            ViewPanel.lbltuf.setText("  Tution Fee: "+"("+monthly+")"+" * "+lbltufee.getText());
            ViewPanel.lbltutfee.setText(String.valueOf(tutfee));
            ViewPanel.lbltransf.setText("  Transport Fee: "+"("+monthly+")"+" * "+lbltransfee.getText());
            ViewPanel.lbltransfee.setText(String.valueOf(trans));
            showExamSchdev();
            ViewPanel.lbllate.setText(txtmisc.getText());
            ViewPanel.lbltotal1.setText(txtselect.getText());
            int tot1=Integer.parseInt(ViewPanel.lbltotal1.getText());
            int dues=Integer.parseInt(ViewPanel.lbldues.getText());
            int gdtotal=tot1+dues;
            ViewPanel.lbltotal.setText(String.valueOf(gdtotal));
            vp.setVisible(true);            
        }
        if(flag2==true&&flag1==false&&Integer.parseInt(txtselect.getText())!=0){
            vp=new ViewPanel(this,true);
            ViewPanel.lbladmno.setText(txtroll.getText());
            ViewPanel.lblname.setText(txtname.getText());
            ViewPanel.lblclass.setText("Class- "+txtclass.getText());
            ViewPanel.lblroll.setText("Roll- "+txtroll1.getText());
            String ld=NewAdmPanel.date(paymonth1);
            ViewPanel.lbllastmonth.setText(ld+"-"+paydate);                  
            ViewPanel.lbllastamt.setText(String.valueOf(total));
            ViewPanel.lbldues.setText(txtda.getText());            
            ViewPanel.lbltuf.setText("  Tution Fee: "+"("+monthly+")"+" * "+lbltufee.getText());
            ViewPanel.lbltutfee.setText(String.valueOf(tutfee));
            ViewPanel.lbltransf.setText("  Transport Fee: "+"("+monthly+")"+" * "+lbltransfee.getText());
            ViewPanel.lbltransfee.setText(String.valueOf(trans));
            showExamSchdev();
            ViewPanel.lbllate.setText(txtmisc.getText());
            ViewPanel.lbltotal1.setText(txtselect.getText());
            int tot1=Integer.parseInt(ViewPanel.lbltotal1.getText());
            int dues=Integer.parseInt(ViewPanel.lbldues.getText());
            int gdtotal=tot1+dues;
            ViewPanel.lbltotal.setText(String.valueOf(gdtotal));
            vp.setVisible(true);            
        }
    }//GEN-LAST:event_lblview1MouseClicked
private void showExamSchdev()
{
            int exam=Integer.parseInt(lblexamfee.getText());
            int schdev=Integer.parseInt(lblschdevfee.getText());
            int tot=0,tot1=0;
            boolean flag=false,flag1=false;
            ArrayList<Object> examlist = new ArrayList<>();
            ArrayList<Object> schdevlist = new ArrayList<>();
            //String s[]={"Asif","Aman","Manish"};
            //System.out.println(Arrays.toString(s));
    Object[] loi1 = jlist.getSelectedValuesList().toArray();
            for(int i=0;i<examcountmonth;i++)
            {
            for(int j=0;j<loi1.length;j++){
            if(loi1[j].equals(examination[i])){
            tot=tot+exam;
            examlist.add(examination[i]);
            flag=true;
            }
            }             
            }
            for(int i=0;i<schdevcountmonth;i++)
            {
            for(int j=0;j<loi1.length;j++){
            if(loi1[j].equals(schooldevfee[i])){
                         tot1=tot1+schdev;
                         schdevlist.add(schooldevfee[i]);
                         flag1=true;
            }
            }
            }
            if(flag)
            {
            ViewPanel.lblexamf.setText("  Examination Fee: "+"("+examlist.toString().substring(1,examlist.toString().length()-1) +")"+" * "+exam);
            ViewPanel.lblexamfee.setText(String.valueOf(tot));
            }
            if(flag1)
            {
            ViewPanel.lblscvdevf.setText("  School Development Fee: "+"("+schdevlist.toString().substring(1, schdevlist.toString().length()-1) +")"+" * "+schdev);
            ViewPanel.lblschdevfee.setText(String.valueOf(tot1));
            }
}
    private void lblview2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblview2MouseClicked
        // TODO add your handling code here:
        if(txtmisc.getText().equals("")){
                txtmisc.setText("0");
            }
        if(flag1==true&&Integer.parseInt(txttpa.getText())!=0){
            vp=new ViewPanel(this,true);            
            ViewPanel.lbladmno.setText(txtroll.getText());
            ViewPanel.lblname.setText(txtname.getText());
            ViewPanel.lblclass.setText("Class- "+txtclass.getText());
            ViewPanel.lblroll.setText("Roll- "+txtroll1.getText());
            String mon;
            if(paymonth.length()==3){
                ViewPanel.lbllastmonth.setText(paymonth+"-"+paydate);
                mon=paymonth;
            }
            else{
                String ld=paymonth.substring(4, 7);
                ViewPanel.lbllastmonth.setText(ld+"-"+paydate);
                mon=ld;
            }            
            ViewPanel.lbllastamt.setText(String.valueOf(total));
            ViewPanel.lbldues.setText(txtda.getText());
            String d[]=new java.util.Date().toString().split(" ");
            //String today = d[2]+"-"+d[1]+"-"+d[5];
            String curmonth1 =d[1];
            String totmon=mon+"-"+curmonth1;
            ViewPanel.lbltuf.setText("  Tution Fee: "+"("+totmon+")"+" * "+lbltufee.getText());
            ViewPanel.lbltutfee.setText(String.valueOf(tutamt));
            ViewPanel.lbltransf.setText("  Transport Fee: "+"("+totmon+")"+" * "+lbltransfee.getText());
            ViewPanel.lbltransfee.setText(String.valueOf(transfee));
            totalPaymentMade(0);
            ViewPanel.lbllate.setText(txtmisc.getText());
            int tuf=Integer.parseInt(ViewPanel.lbltutfee.getText());
            int trf=Integer.parseInt(ViewPanel.lbltransfee.getText());
            int exf=Integer.parseInt(ViewPanel.lblexamfee.getText());
            int schf=Integer.parseInt(ViewPanel.lblschdevfee.getText());
            int latef=Integer.parseInt(ViewPanel.lbllate.getText());
            int dues=Integer.parseInt(ViewPanel.lbldues.getText());
            int totall=tuf+trf+exf+schf+latef;
            ViewPanel.lbltotal1.setText(String.valueOf(totall));
            ViewPanel.lbltotal.setText(String.valueOf(totall+dues));
            vp.setVisible(true);
        }
        if(flag2==true&&flag1==false&&Integer.parseInt(txttpa.getText())!=0){
            vp=new ViewPanel(this,true);
            ViewPanel.lbladmno.setText(txtroll.getText());
            ViewPanel.lblname.setText(txtname.getText());
            ViewPanel.lblclass.setText("Class- "+txtclass.getText());
            ViewPanel.lblroll.setText("Roll- "+txtroll1.getText());
            String ld=NewAdmPanel.date(paymonth1);
            ViewPanel.lbllastmonth.setText(ld+"-"+paydate);                  
            ViewPanel.lbllastamt.setText(String.valueOf(total));
            ViewPanel.lbldues.setText(txtda.getText());
            int mon=Integer.parseInt(paymonth1)+1;
            String mon1;
            if(mon<10)
                mon1=NewAdmPanel.date("0"+String.valueOf(mon));
            else
                mon1=NewAdmPanel.date(String.valueOf(mon));
            String d[]=new java.util.Date().toString().split(" ");
        //String today = d[2]+"-"+d[1]+"-"+d[5];
            String curmonth1 =d[1];
            String totmon=mon1+"-"+curmonth1;
            ViewPanel.lbltuf.setText("  Tution Fee: "+"("+totmon+")"+" * "+lbltufee.getText());
            ViewPanel.lbltutfee.setText(String.valueOf(tutamt));
            ViewPanel.lbltransf.setText("  Transport Fee: "+"("+totmon+")"+" * "+lbltransfee.getText());
            ViewPanel.lbltransfee.setText(String.valueOf(transfee));
            totalPaymentMade(0);
            ViewPanel.lbllate.setText(txtmisc.getText());
            int tuf=Integer.parseInt(ViewPanel.lbltutfee.getText());
            int trf=Integer.parseInt(ViewPanel.lbltransfee.getText());
            int exf=Integer.parseInt(ViewPanel.lblexamfee.getText());
            int schf=Integer.parseInt(ViewPanel.lblschdevfee.getText());
            int latef=Integer.parseInt(ViewPanel.lbllate.getText());
            int dues=Integer.parseInt(ViewPanel.lbldues.getText());
            int totall=tuf+trf+exf+schf+latef;
            ViewPanel.lbltotal1.setText(String.valueOf(totall));
            ViewPanel.lbltotal.setText(String.valueOf(totall+dues));
            vp.setVisible(true);            
        }
    }//GEN-LAST:event_lblview2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudentsFee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudentsFee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudentsFee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudentsFee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new StudentsFee().setVisible(true);
            }
        });
    }
    public static PrintDialog prd;
    private ViewPanel vp;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncancle;
    private javax.swing.JButton btnclear;
    public static javax.swing.JButton btnprint;
    private javax.swing.JButton btnpws;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton btnsearch;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox cbadm;
    private javax.swing.JCheckBox cbcaut;
    private javax.swing.JCheckBox cbcomp;
    private javax.swing.JCheckBox cbelect;
    private javax.swing.JCheckBox cbexam;
    private javax.swing.JCheckBox cbf;
    private javax.swing.JCheckBox cbhostel;
    private javax.swing.JCheckBox cblib;
    private javax.swing.JCheckBox cblibfine;
    private javax.swing.JCheckBox cbmisc;
    private javax.swing.JCheckBox cbp;
    private javax.swing.JCheckBox cbpupil;
    private javax.swing.JCheckBox cbreg;
    private javax.swing.JCheckBox cbschdev;
    private javax.swing.JCheckBox cbsession;
    private javax.swing.JCheckBox cbsmart;
    private javax.swing.JCheckBox cbsport;
    private javax.swing.JCheckBox cbtrans;
    private javax.swing.JCheckBox cbtuit;
    private javax.swing.JComboBox cmbdd;
    private javax.swing.JComboBox cmbmm;
    private javax.swing.JComboBox cmbyy;
    public static javax.swing.JLabel head1;
    private javax.swing.JLabel head2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel48;
    public static javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JCheckBox jcbac;
    private javax.swing.JList jlist;
    private javax.swing.JLabel lbladmfee;
    private javax.swing.JLabel lblcaut;
    private javax.swing.JLabel lblcompfee;
    private javax.swing.JLabel lblelectfee;
    private javax.swing.JLabel lblexamfee;
    private javax.swing.JLabel lblhostelfee;
    private javax.swing.JLabel lbllibfee;
    private javax.swing.JLabel lbllibfine;
    private javax.swing.JLabel lblpupil;
    private javax.swing.JLabel lblregfee;
    private javax.swing.JLabel lblschdevfee;
    private javax.swing.JLabel lblsessionfee;
    private javax.swing.JLabel lblslno;
    private javax.swing.JLabel lblslno1;
    private javax.swing.JLabel lblsmart;
    private javax.swing.JLabel lblsport;
    private javax.swing.JLabel lbltransfee;
    private javax.swing.JLabel lbltufee;
    private javax.swing.JLabel lblview1;
    private javax.swing.JLabel lblview2;
    private javax.swing.JRadioButton rbcash;
    private javax.swing.JRadioButton rbcheque;
    public static javax.swing.JTextField txtac;
    public static javax.swing.JTextField txtacamt;
    public static javax.swing.JTextField txtamt;
    public static javax.swing.JTextField txtbkname;
    public static javax.swing.JTextField txtchamt;
    public static javax.swing.JTextField txtchno;
    public static javax.swing.JTextField txtclass;
    public static javax.swing.JTextField txtcurd;
    public static javax.swing.JTextField txtda;
    public static javax.swing.JTextField txtmisc;
    public static javax.swing.JTextField txtname;
    public static javax.swing.JTextField txtroll;
    public static javax.swing.JTextField txtroll1;
    public static javax.swing.JTextField txtsection;
    public static javax.swing.JTextField txtselect;
    public static javax.swing.JTextField txttcac;
    public static javax.swing.JTextField txttchac;
    public static javax.swing.JTextField txttpa;
    public static javax.swing.JTextField txtvill;
    // End of variables declaration//GEN-END:variables
}
