/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author ASIF
 */
public class UpdateFee extends javax.swing.JPanel {

    /**
     * Creates new form UpdateFee
     */
    private int regfee=0;
    private Statement stmt;
    private ResultSet rs;
    private java.sql.Connection con;
    public UpdateFee(String class1) {
        initComponents();
        txtmisc.setText("0");
        txtdisc.setText("0");
        try {
                con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1="SELECT * FROM FEE_DETAILS WHERE CLASS='"+class1+"'";
                rs=stmt.executeQuery(str1);
                while(rs.next()){
//                    lblregfee.setText(rs.getString(2));
//                    lbladmfee.setText(rs.getString(3));
//                    lbltufee.setText(rs.getString(4));
//                    lblcompfee.setText(rs.getString(5));
//                    lblelectfee.setText(rs.getString(6));
//                    lblsmart.setText(rs.getString(7));
//                    lblsport.setText(rs.getString(8));
//                    lblpupil.setText(rs.getString(9));
//                    lbllibfee.setText(rs.getString(10));
//                    lbllibfine.setText(rs.getString(11));
//                    lblhostelfee.setText(rs.getString(13));
//                    lblschdevfee.setText(rs.getString(14));
//                    lblexamfee.setText(rs.getString(15));
//                    lblsessionfee.setText(rs.getString(16));
//                    lblcaut.setText(rs.getString(17));
                    String reg=rs.getString(2);
                    String adm=rs.getString(3);
                    String tut=rs.getString(4);
                    String comp=rs.getString(5);
                    String elect=rs.getString(6);
                    String smart=rs.getString(7);
                    String sport=rs.getString(8);
                    //sport1=sport.substring(sport.lastIndexOf("/")+1, sport.length());
                    String pipul=rs.getString(9);
                    String lib=rs.getString(10);
                    String libf=rs.getString(11);
                    String hostel=rs.getString(13);
                    String schdev=rs.getString(14);
                    String exam=rs.getString(15);
                    String session=rs.getString(16);
                    String caut=rs.getString(17);
                    lblregfee.setText(rs.getString(2).substring(0, reg.lastIndexOf("/")));
                    lbladmfee.setText(rs.getString(3).substring(0, adm.lastIndexOf("/")));
                    lbltufee.setText(rs.getString(4).substring(0, tut.lastIndexOf("/")));
                    lblcompfee.setText(rs.getString(5).substring(0, comp.lastIndexOf("/")));
                    lblelectfee.setText(rs.getString(6).substring(0, elect.lastIndexOf("/")));
                    lblsmart.setText(rs.getString(7).substring(0, smart.lastIndexOf("/")));
                    lblsport.setText(rs.getString(8).substring(0, sport.lastIndexOf("/")));
                    lblpupil.setText(rs.getString(9).substring(0, pipul.lastIndexOf("/")));
                    lbllibfee.setText(rs.getString(10).substring(0, lib.lastIndexOf("/")));
                    lbllibfine.setText(rs.getString(11).substring(0, libf.lastIndexOf("/")));
                    //lbltransfee.setText(rs.getString(12));
                    lblhostelfee.setText(rs.getString(13).substring(0, hostel.lastIndexOf("/")));
                    lblschdevfee.setText(rs.getString(14).substring(0, schdev.lastIndexOf("/")));
                    lblexamfee.setText(rs.getString(15).substring(0, exam.lastIndexOf("/")));
                    lblsessionfee.setText(rs.getString(16).substring(0, session.lastIndexOf("/")));
                    lblcaut.setText(rs.getString(17).substring(0, caut.lastIndexOf("/")));
                }
                stmt.close();
                rs.close();
//                con.close();
                } catch (SQLException ex) {
                    lblregfee.setText("");
                    lbladmfee.setText("");
                    lbltufee.setText("");
                    lblcompfee.setText("");
                    lblelectfee.setText("");
                    lblsmart.setText("");
                    lblsport.setText("");
                    lblpupil.setText("");
                    lbllibfee.setText("");
                    lbllibfine.setText("");
                    lblhostelfee.setText("");
                    lblschdevfee.setText("");
                    lblexamfee.setText("");
                    lblsessionfee.setText("");
                    lblcaut.setText("");
                //JOptionPane.showMessageDialog(rootPane, ex);
            }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup2 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cbreg = new javax.swing.JCheckBox();
        lblregfee = new javax.swing.JLabel();
        cbadm = new javax.swing.JCheckBox();
        lbladmfee = new javax.swing.JLabel();
        cbcaut = new javax.swing.JCheckBox();
        lblcaut = new javax.swing.JLabel();
        cbtuit = new javax.swing.JCheckBox();
        lbltufee = new javax.swing.JLabel();
        cbcomp = new javax.swing.JCheckBox();
        lblcompfee = new javax.swing.JLabel();
        cbelect = new javax.swing.JCheckBox();
        lblelectfee = new javax.swing.JLabel();
        cbsmart = new javax.swing.JCheckBox();
        lblsmart = new javax.swing.JLabel();
        cbsport = new javax.swing.JCheckBox();
        cbmisc = new javax.swing.JCheckBox();
        lblsport = new javax.swing.JLabel();
        cbsession = new javax.swing.JCheckBox();
        lblsessionfee = new javax.swing.JLabel();
        lblexamfee = new javax.swing.JLabel();
        cbexam = new javax.swing.JCheckBox();
        cbschdev = new javax.swing.JCheckBox();
        lblschdevfee = new javax.swing.JLabel();
        lblhostelfee = new javax.swing.JLabel();
        cbhostel = new javax.swing.JCheckBox();
        cblibfine = new javax.swing.JCheckBox();
        lbllibfine = new javax.swing.JLabel();
        cblib = new javax.swing.JCheckBox();
        lbllibfee = new javax.swing.JLabel();
        lblpupil = new javax.swing.JLabel();
        cbpupil = new javax.swing.JCheckBox();
        jLabel42 = new javax.swing.JLabel();
        txtselect = new javax.swing.JTextField();
        txtmisc = new javax.swing.JTextField();
        btnok = new javax.swing.JButton();
        btncancel = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        txtdisc = new javax.swing.JTextField();

        buttonGroup2.add(cbreg);
        buttonGroup2.add(cbadm);

        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1097, 660));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setOpaque(true);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 52, 370, 2));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setText("Admission Fee Details");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, 340, 50));

        cbreg.setBackground(new java.awt.Color(255, 255, 255));
        cbreg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbreg.setText("Admission Fee");
        cbreg.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbregItemStateChanged(evt);
            }
        });
        jPanel1.add(cbreg, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 125, -1));

        lblregfee.setBackground(new java.awt.Color(255, 255, 255));
        lblregfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblregfee.setOpaque(true);
        jPanel1.add(lblregfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, 70, 23));

        cbadm.setBackground(new java.awt.Color(255, 255, 255));
        cbadm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbadm.setText("Re-Admission Fee");
        cbadm.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbadmItemStateChanged(evt);
            }
        });
        jPanel1.add(cbadm, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, -1, -1));

        lbladmfee.setBackground(new java.awt.Color(255, 255, 255));
        lbladmfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbladmfee.setOpaque(true);
        jPanel1.add(lbladmfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, 70, 23));

        cbcaut.setBackground(new java.awt.Color(255, 255, 255));
        cbcaut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbcaut.setText("Caution Money(Refundable)");
        cbcaut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbcautActionPerformed(evt);
            }
        });
        jPanel1.add(cbcaut, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, -1, -1));

        lblcaut.setBackground(new java.awt.Color(255, 255, 255));
        lblcaut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblcaut.setOpaque(true);
        jPanel1.add(lblcaut, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 180, 70, 23));

        cbtuit.setBackground(new java.awt.Color(255, 255, 255));
        cbtuit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbtuit.setText("Tuition Fee");
        cbtuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbtuitActionPerformed(evt);
            }
        });
        jPanel1.add(cbtuit, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, -1, -1));

        lbltufee.setBackground(new java.awt.Color(255, 255, 255));
        lbltufee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbltufee.setOpaque(true);
        jPanel1.add(lbltufee, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 220, 70, 23));

        cbcomp.setBackground(new java.awt.Color(255, 255, 255));
        cbcomp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbcomp.setText("Computer Fee");
        cbcomp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbcompActionPerformed(evt);
            }
        });
        jPanel1.add(cbcomp, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, -1, -1));

        lblcompfee.setBackground(new java.awt.Color(255, 255, 255));
        lblcompfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblcompfee.setOpaque(true);
        jPanel1.add(lblcompfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 260, 70, 23));

        cbelect.setBackground(new java.awt.Color(255, 255, 255));
        cbelect.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbelect.setText("Electric/Generator Charge");
        cbelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbelectActionPerformed(evt);
            }
        });
        jPanel1.add(cbelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, -1, -1));

        lblelectfee.setBackground(new java.awt.Color(255, 255, 255));
        lblelectfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblelectfee.setOpaque(true);
        jPanel1.add(lblelectfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 300, 70, 23));

        cbsmart.setBackground(new java.awt.Color(255, 255, 255));
        cbsmart.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsmart.setText("Smart Class Fee");
        cbsmart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsmartActionPerformed(evt);
            }
        });
        jPanel1.add(cbsmart, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 340, -1, -1));

        lblsmart.setBackground(new java.awt.Color(255, 255, 255));
        lblsmart.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsmart.setOpaque(true);
        jPanel1.add(lblsmart, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 340, 70, 23));

        cbsport.setBackground(new java.awt.Color(255, 255, 255));
        cbsport.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsport.setText("Sports Fee");
        cbsport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsportActionPerformed(evt);
            }
        });
        jPanel1.add(cbsport, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, -1, -1));

        cbmisc.setBackground(new java.awt.Color(255, 255, 255));
        cbmisc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbmisc.setText("Miscellaneous Charges");
        cbmisc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbmiscActionPerformed(evt);
            }
        });
        cbmisc.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                cbmiscFocusLost(evt);
            }
        });
        jPanel1.add(cbmisc, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 380, -1, -1));

        lblsport.setBackground(new java.awt.Color(255, 255, 255));
        lblsport.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsport.setOpaque(true);
        jPanel1.add(lblsport, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 380, 70, 23));

        cbsession.setBackground(new java.awt.Color(255, 255, 255));
        cbsession.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbsession.setText("Session Fee");
        cbsession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbsessionActionPerformed(evt);
            }
        });
        jPanel1.add(cbsession, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, -1, -1));

        lblsessionfee.setBackground(new java.awt.Color(255, 255, 255));
        lblsessionfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblsessionfee.setOpaque(true);
        jPanel1.add(lblsessionfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 340, 70, 23));

        lblexamfee.setBackground(new java.awt.Color(255, 255, 255));
        lblexamfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblexamfee.setOpaque(true);
        jPanel1.add(lblexamfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 300, 70, 23));

        cbexam.setBackground(new java.awt.Color(255, 255, 255));
        cbexam.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbexam.setText("Examination Fee");
        cbexam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbexamActionPerformed(evt);
            }
        });
        jPanel1.add(cbexam, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 300, -1, -1));

        cbschdev.setBackground(new java.awt.Color(255, 255, 255));
        cbschdev.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbschdev.setText("School Development Fee");
        cbschdev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbschdevActionPerformed(evt);
            }
        });
        jPanel1.add(cbschdev, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 260, -1, -1));

        lblschdevfee.setBackground(new java.awt.Color(255, 255, 255));
        lblschdevfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblschdevfee.setOpaque(true);
        jPanel1.add(lblschdevfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 260, 70, 23));

        lblhostelfee.setBackground(new java.awt.Color(255, 255, 255));
        lblhostelfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblhostelfee.setOpaque(true);
        jPanel1.add(lblhostelfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 220, 70, 23));

        cbhostel.setBackground(new java.awt.Color(255, 255, 255));
        cbhostel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbhostel.setText("Hostel Fee");
        cbhostel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbhostelActionPerformed(evt);
            }
        });
        jPanel1.add(cbhostel, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 220, -1, -1));

        cblibfine.setBackground(new java.awt.Color(255, 255, 255));
        cblibfine.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cblibfine.setText("Library Fine");
        cblibfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cblibfineActionPerformed(evt);
            }
        });
        jPanel1.add(cblibfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, -1, -1));

        lbllibfine.setBackground(new java.awt.Color(255, 255, 255));
        lbllibfine.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbllibfine.setOpaque(true);
        jPanel1.add(lbllibfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 180, 70, 23));

        cblib.setBackground(new java.awt.Color(255, 255, 255));
        cblib.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cblib.setText("Library Fee");
        cblib.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cblibActionPerformed(evt);
            }
        });
        jPanel1.add(cblib, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 140, -1, -1));

        lbllibfee.setBackground(new java.awt.Color(255, 255, 255));
        lbllibfee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbllibfee.setOpaque(true);
        jPanel1.add(lbllibfee, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 140, 70, 23));

        lblpupil.setBackground(new java.awt.Color(255, 255, 255));
        lblpupil.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblpupil.setOpaque(true);
        jPanel1.add(lblpupil, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 100, 70, 23));

        cbpupil.setBackground(new java.awt.Color(255, 255, 255));
        cbpupil.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbpupil.setText("Pupil Fund");
        cbpupil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpupilActionPerformed(evt);
            }
        });
        jPanel1.add(cbpupil, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, -1, -1));

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel42.setText("Total Amount :");
        jPanel1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 460, 130, 25));

        txtselect.setEditable(false);
        txtselect.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel1.add(txtselect, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 460, 120, 25));

        txtmisc.setEditable(false);
        txtmisc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmisc.setToolTipText("Use Only Digit(0-9)");
        txtmisc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtmiscMouseClicked(evt);
            }
        });
        txtmisc.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtmiscFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmiscFocusLost(evt);
            }
        });
        jPanel1.add(txtmisc, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 380, 110, 25));

        btnok.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnok.setText("OK");
        btnok.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnokActionPerformed(evt);
            }
        });
        jPanel1.add(btnok, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 540, 60, -1));

        btncancel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancel.setText("Cancle");
        btncancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancelActionPerformed(evt);
            }
        });
        jPanel1.add(btncancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 540, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("LogOut");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel8MouseExited(evt);
            }
        });
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1290, 40, -1, -1));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel43.setText("Discount:");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 420, 80, 25));

        txtdisc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtdisc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtdiscMouseClicked(evt);
            }
        });
        txtdisc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdiscActionPerformed(evt);
            }
        });
        txtdisc.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtdiscFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtdiscFocusLost(evt);
            }
        });
        jPanel1.add(txtdisc, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 420, 120, 25));

        jScrollPane1.setViewportView(jPanel1);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents
private void selected1(){
    if(txtselect.getText().equals("")||txtselect.getText().equals("0")){
                txtselect.setText(String.valueOf(regfee));
                totalamount();
            }
            else{
                int select=Integer.parseInt(txtselect.getText());
                int total1=select+regfee;
                txtselect.setText(String.valueOf(total1));
            }
}
private void deselected(){
    if(txtselect.getText().equals("")||txtselect.getText().equals("0")){
                txtselect.setText("0");
            }
            else{
                int select=Integer.parseInt(txtselect.getText());
                int total1=select-regfee;
                txtselect.setText(String.valueOf(total1));
            }
}
private void totalamount(){
    int reg=0,adm=0,caut=0,tut=0,comp=0,elect=0,smart=0,sport=0,pupil=0,lib=0,lab=0,host=0,schdev=0,exam=0,session=0;
    if(cbreg.isSelected()){
        reg=Integer.parseInt(lblregfee.getText());
    }
    if(cbadm.isSelected()){
        adm=Integer.parseInt(lbladmfee.getText());
    }
    if(cbcaut.isSelected()){
        caut=Integer.parseInt(lblcaut.getText());
    }
    if(cbtuit.isSelected()){
        tut=Integer.parseInt(lbltufee.getText());
    }
    if(cbcomp.isSelected()){
        comp=Integer.parseInt(lblcompfee.getText());
    }
    if(cbelect.isSelected()){
        elect=Integer.parseInt(lblelectfee.getText());
    }
    if(cbsmart.isSelected()){
        smart=Integer.parseInt(lblsmart.getText());
    }
    if(cbsport.isSelected()){
        sport=Integer.parseInt(lblsport.getText());
    }
    if(cbpupil.isSelected()){
        pupil=Integer.parseInt(lblpupil.getText());
    }
    if(cblib.isSelected()){
        lib=Integer.parseInt(lbllibfee.getText());
    }
    if(cblibfine.isSelected()){
        lab=Integer.parseInt(lbllibfine.getText());
    }
    if(cbhostel.isSelected()){
        host=Integer.parseInt(lblhostelfee.getText());
    }
    if(cbexam.isSelected()){
        exam=Integer.parseInt(lblexamfee.getText());
    }
    if(cbschdev.isSelected()){
        schdev=Integer.parseInt(lblschdevfee.getText());
    }
    if(cbsession.isSelected()){
        session=Integer.parseInt(lblsessionfee.getText());
    }
    int misc=Integer.parseInt(txtmisc.getText());
    int disc=Integer.parseInt(txtdisc.getText());
    int total=(reg+adm+caut+tut+comp+elect+smart+sport+pupil+lib+lab+host+schdev+exam+session+misc)-disc;
    int total1=(reg+adm+caut+tut+comp+elect+smart+sport+pupil+lib+lab+host+schdev+exam+session+misc);
    txtselect.setText(String.valueOf(total));
    if(disc>total1){
        txtselect.setText("");
    }
}
    private void cbcautActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbcautActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblcaut.getText());
        if (cbcaut.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbcautActionPerformed

    private void cbtuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbtuitActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lbltufee.getText());
        if (cbtuit.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbtuitActionPerformed

    private void cbcompActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbcompActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblcompfee.getText());
        if (cbcomp.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbcompActionPerformed

    private void cbelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbelectActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblelectfee.getText());
        if (cbelect.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbelectActionPerformed

    private void cbsmartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsmartActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblsmart.getText());
        if (cbsmart.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbsmartActionPerformed

    private void cbsportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsportActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblsport.getText());
        if (cbsport.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbsportActionPerformed

    private void cbmiscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbmiscActionPerformed
        // TODO add your handling code here:
        if (cbmisc.isSelected() == false) {
            txtmisc.setText("0");
            totalamount();
            txtmisc.setEditable(false);
        } else {
            totalamount();
            txtmisc.setEditable(true);
            txtmisc.grabFocus();
        }
    }//GEN-LAST:event_cbmiscActionPerformed

    private void cbmiscFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cbmiscFocusLost
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            totalamount();
        } else {
            txtmisc.setText("0");
        }
    }//GEN-LAST:event_cbmiscFocusLost

    private void cbsessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbsessionActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblsessionfee.getText());
        if (cbsession.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbsessionActionPerformed

    private void cbexamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbexamActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblexamfee.getText());
        if (cbexam.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbexamActionPerformed

    private void cbschdevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbschdevActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblschdevfee.getText());
        if (cbschdev.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbschdevActionPerformed

    private void cbhostelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbhostelActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblhostelfee.getText());
        if (cbhostel.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbhostelActionPerformed

    private void cblibfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cblibfineActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lbllibfine.getText());
        if (cblibfine.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cblibfineActionPerformed

    private void cblibActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cblibActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lbllibfee.getText());
        if (cblib.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cblibActionPerformed

    private void cbpupilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpupilActionPerformed
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblpupil.getText());
        if (cbpupil.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbpupilActionPerformed

    private void txtmiscMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtmiscMouseClicked
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            int misc = Integer.parseInt(txtmisc.getText());
            if (misc <= 0) {
                txtmisc.setText("");
            }
        } else {
            txtmisc.setText("");
        }
    }//GEN-LAST:event_txtmiscMouseClicked

    private void txtmiscFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmiscFocusLost
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            totalamount();
        } else {
            txtmisc.setText("0");
        }
    }//GEN-LAST:event_txtmiscFocusLost

    private void btnokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnokActionPerformed
        // TODO add your handling code here:
        String str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16,disc;
        if (cbadm.isSelected() == false&&cbreg.isSelected()==false || txtselect.getText().equals("")) {
            JOptionPane.showMessageDialog(this.getParent(), "Please FillUp The All Fields");
        } else {
            if (cbreg.isSelected()) {
                str1 = lblregfee.getText();
            } else {
                str1 = "0";
            }
            if (cbadm.isSelected()) {
                str2 = lbladmfee.getText();
            } else {
                str2 = "0";
            }
            if (cbcaut.isSelected()) {
                str3 = lblcaut.getText();
            } else {
                str3 = "0";
            }
            if (cbtuit.isSelected()) {
                str4 = lbltufee.getText();
            } else {
                str4 = "0";
            }
            if (cbcomp.isSelected()) {
                str5 = lblcompfee.getText();
            } else {
                str5 = "0";
            }
            if (cbelect.isSelected()) {
                str6 = lblelectfee.getText();
            } else {
                str6 = "0";
            }
            if (cbsmart.isSelected()) {
                str7 = lblsmart.getText();
            } else {
                str7 = "0";
            }
            if (cbsport.isSelected()) {
                str8 = lblsport.getText();
            } else {
                str8 = "0";
            }
            if (cbpupil.isSelected()) {
                str9 = lblpupil.getText();
            } else {
                str9 = "0";
            }
            if (cblib.isSelected()) {
                str10 = lbllibfee.getText();
            } else {
                str10 = "0";
            }
            if (cblibfine.isSelected()) {
                str11 = lbllibfine.getText();
            } else {
                str11 = "0";
            }
            if (cbhostel.isSelected()) {
                str12 = lblhostelfee.getText();
            } else {
                str12 = "0";
            }
            if (cbschdev.isSelected()) {
                str13 = lblschdevfee.getText();
            } else {
                str13 = "0";
            }
            if (cbexam.isSelected()) {
                str14 = lblexamfee.getText();
            } else {
                str14 = "0";
            }
            if (cbsession.isSelected()) {
                str15 = lblsessionfee.getText();
            } else {
                str15 = "0";
            }
            str16 = txtmisc.getText();
            disc=txtdisc.getText();
            if(disc.equals("")){
                disc="0";
            }
            String str19 = txtselect.getText();
            AdmUpdate.feeDetails(str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16, str19,disc);
            AdmissionOpen.upd.remove(this);
            this.updateUI();
            AdmissionOpen.jjp.setVisible(true);
        }
    }//GEN-LAST:event_btnokActionPerformed

    private void btncancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancelActionPerformed
        // TODO add your handling code here:
        if (AdmUpdate.num3 == 1) {
            String str1 = "";
            String str2 = "";
            String str3 = "";
            String str4 = "";
            String str5 = "";
            String str6 = "";
            String str7 = "";
            String str8 = "";
            String str9 = "";
            String str10 = "";
            String str11 = "";
            String str12 = "";
            String str13 = "";
            String str14 = "";
            String str15 = "";
            String str16 = "";
            String str19 = "";
            String disc = "";
            AdmUpdate.feeDetails(str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16, str19,disc);
            AdmissionOpen.upd.remove(this);
            this.updateUI();
            AdmissionOpen.jjp.setVisible(true);
            //FirstPanel.lblnewadm1.setEnabled(true);
        }
    }//GEN-LAST:event_btncancelActionPerformed

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
        AdmissionOpen.logOut();
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseEntered
        // TODO add your handling code here:
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
    }//GEN-LAST:event_jLabel8MouseEntered

    private void jLabel8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseExited
        // TODO add your handling code here:
        jLabel8.setBorder(null);
    }//GEN-LAST:event_jLabel8MouseExited

    private void txtdiscMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtdiscMouseClicked
        // TODO add your handling code here:
        if (txtdisc.getText().matches("\\d+")) {
            int misc = Integer.parseInt(txtdisc.getText());
            if (misc <= 0) {
                txtdisc.setText("");
            }
        } else {
            txtdisc.setText("");
        }
    }//GEN-LAST:event_txtdiscMouseClicked

    private void txtdiscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdiscActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdiscActionPerformed

    private void txtdiscFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtdiscFocusGained
        // TODO add your handling code here:
        if (txtdisc.getText().matches("\\d+")) {
            int misc = Integer.parseInt(txtdisc.getText());
            if (misc <= 0) {
                txtdisc.setText("");
            }
        } else {
            txtdisc.setText("");
        }
    }//GEN-LAST:event_txtdiscFocusGained

    private void txtdiscFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtdiscFocusLost
        // TODO add your handling code here:
        if (txtdisc.getText().matches("\\d+")) {
            totalamount();
        } else {
            txtdisc.setText("0");
        }
    }//GEN-LAST:event_txtdiscFocusLost

    private void cbregItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbregItemStateChanged
        // TODO add your handling code here:
        regfee = Integer.parseInt(lblregfee.getText());
        if (cbreg.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbregItemStateChanged

    private void cbadmItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbadmItemStateChanged
        // TODO add your handling code here:
        regfee = Integer.parseInt(lbladmfee.getText());
        if (cbadm.isSelected()) {
            selected1();
        } else {
            deselected();
        }
    }//GEN-LAST:event_cbadmItemStateChanged

    private void txtmiscFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmiscFocusGained
        // TODO add your handling code here:
        if (txtmisc.getText().matches("\\d+")) {
            int misc=Integer.parseInt(txtmisc.getText());
            if(misc<=0){
            txtmisc.setText("");
            }
        } else {
            txtmisc.setText("");
        }
    }//GEN-LAST:event_txtmiscFocusGained

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncancel;
    private javax.swing.JButton btnok;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox cbadm;
    private javax.swing.JCheckBox cbcaut;
    private javax.swing.JCheckBox cbcomp;
    private javax.swing.JCheckBox cbelect;
    private javax.swing.JCheckBox cbexam;
    private javax.swing.JCheckBox cbhostel;
    private javax.swing.JCheckBox cblib;
    private javax.swing.JCheckBox cblibfine;
    private javax.swing.JCheckBox cbmisc;
    private javax.swing.JCheckBox cbpupil;
    private javax.swing.JCheckBox cbreg;
    private javax.swing.JCheckBox cbschdev;
    private javax.swing.JCheckBox cbsession;
    private javax.swing.JCheckBox cbsmart;
    private javax.swing.JCheckBox cbsport;
    private javax.swing.JCheckBox cbtuit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbladmfee;
    private javax.swing.JLabel lblcaut;
    private javax.swing.JLabel lblcompfee;
    private javax.swing.JLabel lblelectfee;
    private javax.swing.JLabel lblexamfee;
    private javax.swing.JLabel lblhostelfee;
    private javax.swing.JLabel lbllibfee;
    private javax.swing.JLabel lbllibfine;
    private javax.swing.JLabel lblpupil;
    private javax.swing.JLabel lblregfee;
    private javax.swing.JLabel lblschdevfee;
    private javax.swing.JLabel lblsessionfee;
    private javax.swing.JLabel lblsmart;
    private javax.swing.JLabel lblsport;
    private javax.swing.JLabel lbltufee;
    public static javax.swing.JTextField txtdisc;
    public static javax.swing.JTextField txtmisc;
    public static javax.swing.JTextField txtselect;
    // End of variables declaration//GEN-END:variables
}
