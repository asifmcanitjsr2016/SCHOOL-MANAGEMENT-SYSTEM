package SchoolProject;
import java. awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class regi extends JFrame implements ActionListener
{	
JLabel a,b,c,d,e;
JTextField m,n,o,p,q;
JButton bt,del,up,exit,re,sea;
Connection con;

Statement st;
Container cn;
regi()
{
super("registration form");
cn=getContentPane();
cn.setLayout(null);
a=new JLabel("NAME");
a.setBounds(10,100,100,25);
cn.add(a);
m=new JTextField(10);
m.setBounds(120,100,150,25);
cn.add(m);
b=new JLabel("ROLL");
b.setBounds(10,150,100,25);
cn.add(b);
n=new JTextField(10);
n.setText("39");
n.setBounds(120,150,150,25);
cn.add(n);
c=new JLabel("CLASS");
c.setBounds(10,200,100,25);
cn.add(c);
o=new JTextField(10);
o.setBounds(120,200,150,25);
cn.add(o);
d=new JLabel("MARKS");
d.setBounds(10,250,100,25);
cn.add(d);
p=new JTextField(10);
p.setBounds(120,250,150,25);
cn.add(p);
e=new JLabel("branch");
e.setBounds(10,300,100,25);
cn.add(e);
q=new JTextField(10);
q.setBounds(120,300,150,25);
cn.add(q);

bt=new JButton("submit");
bt.setBounds(100,350,100,25);
cn.add(bt);



del=new JButton("Delete");
del.setBounds(200,350,100,25);
cn.add(del);



up=new JButton("Update");
up.setBounds(300,350,100,25);
cn.add(up);



exit=new JButton("exit");
exit.setBounds(400,350,100,25);
cn.add(exit);


re=new JButton("Reset");
re.setBounds(500,350,100,25);
cn.add(re);



sea=new JButton("Search");
sea.setBounds(600,350,100,25);
cn.add(sea);


 
bt.addActionListener(this);

 
del.addActionListener(this);

 
up.addActionListener(this);

 
exit.addActionListener(this);

 
re.addActionListener(this);

 
sea.addActionListener(this);
setSize(1000,1000);
show();
}


public void actionPerformed(ActionEvent ae)
{
try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                } catch (Exception e) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Error : Unable To Load Driver",
                            "Driver test", javax.swing.JOptionPane.ERROR_MESSAGE, null);
                }
try {
         con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
} catch (Exception sqe) {
javax.swing.JOptionPane.showMessageDialog(null, "Error : Unable to Connect",
                            "Driver test", javax.swing.JOptionPane.ERROR_MESSAGE, null);
                }
if(ae.getSource()==sea)
{
String xx=n.getText();
String Str1="select * from student where roll='"+xx+"'";
try{
    st=con.createStatement();
ResultSet rs=st.executeQuery(Str1);
while(rs.next())
{
m.setText(rs.getString(1));
n.setText(rs.getString(2));
o.setText(rs.getString(3));
p.setText(rs.getString(4));
q.setText(rs.getString(5));
}
}
catch(SQLException xe)
{
    xe.printStackTrace();
}
}
}
public static void main(String arg[])
{
        new regi();
}
}
