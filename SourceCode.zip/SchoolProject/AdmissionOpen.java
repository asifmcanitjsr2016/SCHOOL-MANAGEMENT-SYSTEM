package SchoolProject;

import java.awt.Color;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UnsupportedLookAndFeelException;

/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
/**
 *
 * @author ASIF
 */
public class AdmissionOpen extends javax.swing.JFrame {

    /**
     * Creates new form AdmissionOpen
     */
    public static javax.swing.JScrollPane jsp;
    public static JScrollPane jScrollPane1;
    public static int old=0,count = 0, count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, count6 = 0, count7 = 0, count8 = 0, count9 = 0, count10 = 0, count11 = 0, count12 = 0, count13 = 0,count14=0,count15=0,count16=0,count17=0,count18=0,count19=0,count20=0,count21=0,count22=0,count23=0,count24=0,count25=0,count26=0,count27=0,count28=0,count29=0,count30=0,count31=0,admin=0,user=0,stfcount=0,stscount=0,totcollect=0,totalexp=0,vehcount=0,totrept=0,duesrept=0;
    public static NewJPanel njp;
    private static Statement stmt;
    private static ResultSet rs;
    public static String roll;
    public static HomePanel hmp;
    public static HomePanel1 hmp1;
    public static String r="";
    java.sql.Connection con;
    private static String[] onedigit={"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
    private static String[] twodigit={"Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
    private static String[] twodigt={"Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninty"};
    private static String result;
    public static String arg,arg1,arg3;
    private String curdate1;
    private int counter=1;
    public AdmissionOpen(){        
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdmissionOpen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(AdmissionOpen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(AdmissionOpen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(AdmissionOpen.class.getName()).log(Level.SEVERE, null, ex);
        }
        initComponents();        
        WindowUtilities.setNativeLookAndFeel();
        try{
        con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
         String str1 = "SELECT SCHOOL_NAME,ADDRESS,MOBILE_NO FROM HEADLINES";
            rs = stmt.executeQuery(str1);
            while(rs.next()){
                arg=rs.getString(1);
                arg1=rs.getString(2);
                arg3=rs.getString(3);
                break;
            }
        }
        catch(SQLException xe){
            JOptionPane.showMessageDialog(rootPane, xe);
        }        
//        try{
//            int i=0;
//            boolean flag =false;
//        String admrec="select student_name from newadmission";
//        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//            rs=stmt.executeQuery(admrec);
//            while(rs.next()){
//                String str3=rs.getString(1);
//                String incr="";
//                i++;   
//                if(i<=9){
//                    incr="00".concat(String.valueOf(i));
//                }
//                else if(i>9&&i<=99){
//        incr="0".concat(String.valueOf(i));
//                    
//                }
//                else{
//                    incr=(String.valueOf(i));
//                }
//                    String query = ("update newadmission set admission_no='" + "HHA 2015-2016 / ".concat(incr) +"',adm_receipt_no='" + "HHA/ADM ".concat(incr) +"' where student_name='"+str3+"'");
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
//            stmt.executeUpdate(query);
//            con.setAutoCommit(true);
//                }
//        }
//        catch(SQLException xe){
//            
//        }
//        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//        double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
//        double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        jm1.setVisible(false);
        jm2.setVisible(false);
        jm3.setVisible(false);
        jm4.setVisible(false);
        jm5.setVisible(false);
        jm6.setVisible(false);
        jm7.setVisible(false);
        jm8.setVisible(false);
        jSeparator13.setVisible(false);
        jmi24.setVisible(false);            
        log = new Login();
        log.setBounds(560, 200, 450, 225);
        njp = new NewJPanel();        
        hmp=new HomePanel();
        hmp.setBounds(0,0,1480,90);
        njp.add(hmp);
        hmp1=new HomePanel1();
        hmp1.setBounds(0,670,1370,37);
        njp.add(hmp1);
        NewJPanel.lbllowest.setVisible(false);
        NewJPanel.jPanel1.setVisible(false);
        njp.add(log);
        log.setVisible(false);
        mpg=new MainPicture();
        njp.add(mpg);
        mpg.setVisible(true);
        mpg.updateUI();
        this.add(njp);
//        this.pack();
        njp.updateUI();
        boolean flag=false;
        NewJPanel.jPanel2.setBounds(0, 90, 250, 580);
        String curdate = NewJPanel.lbldate.getText().substring(5, 15);//11/07/2016
        curdate1 = NewAdmPanel.date(curdate);
        try{        
         String str1 = "SELECT * FROM TRIAL_PERIOD";
         stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(str1);
            rs.last();
            String date = String.valueOf(rs.getDate(1));//"1991-11-06"
            String d = date.substring(0, 4);
            String d1 = date.substring(5, 7);
            String d2 = date.substring(8, 10);                    
            String dd = d2.concat("/").concat(d1).concat("/").concat(d);
            counter=Integer.parseInt(rs.getString(2));
            int exp=Integer.parseInt(rs.getString(3));
            if(exp==0){                
            }
            else{
            if(counter>=exp){
                JOptionPane.showMessageDialog(this,"Sorry! Your Trial Period Has Been Expired.");
                System.exit(0);
            }
            if(curdate.equals(dd)){
            }
            else{
            counter++;
           String query = ("update TRIAL_PERIOD set CUR_DATE='" + curdate1 + "',COUNTER='" + counter + "'");                     
                                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                                stmt.executeUpdate(query);
                                con.setAutoCommit(true);            
            }
            }
        }
        catch(SQLException xe){
            //JOptionPane.showMessageDialog(this, xe);
            try{ 
            String query = ("insert into TRIAL_PERIOD values('" + curdate1 + "','"+counter+"','"+15+"')");
            stmt = con.createStatement();
            stmt.executeUpdate(query);
            con.setAutoCommit(true);
            }
            catch(SQLException xre){
            }
            }
//        try {
////            con2 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//            String get="SELECT UPD_YEAR FROM NEWADMISSION";
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//            rs=stmt.executeQuery(get);
//            rs.last();
//            String updyear=rs.getString(1);
//            if(NewJPanel.year.equals(updyear)){
//                flag=false;
//            }
//            else  {
//                if(month.equals("04")){
//                try{            
//            String query = ("update newadmission set UPD_YEAR='" + NewJPanel.year +"'");
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
//            stmt.executeUpdate(query);
//            con.setAutoCommit(true);
//            flag=true;
//            //stmt.close();
//    }
//    catch(SQLException sql){
////        JOptionPane.showMessageDialog(this, sql);
//    }               
//            }
//            }
//        } catch (Exception e) {
////            javax.swing.JOptionPane.showMessageDialog(null, "Error : Unable To Load Driver",
////                    "Driver test", javax.swing.JOptionPane.ERROR_MESSAGE, null);
//        }
//        if(flag==true && month.equals("04")){
//            try{
//            String get="SELECT CLASS FROM NEWADMISSION";
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//            rs=stmt.executeQuery(get);
//            while(rs.next()){
//         String class1=rs.getString(1);
//         if(class1.equals("10")){
//            String query = ("INSERT INTO ADMISSION_HISTORY (SELECT * FROM NEWADMISSION WHERE CLASS='"+"10"+"')");
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
//            stmt.executeUpdate(query);
//            con.setAutoCommit(true);
//            String query1 = ("DELETE FROM NEWADMISSION WHERE CLASS='"+"10"+"'");
//            stmt = con.createStatement();
//            stmt.executeUpdate(query1);
//            con.setAutoCommit(true);
//            break;
//                }
//        }
//            }
//        catch(SQLException xe){
//            
//}
//        try{
////            con2 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//            String get="SELECT CLASS FROM NEWADMISSION";
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//            rs=stmt.executeQuery(get);
//            while(rs.next()){
//                String class1=rs.getString(1);
//                    if (class1.equals("Kids")) {
//                                String query = ("update newadmission set CLASS='" + "Nursery" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                    else if (class1.equals("Nursery")) {                           
//                                String query = ("update newadmission set CLASS='" + "L.K.G" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("L.K.G")) {
//                                String query = ("update newadmission set CLASS='" + "U.K.G" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("U.K.G")) {
//                                String query = ("update newadmission set CLASS='" + "1" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("1")) {
//                                String query = ("update newadmission set CLASS='" + "2" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("2")) {
//                                String query = ("update newadmission set CLASS='" + "3" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("3")) {
//                                String query = ("update newadmission set CLASS='" + "4" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("4")) {
//                                String query = ("update newadmission set CLASS='" + "5" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("5")) {
//                                String query = ("update newadmission set CLASS='" + "6" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("6")) {
//                                String query = ("update newadmission set CLASS='" + "7" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("7")) {
//                                String query = ("update newadmission set CLASS='" + "8" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("8")) {
//                                String query = ("update newadmission set CLASS='" + "9" +"' WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                        else if (class1.equals("9")) {
//                                String query = ("update newadmission set CLASS='" + "10" +"'WHERE CLASS='"+class1+"'");
//                                changeClass(query);
//                            }
//                    }
//            }
//        catch(SQLException sql){
////              JOptionPane.showMessageDialog(this, sql);
//            }
//
//    }
    }
//private void changeClass(String query){
//    try{            
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
//            stmt.executeUpdate(query);
//            con.setAutoCommit(true);
//            //stmt.close();
//    }
//    catch(SQLException sql){
////        JOptionPane.showMessageDialog(this, sql);
//    }
//}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jm1 = new javax.swing.JMenu();
        jmi1 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenu3 = new javax.swing.JMenu();
        jmi22 = new javax.swing.JMenuItem();
        jSeparator14 = new javax.swing.JPopupMenu.Separator();
        jmi2 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jmi3 = new javax.swing.JMenuItem();
        jm7 = new javax.swing.JMenu();
        jmi16 = new javax.swing.JMenuItem();
        jSeparator10 = new javax.swing.JPopupMenu.Separator();
        jmi17 = new javax.swing.JMenuItem();
        jSeparator11 = new javax.swing.JPopupMenu.Separator();
        jmi18 = new javax.swing.JMenuItem();
        jSeparator12 = new javax.swing.JPopupMenu.Separator();
        jmi38 = new javax.swing.JMenuItem();
        jSeparator29 = new javax.swing.JPopupMenu.Separator();
        jmi19 = new javax.swing.JMenuItem();
        jm2 = new javax.swing.JMenu();
        jmi4 = new javax.swing.JMenuItem();
        jSeparator15 = new javax.swing.JPopupMenu.Separator();
        jmi23 = new javax.swing.JMenuItem();
        jm3 = new javax.swing.JMenu();
        jmi5 = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jmi6 = new javax.swing.JMenuItem();
        jm4 = new javax.swing.JMenu();
        jmi7 = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        jmi8 = new javax.swing.JMenuItem();
        jm5 = new javax.swing.JMenu();
        jmi10 = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JPopupMenu.Separator();
        jmi20 = new javax.swing.JMenuItem();
        jSeparator18 = new javax.swing.JPopupMenu.Separator();
        jmi26 = new javax.swing.JMenuItem();
        jSeparator25 = new javax.swing.JPopupMenu.Separator();
        jmi34 = new javax.swing.JMenuItem();
        jSeparator26 = new javax.swing.JPopupMenu.Separator();
        jmi35 = new javax.swing.JMenuItem();
        jSeparator28 = new javax.swing.JPopupMenu.Separator();
        jmi37 = new javax.swing.JMenuItem();
        jm8 = new javax.swing.JMenu();
        jmi29 = new javax.swing.JMenuItem();
        jSeparator21 = new javax.swing.JPopupMenu.Separator();
        jmi30 = new javax.swing.JMenuItem();
        jSeparator22 = new javax.swing.JPopupMenu.Separator();
        jmi31 = new javax.swing.JMenuItem();
        jSeparator23 = new javax.swing.JPopupMenu.Separator();
        jmi32 = new javax.swing.JMenuItem();
        jm6 = new javax.swing.JMenu();
        jmi11 = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        jmi12 = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        jMenu2 = new javax.swing.JMenu();
        jmi13 = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        jmi14 = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        jmi21 = new javax.swing.JMenuItem();
        jSeparator13 = new javax.swing.JPopupMenu.Separator();
        jmi24 = new javax.swing.JMenuItem();
        jSeparator17 = new javax.swing.JPopupMenu.Separator();
        jmi25 = new javax.swing.JMenuItem();
        jSeparator24 = new javax.swing.JPopupMenu.Separator();
        jmi33 = new javax.swing.JMenuItem();
        jSeparator16 = new javax.swing.JPopupMenu.Separator();
        jmi27 = new javax.swing.JMenuItem();
        jSeparator19 = new javax.swing.JPopupMenu.Separator();
        jmi28 = new javax.swing.JMenuItem();
        jSeparator20 = new javax.swing.JPopupMenu.Separator();
        jmi36 = new javax.swing.JMenuItem();
        jSeparator27 = new javax.swing.JPopupMenu.Separator();
        jmi15 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("New Admission");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jMenuBar1.setNextFocusableComponent(this);
        jMenuBar1.setPreferredSize(new java.awt.Dimension(56, 30));

        jm1.setText("Cash Collection");
        jm1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jm1.setVerifyInputWhenFocusTarget(false);

        jmi1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi1.setText("Students Fee");
        jmi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi1ActionPerformed(evt);
            }
        });
        jm1.add(jmi1);
        jm1.add(jSeparator1);

        jMenu3.setText("Misc Collection");
        jMenu3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi22.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi22.setText("Stationery");
        jmi22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi22ActionPerformed(evt);
            }
        });
        jMenu3.add(jmi22);
        jMenu3.add(jSeparator14);

        jmi2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi2.setText("Loan");
        jmi2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi2ActionPerformed(evt);
            }
        });
        jMenu3.add(jmi2);
        jMenu3.add(jSeparator2);

        jmi3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi3.setText("Donation");
        jmi3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi3ActionPerformed(evt);
            }
        });
        jMenu3.add(jmi3);

        jm1.add(jMenu3);

        jMenuBar1.add(jm1);

        jm7.setText("Admission");
        jm7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi16.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi16.setText("New Admission");
        jmi16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi16ActionPerformed(evt);
            }
        });
        jm7.add(jmi16);
        jm7.add(jSeparator10);

        jmi17.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi17.setText("Update Student Details");
        jmi17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi17ActionPerformed(evt);
            }
        });
        jm7.add(jmi17);
        jm7.add(jSeparator11);

        jmi18.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi18.setText("Update Previous Study Details");
        jmi18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi18ActionPerformed(evt);
            }
        });
        jm7.add(jmi18);
        jm7.add(jSeparator12);

        jmi38.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi38.setText("Attendence");
        jmi38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi38ActionPerformed(evt);
            }
        });
        jm7.add(jmi38);
        jm7.add(jSeparator29);

        jmi19.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi19.setText("All Admission Record");
        jmi19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi19ActionPerformed(evt);
            }
        });
        jm7.add(jmi19);

        jMenuBar1.add(jm7);

        jm2.setText("Staff Record");
        jm2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi4.setText("New Staff");
        jmi4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi4ActionPerformed(evt);
            }
        });
        jm2.add(jmi4);
        jm2.add(jSeparator15);

        jmi23.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi23.setText("Old Staff");
        jmi23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi23ActionPerformed(evt);
            }
        });
        jm2.add(jmi23);

        jMenuBar1.add(jm2);

        jm3.setText("Payment");
        jm3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi5.setText("PMT School Staff");
        jmi5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi5ActionPerformed(evt);
            }
        });
        jm3.add(jmi5);
        jm3.add(jSeparator3);

        jmi6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi6.setText("Misc Payments");
        jmi6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi6ActionPerformed(evt);
            }
        });
        jm3.add(jmi6);

        jMenuBar1.add(jm3);

        jm4.setText("Cash Posting");
        jm4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi7.setText("To Bank");
        jmi7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi7ActionPerformed(evt);
            }
        });
        jm4.add(jmi7);
        jm4.add(jSeparator4);

        jmi8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi8.setText("To Fund");
        jmi8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi8ActionPerformed(evt);
            }
        });
        jm4.add(jmi8);

        jMenuBar1.add(jm4);

        jm5.setText("Records");
        jm5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi10.setText("All Records");
        jmi10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi10ActionPerformed(evt);
            }
        });
        jm5.add(jmi10);
        jm5.add(jSeparator9);

        jmi20.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi20.setText("View Login Records");
        jmi20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi20ActionPerformed(evt);
            }
        });
        jm5.add(jmi20);
        jm5.add(jSeparator18);

        jmi26.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi26.setText("Stationery Record");
        jmi26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi26ActionPerformed(evt);
            }
        });
        jm5.add(jmi26);
        jm5.add(jSeparator25);

        jmi34.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi34.setText("NOC_Record");
        jmi34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi34ActionPerformed(evt);
            }
        });
        jm5.add(jmi34);
        jm5.add(jSeparator26);

        jmi35.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi35.setText("Print Report");
        jmi35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi35ActionPerformed(evt);
            }
        });
        jm5.add(jmi35);
        jm5.add(jSeparator28);

        jmi37.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi37.setText("Print Dues Report");
        jmi37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi37ActionPerformed(evt);
            }
        });
        jm5.add(jmi37);

        jMenuBar1.add(jm5);

        jm8.setText("Vehicle");
        jm8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi29.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi29.setText("Add New/Search");
        jmi29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi29ActionPerformed(evt);
            }
        });
        jm8.add(jmi29);
        jm8.add(jSeparator21);

        jmi30.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi30.setText("Tax/Insurance/Fitness Details");
        jmi30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi30ActionPerformed(evt);
            }
        });
        jm8.add(jmi30);
        jm8.add(jSeparator22);

        jmi31.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi31.setText("Vehicles Query");
        jmi31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi31ActionPerformed(evt);
            }
        });
        jm8.add(jmi31);
        jm8.add(jSeparator23);

        jmi32.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi32.setText("All Vehicle Record");
        jmi32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi32ActionPerformed(evt);
            }
        });
        jm8.add(jmi32);

        jMenuBar1.add(jm8);

        jm6.setText("Home");
        jm6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi11.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi11.setText("New User");
        jmi11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi11ActionPerformed(evt);
            }
        });
        jm6.add(jmi11);
        jm6.add(jSeparator6);

        jmi12.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi12.setText("Modify User");
        jmi12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi12ActionPerformed(evt);
            }
        });
        jm6.add(jmi12);
        jm6.add(jSeparator7);

        jMenu2.setText("Delete User");
        jMenu2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jmi13.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi13.setText("All User");
        jmi13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi13ActionPerformed(evt);
            }
        });
        jMenu2.add(jmi13);
        jMenu2.add(jSeparator8);

        jmi14.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi14.setText("Specific User");
        jmi14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi14ActionPerformed(evt);
            }
        });
        jMenu2.add(jmi14);

        jm6.add(jMenu2);
        jm6.add(jSeparator5);

        jmi21.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi21.setText("Fee_Details");
        jmi21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi21ActionPerformed(evt);
            }
        });
        jm6.add(jmi21);
        jm6.add(jSeparator13);

        jmi24.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi24.setText("Set_Section");
        jmi24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi24ActionPerformed(evt);
            }
        });
        jm6.add(jmi24);
        jm6.add(jSeparator17);

        jmi25.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi25.setText("Print Leaving");
        jmi25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi25ActionPerformed(evt);
            }
        });
        jm6.add(jmi25);
        jm6.add(jSeparator24);

        jmi33.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi33.setText("Print_NOC");
        jmi33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi33ActionPerformed(evt);
            }
        });
        jm6.add(jmi33);
        jm6.add(jSeparator16);

        jmi27.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi27.setText("Total Collection");
        jmi27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi27ActionPerformed(evt);
            }
        });
        jm6.add(jmi27);
        jm6.add(jSeparator19);

        jmi28.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi28.setText("Total Expenses");
        jmi28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi28ActionPerformed(evt);
            }
        });
        jm6.add(jmi28);
        jm6.add(jSeparator20);

        jmi36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi36.setText("Balance Sheet");
        jmi36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi36ActionPerformed(evt);
            }
        });
        jm6.add(jmi36);
        jm6.add(jSeparator27);

        jmi15.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jmi15.setText("Exit");
        jmi15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmi15ActionPerformed(evt);
            }
        });
        jm6.add(jmi15);

        jMenuBar1.add(jm6);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        int k = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Exit?", "Exit From Application", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (k == JOptionPane.YES_OPTION) {
        if(LoginPanel.logincheck==1){
        NewJPanel.jPanel3.setBounds(600, 350,400,73);
        NewJPanel.jPanel3.setVisible(true);
        NewJPanel.t.start();
        Thread t = new Thread(new Runnable() {

                    @Override
                    public void run() {
                try{Thread.sleep(44);
                backupDatabase();
                }catch(Exception e){}
                    }
                });
            t.start();
        
            }
       else{
                System.exit(0);
            }
        }
    }//GEN-LAST:event_formWindowClosing
private void backupDatabase(){
       // NewJPanel.jPanel3.setBounds(600, 350,400,73);
       // NewJPanel.jPanel3.setVisible(true);
        File file = new File("D:\\BackupHHAcademy");
	if (!file.exists()) {
		if (file.mkdir()) {
			System.out.println("Directory is created!");
		} else {
			System.out.println("Failed to create directory!");
		}
        }
        String executeCmd = String.format("exp aman/123 file=D:/BackupHHAcademy/DatabaseHHA.dmp direct=y consistent=y statistics='none'");
        Process runtimeProcess;        
        try {                
            runtimeProcess = Runtime.getRuntime().exec(executeCmd);
            int processComplete = runtimeProcess.waitFor(); 
            if (processComplete == 0) {
                NewJPanel.jPanel3.setVisible(true);                
                JOptionPane.showMessageDialog(rootPane, "Backup Created Successfully");
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Could Not Create The Backup");
                System.exit(0);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
}
    private void jmi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi1ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==1||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi1.setEnabled(false);
            stdfee = new StudentsFee();
            stdfee.setVisible(true);
            stdfee.setBounds(384, 30, 581, 378);
            stdfee.setExtendedState(MAXIMIZED_BOTH);
            count3 = 1;
        }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi1ActionPerformed
public static String convertDigit(int length,String amount){
            int len=length;
            String amt=amount;            
            if(len==1){
                for(int i=0; i<onedigit.length;i++){
                    if(Integer.parseInt(amt)==i+1){
                        result=onedigit[i]+" ";
                        break;
                    }
                }
            }
            else if(len==2){
                String temp="",temp1="";
                String sub1=amt.substring(0, 1);//12
                String sub2=amt.substring(1,amt.length());//22
                if(sub1.equals("1")){
                  for(int i=0; i<twodigit.length;i++){
                    if(Integer.parseInt(sub2)==i){
                        temp=twodigit[i]+" ";
                        break;
                    }
                }
                    }
                else{
                    for(int i=0; i<twodigt.length;i++){
                        if(Integer.parseInt(sub1)==i+2){
                        temp=twodigt[i]+" ";
                        if(sub2.equals("0")){
                            temp=twodigt[i]+" ";
                        }
                        else{
                            if(Integer.parseInt(sub2)>0){
                            temp1=convertDigit(1,sub2);
                        }
                        }
                        break;
                    }
                    }
                    
                }
                result=temp+temp1;
                temp="";temp1="";
            }
            else if(len==3){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 1);
               String sub2=amt.substring(1,amt.length());//201
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(1,sub1)+"Hundred"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3 = convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==4){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 1);
               String sub2=amt.substring(1,amt.length());//2011
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(1,sub1)+"Thousand"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==5){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 2);
               String sub2=amt.substring(2,amt.length());//20111
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(2,sub1)+"Thousand"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==6){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 1);
               String sub2=amt.substring(1,amt.length());//201111
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(1,sub1)+"Lakh"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==7){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 2);
               String sub2=amt.substring(2,amt.length());//2011111
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(2,sub1)+"Lakh"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==8){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 1);
               String sub2=amt.substring(1,amt.length());//20111111
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(1,sub1)+"Crore"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            else if(len==9){
                String temp2="",temp3="";
                String sub1=amt.substring(0, 2);
               String sub2=amt.substring(2,amt.length());//201111111
               int ndlen1=Integer.parseInt(sub2);
               String len3d=String.valueOf(ndlen1);
               int ndlen=len3d.length();
               temp2=convertDigit(2,sub1)+"Crore"+" ";
                 if(len3d.equals("0")){                     
                 }
                 else{
                temp3= convertDigit(ndlen,len3d);
                 }
                 result=temp2+temp3;
                 temp2="";temp3="";
            }
            return(result);
}
    private void jmi4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi4ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==2||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi4.setEnabled(false);
            schstf = new SchoolStaff();
            schstf.setVisible(true);
            schstf.setBounds(384, 30, 581, 378);
            schstf.setExtendedState(MAXIMIZED_BOTH);
            count6 = 1;
            if (LoginPanel.chek == 1) {
             SchoolStaff.btndelete.setEnabled(true);
        } else {
            SchoolStaff.btndelete.setEnabled(false);
        }
        }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi4ActionPerformed

    private void jmi5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi5ActionPerformed
        // TODO add your handling code here:
        if(jmi5.isEnabled()){
            jmi5.setEnabled(false);
            stfpay = new StaffPayment();
            stfpay.setVisible(true);
            stfpay.setBounds(384, 30, 581, 378);
            stfpay.setExtendedState(MAXIMIZED_BOTH);
            count7 = 1;
        }
    }//GEN-LAST:event_jmi5ActionPerformed

    private void jmi6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi6ActionPerformed
        // TODO add your handling code here:
        if(jmi6.isEnabled()){
            jmi6.setEnabled(false);
            micpay = new MiscPayment();
            micpay.setVisible(true);
            micpay.setBounds(384, 30, 581, 378);
            micpay.setExtendedState(MAXIMIZED_BOTH);
            count8 = 1;
            }
    }//GEN-LAST:event_jmi6ActionPerformed

    private void jmi7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi7ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==1||LoginPanel.chek==1||LoginPanel.admaccess1==1){ 
            jmi7.setEnabled(false);
            tbk = new ToBank();
            tbk.setVisible(true);
            tbk.setBounds(384, 30, 581, 378);
            tbk.setExtendedState(MAXIMIZED_BOTH);
            count9 = 1;
            }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi7ActionPerformed

    private void jmi8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi8ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==1||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi8.setEnabled(false);
            tfd = new ToFund();
            tfd.setVisible(true);
            tfd.setBounds(384, 30, 581, 378);
            tfd.setExtendedState(MAXIMIZED_BOTH);
            count10 = 1;
            }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi8ActionPerformed

    private void jmi2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi2ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==1||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi2.setEnabled(false);
            lon = new Loan();
            lon.setVisible(true);
            lon.setBounds(384, 30, 581, 378);
            lon.setExtendedState(MAXIMIZED_BOTH);
            count4 = 1;
            }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi2ActionPerformed

    private void jmi3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi3ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==1||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi3.setEnabled(false);
            don = new Donation();
            don.setVisible(true);
            don.setBounds(384, 30, 581, 378);
            don.setExtendedState(MAXIMIZED_BOTH);
            count5 = 1;
            }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi3ActionPerformed

    private void jmi15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi15ActionPerformed
        // TODO add your handling code here:
        int k = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Exit?", "Exit From Application", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (k == JOptionPane.YES_OPTION) {
            if(LoginPanel.logincheck==1){
        backupDatabase();
            }
       else{
                System.exit(0);
            }
        }
    }//GEN-LAST:event_jmi15ActionPerformed

    private void jmi10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi10ActionPerformed
        // TODO add your handling code here:
        jmi10.setEnabled(false);
        rdw = new RecordWindow();
        rdw.setVisible(true);
        rdw.setBounds(384, 30, 581, 378);
        rdw.setExtendedState(MAXIMIZED_BOTH);
        count11 = 1;
    }//GEN-LAST:event_jmi10ActionPerformed

    private void jmi13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi13ActionPerformed
        // TODO add your handling code here:
        if (LoginPanel.chek == 1) {
            int k = JOptionPane.showConfirmDialog(rootPane, "Are you Sure? You Want To Delete All Users.", "Deleting All Users", JOptionPane.WARNING_MESSAGE);
            if (k == JOptionPane.YES_OPTION) {
                try {
//                    java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                    String str = "DELETE FROM USER_LOGIN";
                    stmt = con.createStatement();
                    stmt.executeUpdate(str);
                    stmt.close();
//                    con.close();
                    JOptionPane.showMessageDialog(this, "All Users Are Successfully Deleted", "", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "No User Found!", "Deleting All Users", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi13ActionPerformed
    public void deleteSingleUser(String arg) {
        if (arg == null) {
        } else if (arg.equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Plese Enter Valid ID", "Deleting Single User", JOptionPane.INFORMATION_MESSAGE, null);
            arg = JOptionPane.showInputDialog(rootPane, "Enter User ID To Delete User", "Deleting Single User", JOptionPane.QUESTION_MESSAGE);
            deleteSingleUser(arg);
        } else {
            boolean flag = false;
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1 = "SELECT USER_ID FROM USER_LOGIN";
                rs = stmt.executeQuery(str1);
                while (rs.next()) {
                    if (rs.getString(1).equalsIgnoreCase(arg)) {
                        arg = rs.getString(1);
                        flag = true;
                        break;
                    }
                }
                stmt.close();
                rs.close();
//                con.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "No User Found", "Deleting Single User", JOptionPane.INFORMATION_MESSAGE);
            }
            if (flag == true) {
                try {
//                    java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                    String str = "DELETE FROM USER_LOGIN WHERE USER_ID='" + arg + "'";
                    stmt = con.createStatement();
                    stmt.executeUpdate(str);
                    JOptionPane.showMessageDialog(this, "User Successfully Deleted", "Deleting Single User", JOptionPane.INFORMATION_MESSAGE);
                    stmt.close();
//                    con.close();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "No User Found", "Deleting Single User", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No User Found For Given ID.Plese Enter Valid ID", "Deleting Single User", JOptionPane.ERROR_MESSAGE);
                arg = JOptionPane.showInputDialog(rootPane, "Enter User ID To Delete User", "Deleting Single User", JOptionPane.QUESTION_MESSAGE);
                deleteSingleUser(arg);
            }
        }
    }
    private void jmi14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi14ActionPerformed
        // TODO add your handling code here:
        if (LoginPanel.chek == 1) {
            String k = JOptionPane.showInputDialog(rootPane, "Enter User ID To Delete User", "Deleting Single User", JOptionPane.QUESTION_MESSAGE);
            deleteSingleUser(k);
        } else {
            JOptionPane.showMessageDialog(rootPane, "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi14ActionPerformed

    private void jmi11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi11ActionPerformed
        // TODO add your handling code here:
        if (LoginPanel.chek == 1) {
            count12 = 1;
            jmi11.setEnabled(false);
            nur = new NewUser();
            nur.setVisible(true);
            nur.setExtendedState(JFrame.MAXIMIZED_BOTH);
        } else {
            JOptionPane.showMessageDialog(rootPane, "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi11ActionPerformed

    private void jmi12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi12ActionPerformed
        // TODO add your handling code here:
        if (LoginPanel.chek == 1) {
            count13 = 1;
            jmi12.setEnabled(false);
            userup = new UserUpdate();
            userup.setVisible(true);
            userup.setExtendedState(JFrame.MAXIMIZED_BOTH);
        } else {
            JOptionPane.showMessageDialog(rootPane, "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi12ActionPerformed

    private void jmi16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi16ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.admaccess==2||LoginPanel.chek==1||LoginPanel.admaccess1==1){
            jmi16.setEnabled(false);
            num1 = 1;
            admp = new NewAdmPanel();
            jsp = new javax.swing.JScrollPane(admp);
            jsp.setBounds(0, 0, 1366, 707);
            AdmissionOpen.njp.setVisible(false);
            newadmpanel=new NewAdmissionPanel();
            newadmpanel.add(jsp);
            admop.add(newadmpanel);
            newadmpanel.updateUI();
            jsp.updateUI();
            admp.updateUI();
            admp.grabFocus();
        }
        else{
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi16ActionPerformed
public void update(){
            if (count == 0) {
                int a = 0;
                boolean flag = false;
//                int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                String r = JOptionPane.showInputDialog(this.getParent(), "Enter ADMISSION No. To Update");
                if (r == null || r.equals("")) {
                    NewJPanel.lblupdate.setEnabled(true);
                } else {
                    try {
//                        java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                        String str = "SELECT ADMISSION_NO FROM NEWADMISSION";
                        rs = stmt.executeQuery(str);
                        while (rs.next()) {
                            if (rs.getString(1).equals(r.toUpperCase())) {
                                flag = true;
                                NewJPanel.lblupdate.setEnabled(false);
                                break;
                            }
                        }
                        if (flag == true) {
                            a = 1;
                            String fetch = "select * from newadmission where ADMISSION_NO='" + r.toUpperCase() + "'";
                            rs = stmt.executeQuery(fetch);
                            while (rs.next()) {
                                String admno = rs.getString(1);
                                String admfee = rs.getString(3);
                                String stdname=rs.getString(4);
                                String dob = String.valueOf(rs.getDate(5));//"1991-11-06"
                                String d = dob.substring(0, 4);
                                String d1 = dob.substring(5, 7);
                                String d2 = dob.substring(8, 10);
                                String dd = d2.concat("-").concat(d1).concat("-").concat(d);
                                String age=rs.getString(6);
                                String rollno = rs.getString(7);
                                String class1 = rs.getString(8);
                                String section = rs.getString(9);
                                String caste = rs.getString(10);
                                String gender = rs.getString(11);
                                String photo = rs.getString(12);
                                String fname = rs.getString(13);
                                String fqauli = rs.getString(14);
                                String faccup = rs.getString(15);
                                String fcont = rs.getString(16);
                                String fdesig = rs.getString(17);
                                String fcomp = rs.getString(18);
                                String fcompadd = rs.getString(19);
                                String mname = rs.getString(20);
                                String mqauli = rs.getString(21);
                                String maccup = rs.getString(22);
                                String mcont = rs.getString(23);
                                String mdesig = rs.getString(24);
                                String mcomp = rs.getString(25);
                                String mcompadd = rs.getString(26);
//                                String course1 = rs.getString(27);
//                                String course2 = rs.getString(28);
//                                String sub1 = rs.getString(29);
//                                String sub2 = rs.getString(30);
//                                String sub3 = rs.getString(31);
//                                String sub4 = rs.getString(32);
//                                String sub5 = rs.getString(33);
//                                String sub6 = rs.getString(34);
//                                String sub7 = rs.getString(35);
//                                String sub8 = rs.getString(36);
//                                String sub9 = rs.getString(37);
//                                String sub10 = rs.getString(38);
//                                String sub11 = rs.getString(39);
                                String f40 = String.valueOf(rs.getDate(45));
                                String yg = f40.substring(0, 4);
                                String mg = f40.substring(5, 7);
                                String dg = f40.substring(8, 10);
                                String dmy = dg.concat("-").concat(mg).concat("-").concat(yg);//2014-03-09
                                String time = String.valueOf(rs.getString(46));
                                String religion = rs.getString(48);
                                String blood = rs.getString(49);
                                String mark = rs.getString(50);
                                String stdadd = rs.getString(51);
                                String village=rs.getString(70);
                                String transfee=rs.getString(71);
                                upd = new UpdateRecord();
                                upd.setBounds(384, 30, 581, 378);
                                upd.setExtendedState(JFrame.MAXIMIZED_BOTH);
                                upd.setVisible(true);
                                upd.repaint();
                                AdmUpdate addp = new AdmUpdate();
                                addp.repaint();
                                jjp = new javax.swing.JScrollPane(addp);
                                upd.add(jjp);                               
                                AdmUpdate.lbladmissiondate.setText("Admission Date:".concat(dmy));
                                AdmUpdate.lbladmtime.setText("Admission Time:".concat(time));
                                addp.click(a, admno,admfee,stdname, dd,age, rollno, class1, section, caste, gender, photo, fname, fqauli, faccup, fcont, fdesig, fcomp, fcompadd,mname, mqauli, maccup, mcont, mdesig, mcomp, mcompadd, religion, blood, mark, stdadd,village,transfee);
                                count = 1;
                                jmi17.setEnabled(false);
                                break;
                            }
                        } else {
                            JOptionPane.showMessageDialog(this.getParent(), "No Any Student of This Admission NO.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
//                        con.close();
                        stmt.close();
                        rs.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(this.getParent(), "No Record Found.");
                    }
                }
            }
}
    private void jmi17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi17ActionPerformed
        // TODO add your handling code here:
        update();
    }//GEN-LAST:event_jmi17ActionPerformed
public void previousUpdate(){
            if (count2 == 0) {
                int a = 0;
                boolean flag = false;
//                int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                String r = JOptionPane.showInputDialog(this.getParent(), "Enter ADMISSION No. To Update");
                if (r == null || r.equals("")) {
                } else {
                    try {
//                        java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                        String str = "SELECT ADMISSION_NO,CLASS FROM NEWADMISSION";
                        rs = stmt.executeQuery(str);
                        while (rs.next()) {
                            if (rs.getString(1).equals(r.toUpperCase())) {
                                String class1=rs.getString(2);
                                if(class1.equals("Kids")||class1.equals("Nursery")||class1.equals("L.K.G")||class1.equals("U.K.G")){
                                    flag=false;
                                }
                                else{
                                int s = Integer.parseInt(class1);
                                if (s > 1) {
                                    flag = true;
                                    break;
                                }
                                }

                            }
                        }
                        if (flag == true) {
                            roll = r;
                            a = 1;
                            String fetch = "select SLC_NO,SCHOOL_NAME,SCHOOL_ADD,STUDENT_CHAR,ISSUE_DATE from newadmission where ADMISSION_NO='" + r.toUpperCase() + "'";
                            rs = stmt.executeQuery(fetch);
                            while (rs.next()) {
                                String f34 = rs.getString(1);
                                String f35 = rs.getString(2);
                                String f36 = rs.getString(3);
                                String f37 = rs.getString(4);
                                String f38 = String.valueOf(rs.getDate(5));//"1991-11-06"
                                String d = f38.substring(0, 4);
                                String d1 = f38.substring(5, 7);
                                String d2 = f38.substring(8, 10);
                                String dd = d2.concat("-").concat(d1).concat("-").concat(d);
                                ftd = new FetchData();
                                ftd.setBounds(384, 30, 581, 378);
                                ftd.setExtendedState(JFrame.MAXIMIZED_BOTH);
                                PreviousStudy prvd = new PreviousStudy();
                                prvd.setBounds(350, 140, 700, 430);
                                FetchData.jp1.add(prvd);
                                FetchData.jp1.updateUI();
                                prvd.updateUI();
                                ftd.setVisible(true);
                                PreviousStudy.fetch(a, f34, f35, f36, f37, dd);
                                count2 = 1;
                                jmi18.setEnabled(false);
                                NewJPanel.lblupdprev.setEnabled(false);
                            }
                        } else {
                            JOptionPane.showMessageDialog(this.getParent(), "No Previous Details Found.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this.getParent(), "No Record Found.");
                    }
                }
            }
}
    private void jmi18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi18ActionPerformed
        // TODO add your handling code here:
        previousUpdate();
    }//GEN-LAST:event_jmi18ActionPerformed
public static void logOut() {
                NewJPanel.lbladmission.setVisible(false);
                NewJPanel.lblupdate.setVisible(false);
                NewJPanel.lblupdprev.setVisible(false);
                NewJPanel.lblall.setVisible(false);
                NewJPanel.lbltotstd.setVisible(false);
                NewJPanel.lblnewadm.setVisible(false);
                NewJPanel.lblfee.setVisible(false);
                NewJPanel.lblst.setVisible(false);
                NewJPanel.lblloan.setVisible(false);
                NewJPanel.lbldonation.setVisible(false);
                NewJPanel.lblnewstaff.setVisible(false);
                NewJPanel.lbloldstf.setVisible(false);
                NewJPanel.lblschoolstf.setVisible(false);
                NewJPanel.lblmisc.setVisible(false);
                NewJPanel.lblbank.setVisible(false);
                NewJPanel.lblfund.setVisible(false);
                NewJPanel.lbllogout.setVisible(false);
                LoginPanel.lbl1.setVisible(false);
                NewJPanel.lbladmission.setEnabled(true);
                NewJPanel.lblupdate.setEnabled(true);
                NewJPanel.lblupdprev.setEnabled(true);
                NewJPanel.lblall.setEnabled(true);
                NewJPanel.lbltotstd.setEnabled(true);
                NewJPanel.lblnewadm.setEnabled(true);
                NewJPanel.lblfee.setEnabled(true);
                NewJPanel.lblst.setEnabled(true);
                NewJPanel.lblloan.setEnabled(true);
                NewJPanel.lbldonation.setEnabled(true);
                NewJPanel.lblnewstaff.setEnabled(true);
                NewJPanel.lbloldstf.setEnabled(true);
                NewJPanel.lblschoolstf.setEnabled(true);
                NewJPanel.lblmisc.setEnabled(true);
                NewJPanel.lblbank.setEnabled(true);
                NewJPanel.lblfund.setEnabled(true);
                NewJPanel.jPanel2.setBounds(0, 90, 250, 580);
        AdmissionOpen.hmp.setVisible(true);
        AdmissionOpen.hmp1.setVisible(true);
        NewJPanel.jPanel1.setVisible(false);
        NewJPanel.lbllowest.setVisible(false);
        jm1.setVisible(false);
        jm2.setVisible(false);
        jm3.setVisible(false);
        jm4.setVisible(false);
        jm5.setVisible(false);
        jm6.setVisible(false);
        jm7.setVisible(false);
        jm8.setVisible(false);
        jmi1.setEnabled(true);
        jmi2.setEnabled(true);
        jmi3.setEnabled(true);
        jmi4.setEnabled(true);
        jmi5.setEnabled(true);
        jmi6.setEnabled(true);
        jmi7.setEnabled(true);
        jmi8.setEnabled(true);
        jmi10.setEnabled(true);
        jmi11.setEnabled(true);
        jmi12.setEnabled(true);
        jmi16.setEnabled(true);
        jmi17.setEnabled(true);
        jmi18.setEnabled(true);
        jmi19.setEnabled(true);
        jmi20.setEnabled(true);
        jmi21.setEnabled(true);
        jmi22.setEnabled(true);
        jmi23.setEnabled(true);
        jmi24.setEnabled(true);
        jmi25.setEnabled(true);
        jmi26.setEnabled(true);
        jmi27.setEnabled(true);
        jmi28.setEnabled(true);
        jmi29.setEnabled(true);
        jmi30.setEnabled(true);
        jmi31.setEnabled(true);
        jmi32.setEnabled(true);
        jmi33.setEnabled(true);
        jmi34.setEnabled(true);
        jmi35.setEnabled(true);
        jmi36.setEnabled(true);
        jmi37.setEnabled(true);
        jmi38.setEnabled(true);
        if (num1 == 1) {
            admop.remove(newadmpanel);
        }
        if (NewAdmPanel.num == 1) {
            newadmpanel.remove(NewAdmPanel.prvdp);
            admop.remove(newadmpanel);
        }
        if (NewAdmPanel.num2 == 1) {
            newadmpanel.remove(NewAdmPanel.admf);
            admop.remove(newadmpanel);
        }
        if (count1 == 1) {
            alp.dispose();
        }
        if (count == 1) {
            upd.dispose();
        }
        if (count2 == 1) {
            ftd.dispose();
        }
        if (count3 == 1) {
            stdfee.dispose();
        }
        if (count4 == 1) {
           lon.dispose();
        }
        if (count5 == 1) {
            don.dispose();
        }
        if (count6 == 1) {
            schstf.dispose();
        }
        if (count7 == 1) {
            stfpay.dispose();
        }
        if (count8 == 1) {
            micpay.dispose();
        }
        if (count9 == 1) {
            tbk.dispose();
        }
        if (count10 == 1) {
            tfd.dispose();
        }
        if (count11 == 1) {
            rdw.dispose();
        }
        if (count12 == 1) {
            nur.dispose();
        }
        if (count13 == 1) {
            userup.dispose();
        }
        if (count14 == 1) {
            lrd.dispose();
        }
        if (count15 == 1) {
            feedt.dispose();
        }
        if (count16 == 1) {
            station.dispose();
        }
        if (count17 == 1) {
            ssc.dispose();
        }
        if (count18 == 1) {
            leav.dispose();
        }
        if (count19 == 1) {
            stsrec.dispose();
        }
        if (count20 == 1) {
            totcolt.dispose();
        }
        if (count21 == 1) {
            totexp.dispose();
        }
        if (count22 == 1) {
            vd.dispose();
        }
        if (count23 == 1) {
            rd.dispose();
        }
        if (count24 == 1) {
            vehquery.dispose();
        }
        if (count25 == 1) {
            avr.dispose();
        }
        if (count26 == 1) {
            noc.dispose();
        }
        if (count27 == 1) {
            nocr.dispose();
        }
        if (count28 == 1) {
            treport.dispose();
        }
        if (count29 == 1) {
            balsheet.dispose();
        }
        if (count30 == 1) {
            durept.dispose();
        }
        if (count31 == 1) {
            atnpg.dispose();
        }
        if (stfcount == 1) {
            oldstf.dispose();
        }
        if(NewJPanel.totstd==1){
            NewJPanel.tsf.dispose();
        }
        if(NewJPanel.totnewadm==1){
            NewJPanel.newadm.dispose();
        }
        njp.setVisible(true);
        njp.updateUI();
        count = 0;
        count1 = 0;
        count2 = 0;        
        count3 = 0;
        count4 = 0;
        count5 = 0;
        count6 = 0;
        count7 = 0;
        stfcount = 0;
        count8 = 0;
        count9 = 0;
        count10 = 0;
        count16=0;
        count25=0;
        count27=0;
        LoginPanel.admaccess=0;
        LoginPanel.chek=0;
            NewJPanel.adm=0;
            NewJPanel.cash=0;
            NewJPanel.stf=0;
            NewJPanel.ac=0;
            NewJPanel.camp=0;
            NewJPanel.dept=0;
            NewJPanel.std=0;
            NewJPanel.gen=0;
            NewJPanel.lib=0;
            NewJPanel.lab=0;
            NewJPanel.host=0;
            NewJPanel.trans=0;
            NewJPanel.cant=0;
            NewJPanel.invent=0;
}
    private void jmi19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi19ActionPerformed
        // TODO add your handling code here:
        if (count1 == 0) {
            jmi19.setEnabled(false);
            count1 = 1;
            arp = new AllRecord();
            alp = new AllRecordForm();
            alp.setVisible(true);
            alp.setBounds(384, 30, 581, 378);
            alp.setExtendedState(JFrame.MAXIMIZED_BOTH);
            alp.add(arp);            
        }
    }//GEN-LAST:event_jmi19ActionPerformed

    private void jmi20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi20ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.chek==1){
            jmi20.setEnabled(false);
            lrd=new LoginRecord();
            lrd.setBounds(405, 100, 570, 378);
            lrd.setVisible(true);            
            count14=1;
        }
        else {
            JOptionPane.showMessageDialog(this.getParent(), "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi20ActionPerformed

    private void jmi21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi21ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.chek==1){
            jmi21.setEnabled(false);
            feedt=new FeeDetails();
            feedt.setVisible(true);
            feedt.setBounds(384, 30, 581, 378);
            feedt.setExtendedState(MAXIMIZED_BOTH);
            count15=1;
        }
        else {
            JOptionPane.showMessageDialog(this.getParent(), "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi21ActionPerformed

    private void jmi22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi22ActionPerformed
        // TODO add your handling code here:
        if(LoginPanel.chek==1||LoginPanel.admaccess==1||LoginPanel.admaccess1==1){
            jmi22.setEnabled(false);
            station=new Stationery();
            station.setVisible(true);
            station.setBounds(384, 30, 581, 378);
            station.setExtendedState(MAXIMIZED_BOTH);
            count16=1;
        }
        else {
            JOptionPane.showMessageDialog(rootPane, "Accessibe By Other Users");
        }
    }//GEN-LAST:event_jmi22ActionPerformed

    private void jmi23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi23ActionPerformed
        // TODO add your handling code here:
        if (stfcount == 0) {
            jmi23.setEnabled(false);
            old=1;
            AllRecordPanel.staffRecord();
            oldstf = new OldStaff();
            jScrollPane1 = new JScrollPane(AllRecordPanel.jTable1);
            oldstf.add(jScrollPane1);
            oldstf.setVisible(true);
            oldstf.setBounds(384, 30, 581, 378);
            oldstf.setExtendedState(JFrame.MAXIMIZED_BOTH);
            stfcount = 1;
            old=0;
            if (AllRecordPanel.flag==false) {
                JOptionPane.showMessageDialog(this.getParent(), "No Reccords Found.", "All Records", JOptionPane.ERROR_MESSAGE);
        }
        }
    }//GEN-LAST:event_jmi23ActionPerformed

    private void jmi24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi24ActionPerformed
        // TODO add your handling code here:
//        PrintDonation prntdon=new PrintDonation(this,true);
//        prntdon.setBounds(300, 20, 670, 600);
//        prntdon.setVisible(true);
//        if(LoginPanel.chek==1){
//            jmi24.setEnabled(false);
//            ssc= new SetSection();
//            ssc.setBounds(405, 100, 620, 360);
//            ssc.setVisible(true);            
//            count17=1;
//        }
//        else {
//            JOptionPane.showMessageDialog(this.getParent(), "For Administrator Only!");
//        }
    }//GEN-LAST:event_jmi24ActionPerformed

    private void jmi25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi25ActionPerformed
        // TODO add your handling code here:
        boolean flag=false;
        if(LoginPanel.chek==1){
//            int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                String r = JOptionPane.showInputDialog(this.getParent(), "Please Enter ADMISSION NO.");
            if(r==null){
            }
            else{
            if (r.equals("")){
            } else {
                try {
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "SELECT ADMISSION_NO,STUDENT_NAME,STUDENT_DOB,CLASS,FATHER_NAME,MOTHER_NAME,STD_ADD,ADMISSION_DATE FROM NEWADMISSION WHERE ADMISSION_NO='" + r.toUpperCase()+ "'";
            rs = stmt.executeQuery(str);
            while(rs.next()){
                String admno=rs.getString(1);
                String name=rs.getString(2);
                String f40 = String.valueOf(rs.getDate(3));
                String yg = f40.substring(0, 4);
                String mg = f40.substring(5, 7);
                String dg = f40.substring(8, 10);
                String dmy = dg.concat("-").concat(mg).concat("-").concat(yg);//2014-03-09
                String class1=rs.getString(4);
                String fname=rs.getString(5);
                String mname=rs.getString(6);
                String stdadd=rs.getString(7);
                String doj = String.valueOf(rs.getDate(8));
                String doj1 = doj.substring(0, 4);
                String doj2 = doj.substring(5, 7);
                String doj3 = doj.substring(8, 10);
                String doj4 = doj3.concat("-").concat(doj2).concat("-").concat(doj1);//2014-03-09
                String curdate = NewJPanel.lbldate.getText().substring(5, 15);
                if(class1.equals("Kids")||class1.equals("Nursery")||class1.equals("L.K.G")||class1.equals("U.K.G")){
                }
                else{
                    class1=class1.concat("th");
                }
                leav= new LeavingForm();
                LeavingForm.lblstdname.setText(name);
                LeavingForm.lblfname.setText(fname);
                LeavingForm.lblmname.setText(mname);
                LeavingForm.txtadd.setText(stdadd);
                LeavingForm.lbldob.setText(dmy);
                LeavingForm.lbladmno.setText(admno);
                LeavingForm.lblclassr.setText(class1);
                LeavingForm.lblclassp.setText(doj4);
                LeavingForm.lbldol.setText(curdate);
                leav.setBounds(300, 20, 620, 600);
                leav.setVisible(true);
                jmi25.setEnabled(false);
                count18=1;
                flag=true;
                break;
            }
            if(flag==false){
            String str1 = "SELECT ADMISSION_NO,STUDENT_NAME,STUDENT_DOB,CLASS,FATHER_NAME,MOTHER_NAME,STD_ADD,ADMISSION_DATE FROM ADMISSION_HISTORY WHERE ADMISSION_NO='" + r.toUpperCase() + "'";
            rs = stmt.executeQuery(str1);
            while(rs.next()){
                String admno=rs.getString(1);
                String name=rs.getString(2);
                String f40 = String.valueOf(rs.getDate(3));
                String yg = f40.substring(0, 4);
                String mg = f40.substring(5, 7);
                String dg = f40.substring(8, 10);
                String dmy = dg.concat("-").concat(mg).concat("-").concat(yg);//2014-03-09
                String class1=rs.getString(4).concat("th");
                String fname=rs.getString(5);
                String mname=rs.getString(6);
                String stdadd=rs.getString(7);
                String curdate = NewJPanel.lbldate.getText().substring(5, 15);
                String doj = String.valueOf(rs.getDate(8));
                String doj1 = doj.substring(0, 4);
                String doj2 = doj.substring(5, 7);
                String doj3 = doj.substring(8, 10);
                String doj4 = doj3.concat("-").concat(doj2).concat("-").concat(doj1);//2014-03-09
                leav= new LeavingForm();
                LeavingForm.lblstdname.setText(name);
                LeavingForm.lblfname.setText(fname);
                LeavingForm.lblmname.setText(mname);
                LeavingForm.txtadd.setText(stdadd);
                LeavingForm.lbldob.setText(dmy);
                LeavingForm.lbladmno.setText(admno);
                LeavingForm.lblclassr.setText(class1);
                LeavingForm.lblclassp.setText(doj4);
                LeavingForm.lbldol.setText(curdate);
                leav.setBounds(300, 20, 620, 600); 
                leav.setVisible(true);
                jmi25.setEnabled(false);
                count18=1;                
                break;
            }
            }
            }
            catch(SQLException sq){
                JOptionPane.showMessageDialog(rootPane, "Record Not Found");
            }
            }            
        }
        }
        else {
            JOptionPane.showMessageDialog(this.getParent(), "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi25ActionPerformed

    private void jmi26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi26ActionPerformed
        // TODO add your handling code here:
        if(jmi26.isEnabled()){        
        jmi26.setEnabled(false);
        stsrec=new StationeryRecord();
        stsrec.setVisible(true);
        stsrec.setBounds(384, 30, 581, 378);
        stsrec.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count19=1;
        stscount=1;
        }
    }//GEN-LAST:event_jmi26ActionPerformed

    private void jmi27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi27ActionPerformed
        // TODO add your handling code here:
        if(jmi27.isEnabled()){
        jmi27.setEnabled(false);
        totcolt=new TotalCollection();
        totcolt.setVisible(true);
        totcolt.setBounds(384, 30, 581, 378);
        totcolt.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count20=1;
        totcollect=1;
        }
    }//GEN-LAST:event_jmi27ActionPerformed

    private void jmi28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi28ActionPerformed
        // TODO add your handling code here:
        if(jmi28.isEnabled()){
        jmi28.setEnabled(false);
        totexp=new TotalExpenses();
        totexp.setVisible(true);
        totexp.setBounds(384, 30, 581, 378);
        totexp.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count21=1;
        totalexp=1;       
        }
    }//GEN-LAST:event_jmi28ActionPerformed

    private void jmi29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi29ActionPerformed
        // TODO add your handling code here:
        if(jmi29.isEnabled()){
            jmi29.setEnabled(false);
            vd=new VehicleDetails();
            vd.setVisible(true);
            vd.setBounds(384, 30, 581, 378);
            vd.setExtendedState(JFrame.MAXIMIZED_BOTH);
            count22=1;
        }
    }//GEN-LAST:event_jmi29ActionPerformed

    private void jmi30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi30ActionPerformed
        // TODO add your handling code here:
        if(jmi30.isEnabled()){
            jmi30.setEnabled(false);
            rd=new VehicleRegistration();
            rd.setVisible(true);
            rd.setBounds(384, 30, 581, 378);
            rd.setExtendedState(JFrame.MAXIMIZED_BOTH);
            count23=1;
        }
    }//GEN-LAST:event_jmi30ActionPerformed

    private void jmi31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi31ActionPerformed
        // TODO add your handling code here:
        if(jmi31.isEnabled()){
        jmi31.setEnabled(false);
        vehquery=new VehicleQuery();
        vehquery.setVisible(true);
        vehquery.setBounds(384, 30, 581, 378);
        vehquery.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count24=1;
        vehcount=1;
        }
    }//GEN-LAST:event_jmi31ActionPerformed

    private void jmi32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi32ActionPerformed
        // TODO add your handling code here:
        if (count25 == 0&&jmi32.isEnabled()) {
            jmi32.setEnabled(false);
            count25 = 1;
            arp = new AllRecord();
            avr = new AllVehicleRecord();
            avr.setVisible(true);
            avr.setBounds(384, 30, 581, 378);
            avr.setExtendedState(JFrame.MAXIMIZED_BOTH);
            avr.add(arp);
        }
    }//GEN-LAST:event_jmi32ActionPerformed

    private void jmi33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi33ActionPerformed
        // TODO add your handling code here:
        boolean flag=false,flag1=false;
        if(LoginPanel.chek==1){
//            int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                r = JOptionPane.showInputDialog(this.getParent(), "Please Enter ADMISSION NO.");
            if(r==null){
            }
            else{
            if (r.equals("")){
            } else {
                try {
                    stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str1 = "SELECT NOC_DATE,STD_NAME,STD_FNAME,ADM_DATE,ADDRESS FROM NOC_RECORD WHERE ADMISSION_NO='" + r.toUpperCase() + "'";
            rs = stmt.executeQuery(str1);
            while(rs.next()){
                String f40 = String.valueOf(rs.getDate(1));
                String yg = f40.substring(0, 4);
                String mg = f40.substring(5, 7);
                String dg = f40.substring(8, 10);
                String nocdate = dg.concat("-").concat(mg).concat("-").concat(yg);
                String name=rs.getString(2);
                String fname=rs.getString(3);
                String admdate = String.valueOf(rs.getDate(4));
                String admyg = admdate.substring(0, 4);
                String admmg = admdate.substring(5, 7);
                String admdg = admdate.substring(8, 10);
                String admdmy = admdg.concat("-").concat(admmg).concat("-").concat(admyg);//2014-03-09
                String stdadd=rs.getString(5);
                noc= new NOCForm();
                NOCForm.lbldol.setText(nocdate);
                NOCForm.lblstdname.setText(name);
                NOCForm.lblfname.setText(fname);
                NOCForm.txtadd.setText(stdadd);
                NOCForm.lblclassp.setText(admdmy);               
                noc.setBounds(300, 20, 620, 600); 
                noc.setVisible(true);
                jmi33.setEnabled(false);
                count26=1;
                flag=true;
                break;
            }
            if(flag==false){
            //            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "SELECT STUDENT_NAME,FATHER_NAME,STD_ADD,ADMISSION_DATE FROM NEWADMISSION WHERE ADMISSION_NO='" + r.toUpperCase()+ "'";
            rs = stmt.executeQuery(str);
            while(rs.next()){
                String curdate = NewJPanel.lbldate.getText().substring(5, 15);
                String entrydate = NewAdmPanel.date(curdate);
                String name=rs.getString(1);
                String fname=rs.getString(2);
                String stdadd=rs.getString(3);
                String admdate = String.valueOf(rs.getDate(4));
                String admyg = admdate.substring(0, 4);
                String admmg = admdate.substring(5, 7);
                String admdg = admdate.substring(8, 10);
                String admdmy = admdg.concat("-").concat(admmg).concat("-").concat(admyg);//2014-03-09               
                noc= new NOCForm();
                NOCForm.lbldol.setText(entrydate);
                NOCForm.lblstdname.setText(name);
                NOCForm.lblfname.setText(fname);
                NOCForm.txtadd.setText(stdadd);
                NOCForm.lblclassp.setText(admdmy);               
                noc.setBounds(300, 20, 620, 600); 
                noc.setVisible(true);
                jmi33.setEnabled(false);
                count26=1;
                flag1=true;
                break;
            }
            }
            }
            catch(SQLException sq){
                //sq.printStackTrace();
                //JOptionPane.showMessageDialog(rootPane, "Record Not Found");
            }
                if(flag==false&&flag1==false){
                  JOptionPane.showMessageDialog(rootPane, "Record Not Found");  
                }
            }            
        }
        }
        else {
            JOptionPane.showMessageDialog(this.getParent(), "For Administrator Only!");
        }
    }//GEN-LAST:event_jmi33ActionPerformed

    private void jmi34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi34ActionPerformed
        // TODO add your handling code here:
        if (count27 == 0) {
            jmi34.setEnabled(false);
            count27 = 1;
            arp = new AllRecord();
            nocr = new NocRecord();
            nocr.setVisible(true);
            nocr.setBounds(384, 30, 581, 378);
            nocr.setExtendedState(JFrame.MAXIMIZED_BOTH);
            nocr.add(arp);            
        }
    }//GEN-LAST:event_jmi34ActionPerformed

    private void jmi35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi35ActionPerformed
        // TODO add your handling code here:
        if(jmi35.isEnabled()){
        jmi35.setEnabled(false);
        treport=new TotalReport();
        treport.setVisible(true);
        treport.setBounds(384, 30, 581, 378);
        treport.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count28=1;
        totrept=1;
        }
    }//GEN-LAST:event_jmi35ActionPerformed

    private void jmi36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi36ActionPerformed
        // TODO add your handling code here:
        if(jmi36.isEnabled()&&LoginPanel.chek==1){
        jmi36.setEnabled(false);
        balsheet=new BalanceSheet();
        balsheet.setVisible(true);
        balsheet.setBounds(384, 30, 581, 378);
        balsheet.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count29=1;    
        }
    }//GEN-LAST:event_jmi36ActionPerformed

    private void jmi37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi37ActionPerformed
        // TODO add your handling code here:
        if(jmi37.isEnabled()){
        jmi37.setEnabled(false);
        durept=new DuesReport();
        durept.setVisible(true);
        durept.setBounds(384, 30, 581, 378);
        durept.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count30=1;
        duesrept=1;    
        }
    }//GEN-LAST:event_jmi37ActionPerformed

    private void jmi38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmi38ActionPerformed
        // TODO add your handling code here:
        if(jmi38.isEnabled()){
        jmi38.setEnabled(false);
        atnpg=new AttndencePage();
        atnpg.setVisible(true);
        atnpg.setBounds(384, 30, 581, 378);
        atnpg.setExtendedState(JFrame.MAXIMIZED_BOTH);
        count31=1;
        }
    }//GEN-LAST:event_jmi38ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                WindowUtilities.setNativeLookAndFeel();
                try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                } catch (Exception e) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Error : Unable To Load Driver",
                            "Driver test", javax.swing.JOptionPane.ERROR_MESSAGE, null);
                }
                try {
                    java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
                    con1.close();
                    admop = new AdmissionOpen();
                    admop.setBounds(384, 30, 581, 378);
                    admop.setExtendedState(MAXIMIZED_BOTH);
                    admop.setVisible(true);
                } catch (SQLException sqe) {
                    //sqe.printStackTrace();
                    DatabaseForm dbf= new DatabaseForm();
                    dbf.setBackground(Color.GREEN);
                    dbf.setBounds(430, 170, 497, 200);
                    dbf.setVisible(true);
                }

            }
        });
    }
    public static NewAdmissionPanel newadmpanel;
    public static Login log;
    public static AdmissionOpen admop;
    public static LoginPanel lp;
    public static StudentsFee stdfee;
    public static Loan lon;
    public static Donation don;
    public static SchoolStaff schstf;
    public static StaffPayment stfpay;
    public static MiscPayment micpay;
    public static ToBank tbk;
    public static ToFund tfd;
    public static NewUser nur;
    public static UserUpdate userup;
    public static RecordWindow rdw;
    public static LoginRecord lrd;
    public static FeeDetails feedt;
    public static Stationery station;
    
    public static NewAdmPanel admp;
    public static javax.swing.JScrollPane jjp;
    public static UpdateRecord upd;
    public static FetchData ftd;
    public static int num1 = 0;
    public static AllRecordForm alp;
    public static AllRecord arp;
    public static MainPicture mpg;
    public static OldStaff oldstf;
    public static SetSection ssc;
    public static LeavingForm leav;
    public static StationeryRecord stsrec;
    public static TotalCollection totcolt;
    public static TotalExpenses totexp;
    public static VehicleDetails vd;
    public static VehicleRegistration rd;
    public static VehicleQuery vehquery;
    public static AllVehicleRecord avr;
    public static NOCForm noc;
    public static NocRecord nocr;
    public static TotalReport treport;
    public static DuesReport durept;
    public static BalanceSheet balsheet;
    public static AttndencePage atnpg;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator10;
    private javax.swing.JPopupMenu.Separator jSeparator11;
    private javax.swing.JPopupMenu.Separator jSeparator12;
    private javax.swing.JPopupMenu.Separator jSeparator13;
    private javax.swing.JPopupMenu.Separator jSeparator14;
    private javax.swing.JPopupMenu.Separator jSeparator15;
    private javax.swing.JPopupMenu.Separator jSeparator16;
    private javax.swing.JPopupMenu.Separator jSeparator17;
    private javax.swing.JPopupMenu.Separator jSeparator18;
    private javax.swing.JPopupMenu.Separator jSeparator19;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator20;
    private javax.swing.JPopupMenu.Separator jSeparator21;
    private javax.swing.JPopupMenu.Separator jSeparator22;
    private javax.swing.JPopupMenu.Separator jSeparator23;
    private javax.swing.JPopupMenu.Separator jSeparator24;
    private javax.swing.JPopupMenu.Separator jSeparator25;
    private javax.swing.JPopupMenu.Separator jSeparator26;
    private javax.swing.JPopupMenu.Separator jSeparator27;
    private javax.swing.JPopupMenu.Separator jSeparator28;
    private javax.swing.JPopupMenu.Separator jSeparator29;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JPopupMenu.Separator jSeparator9;
    public static javax.swing.JMenu jm1;
    public static javax.swing.JMenu jm2;
    public static javax.swing.JMenu jm3;
    public static javax.swing.JMenu jm4;
    public static javax.swing.JMenu jm5;
    public static javax.swing.JMenu jm6;
    public static javax.swing.JMenu jm7;
    public static javax.swing.JMenu jm8;
    public static javax.swing.JMenuItem jmi1;
    public static javax.swing.JMenuItem jmi10;
    public static javax.swing.JMenuItem jmi11;
    public static javax.swing.JMenuItem jmi12;
    private javax.swing.JMenuItem jmi13;
    private javax.swing.JMenuItem jmi14;
    private javax.swing.JMenuItem jmi15;
    public static javax.swing.JMenuItem jmi16;
    public static javax.swing.JMenuItem jmi17;
    public static javax.swing.JMenuItem jmi18;
    public static javax.swing.JMenuItem jmi19;
    public static javax.swing.JMenuItem jmi2;
    public static javax.swing.JMenuItem jmi20;
    public static javax.swing.JMenuItem jmi21;
    public static javax.swing.JMenuItem jmi22;
    public static javax.swing.JMenuItem jmi23;
    public static javax.swing.JMenuItem jmi24;
    public static javax.swing.JMenuItem jmi25;
    public static javax.swing.JMenuItem jmi26;
    public static javax.swing.JMenuItem jmi27;
    public static javax.swing.JMenuItem jmi28;
    public static javax.swing.JMenuItem jmi29;
    public static javax.swing.JMenuItem jmi3;
    public static javax.swing.JMenuItem jmi30;
    public static javax.swing.JMenuItem jmi31;
    public static javax.swing.JMenuItem jmi32;
    public static javax.swing.JMenuItem jmi33;
    public static javax.swing.JMenuItem jmi34;
    public static javax.swing.JMenuItem jmi35;
    public static javax.swing.JMenuItem jmi36;
    public static javax.swing.JMenuItem jmi37;
    public static javax.swing.JMenuItem jmi38;
    public static javax.swing.JMenuItem jmi4;
    public static javax.swing.JMenuItem jmi5;
    public static javax.swing.JMenuItem jmi6;
    public static javax.swing.JMenuItem jmi7;
    public static javax.swing.JMenuItem jmi8;
    // End of variables declaration//GEN-END:variables
}
