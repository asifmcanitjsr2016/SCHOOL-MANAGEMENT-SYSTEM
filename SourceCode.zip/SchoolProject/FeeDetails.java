/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author ASIF
 */
public class FeeDetails extends javax.swing.JFrame {

    /**
     * Creates new form FeeDetails
     */
    private Statement stmt;
    private ResultSet rs;
    private java.sql.Connection con;
    private int classfalse=0;
    private int ctr=0;
    private int tot=0;
    private int a[],b[],c[],d[],e[],f[],g[],h[],i[],j[];
    String sl1,sl2,sl3,sl4,sl5,sl6,sl7,sl8,sl9,sl10;
    public static String admfee,schdevfee,examfee,libfee,libfine,pipulfee,sportfee,hostelfee,smartfee,sessionfee;
    public static int p=0;
    public FeeDetails() {
        initComponents();
        txtregfee.grabFocus();
        jLabel47.setVisible(false);
        txttransfee.setVisible(false);
        head1.setText(AdmissionOpen.arg);
        head2.setText(AdmissionOpen.arg1);
        try{
        con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
        String str="SELECT * FROM VILLEGE";
        rs=stmt.executeQuery(str);
        while(rs.next())
            tot++;
        }
        catch(SQLException xe){
            //JOptionPane.showMessageDialog(rootPane, xe);
        }
    }
    int[] listSelection(String schfee)
    {
        char sdvf[]=schfee.toCharArray();
                    int a[]=new int[12];
                    int b[];
                    char sdv[]=new char[3];
                    int k=0,j=0;
                    for(int i=1;i<sdvf.length;i++)
                    {
                        if(sdvf[i]!=' ')
                        {
                         if(sdvf[i]!=','&& i!=sdvf.length-1)
                        {
                            sdv[k++]=sdvf[i];
                        }
                         else
                        {
                            String st=String.valueOf(sdv);
                            int dateFormat = Integer.parseInt(NewAdmPanel.dateFormat(st));
                            a[j++]=dateFormat-1;
                            k=0;
                        }   
                        }                        
                    }
                    b=new int[j];
                    System.arraycopy(a, 0, b, 0, j);
                    return b;
    }
private void getData(String cls){
    boolean flag=false;
    int arr[]=new int[1];
        arr[0]=-1;
    try {
//                con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1="SELECT * FROM FEE_DETAILS WHERE CLASS='"+cls+"'";
                rs=stmt.executeQuery(str1);
                while(rs.next()){
                    cbclass.setSelectedItem(String.valueOf(rs.getString(1)));
                    String reg=rs.getString(2);
                    String adm=rs.getString(3);
                    admfee=adm.substring(adm.lastIndexOf("/")+1, adm.length());
                    sl1=admfee;
                    if(admfee.equals("Select"))
                        a=arr;
                    else
                        a=(listSelection(admfee));                    
                    String tut=rs.getString(4);
                    String comp=rs.getString(5);
                    String elect=rs.getString(6);
                    String smart=rs.getString(7);
                    smartfee=smart.substring(smart.lastIndexOf("/")+1, smart.length());
                    sl2=smartfee;
                    if(smartfee.equals("Select"))
                        b=arr;
                    else
                        b=(listSelection(smartfee));                    
                    String sport=rs.getString(8);
                    sportfee=sport.substring(sport.lastIndexOf("/")+1, sport.length());
                    sl3=sportfee;
                    if(sportfee.equals("Select"))
                        c=arr;
                    else
                        c=(listSelection(sportfee));                    
                    String pipul=rs.getString(9);
                    pipulfee=pipul.substring(pipul.lastIndexOf("/")+1, pipul.length());
                    sl4=pipulfee;
                    if(pipulfee.equals("Select"))
                        d=arr;
                    else
                        d=(listSelection(pipulfee));                    
                    String lib=rs.getString(10);
                    libfee=lib.substring(lib.lastIndexOf("/")+1, lib.length());
                    sl5=libfee;
                    if(libfee.equals("Select"))
                        e=arr;
                    else
                        e=(listSelection(libfee));                    
                    String libf=rs.getString(11);
                    libfine=libf.substring(libf.lastIndexOf("/")+1, libf.length());
                    sl6=libfine;
                    if(libfine.equals("Select"))
                        f=arr;
                    else
                        f=(listSelection(libfine));                    
                    String hostel=rs.getString(13);
                    hostelfee=hostel.substring(hostel.lastIndexOf("/")+1, hostel.length());
                    sl7=hostelfee;
                    if(hostelfee.equals("Select"))
                        g=arr;
                    else
                        g=(listSelection(hostelfee));                    
                    String schdev=rs.getString(14);
                    schdevfee=schdev.substring(schdev.lastIndexOf("/")+1, schdev.length());
                    sl8=schdevfee;
                    if(schdevfee.equals("Select"))
                        h=arr;
                    else
                        h=(listSelection(schdevfee));                                            
                    String exam=rs.getString(15);
                    examfee=exam.substring(exam.lastIndexOf("/")+1, exam.length());
                    sl9=examfee;
                    if(examfee.equals("Select"))
                        i=arr;
                    else
                        i=listSelection(examfee);                    
                    String session=rs.getString(16);
                    sessionfee=session.substring(session.lastIndexOf("/")+1, session.length());
                    sl10=sessionfee;
                    if(sessionfee.equals("Select"))
                        j=arr;
                    else
                        j=listSelection(sessionfee);                    
                    String caut=rs.getString(17);                    
                    txtregfee.setText(rs.getString(2).substring(0, reg.lastIndexOf("/")));
                    txtadmfee.setText(rs.getString(3).substring(0, adm.lastIndexOf("/")));
                    txttufee.setText(rs.getString(4).substring(0, tut.lastIndexOf("/")));
                    txtcompfee.setText(rs.getString(5).substring(0, comp.lastIndexOf("/")));
                    txtelectfee.setText(rs.getString(6).substring(0, elect.lastIndexOf("/")));
                    txtsmart.setText(rs.getString(7).substring(0, smart.lastIndexOf("/")));
                    txtsport.setText(rs.getString(8).substring(0, sport.lastIndexOf("/")));
                    txtpupil.setText(rs.getString(9).substring(0, pipul.lastIndexOf("/")));
                    txtlibfee.setText(rs.getString(10).substring(0, lib.lastIndexOf("/")));
                    txtlibfine.setText(rs.getString(11).substring(0, libf.lastIndexOf("/")));
                    txttransfee.setText(rs.getString(12));
                    txthostelfee.setText(rs.getString(13).substring(0, hostel.lastIndexOf("/")));
                    txtschdevfee.setText(rs.getString(14).substring(0, schdev.lastIndexOf("/")));
                    txtexamfee.setText(rs.getString(15).substring(0, exam.lastIndexOf("/")));
                    txtsessionfee.setText(rs.getString(16).substring(0, session.lastIndexOf("/")));
                    txtcaut.setText(rs.getString(17).substring(0, caut.lastIndexOf("/")));                    
                    flag=true;
                    classfalse=0;
                }
                } catch (SQLException ex) {
                    classfalse=0;
                    clear();
                //JOptionPane.showMessageDialog(rootPane, ex);
            }
    if(flag==false){
        classfalse=1;
        a=b=c=d=e=f=g=h=i=j=arr;
        admfee=schdevfee=examfee=libfee=libfine=pipulfee=sportfee=hostelfee=smartfee=sessionfee="Select";
        sl1=sl2=sl3=sl4=sl5=sl6=sl7=sl8=sl9=sl10="Select";
        clear();
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        txtadmfee = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        lbl2 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        lbl5 = new javax.swing.JLabel();
        txtlibfee = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtexamfee = new javax.swing.JTextField();
        cbclass = new javax.swing.JComboBox();
        txtregfee = new javax.swing.JTextField();
        btnclear = new javax.swing.JButton();
        txtcompfee = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        txtcaut = new javax.swing.JTextField();
        lbl4 = new javax.swing.JLabel();
        txttransfee = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        txttufee = new javax.swing.JTextField();
        btnsave = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        btncancle = new javax.swing.JButton();
        txtsessionfee = new javax.swing.JTextField();
        txtsmart = new javax.swing.JTextField();
        txtschdevfee = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        txtelectfee = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtsport = new javax.swing.JTextField();
        lbl1 = new javax.swing.JLabel();
        txtlibfine = new javax.swing.JTextField();
        txthostelfee = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        lbl3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        txtpupil = new javax.swing.JTextField();
        btn4 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn10 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        head1 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        head2 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jLabel7 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        txtamt = new javax.swing.JTextField();
        txtval = new javax.swing.JTextField();
        btnnew = new javax.swing.JButton();
        btnnext = new javax.swing.JButton();
        btnsav = new javax.swing.JButton();
        btnprev = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jScrollPane1.setPreferredSize(new java.awt.Dimension(1347, 800));

        jPanel1.setBackground(new java.awt.Color(255, 211, 216));
        jPanel1.setPreferredSize(new java.awt.Dimension(1345, 767));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "School Fee Details ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 36))); // NOI18N
        jLayeredPane1.setOpaque(true);

        txtadmfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtadmfee.setToolTipText("Use Only Digit(0-9)");
        txtadmfee.setNextFocusableComponent(txtcaut);
        txtadmfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtadmfeeActionPerformed(evt);
            }
        });
        txtadmfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtadmfeeFocusLost(evt);
            }
        });
        txtadmfee.setBounds(290, 160, 100, 25);
        jLayeredPane1.add(txtadmfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel28.setText("Admission/Re-Admission Fee :");
        jLabel28.setBounds(30, 160, 237, 20);
        jLayeredPane1.add(jLabel28, javax.swing.JLayeredPane.DEFAULT_LAYER);

        lbl2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbl2.setText("<html>\n<u>\nOne Time\n</u>");
        lbl2.setBounds(400, 200, 90, 20);
        jLayeredPane1.add(lbl2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel47.setText("Transport Fee :");
        jLabel47.setBounds(680, 530, 118, 20);
        jLayeredPane1.add(jLabel47, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel45.setText("Library Fee :");
        jLabel45.setBounds(540, 160, 100, 20);
        jLayeredPane1.add(jLabel45, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel30.setText("Caution Money (Refundable) :");
        jLabel30.setBounds(30, 200, 238, 20);
        jLayeredPane1.add(jLabel30, javax.swing.JLayeredPane.DEFAULT_LAYER);

        lbl5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbl5.setText("<html> <u> All Month </u>");
        lbl5.setBounds(400, 320, 90, 20);
        jLayeredPane1.add(lbl5, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtlibfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtlibfee.setToolTipText("Use Only Digit(0-9)");
        txtlibfee.setNextFocusableComponent(txtlibfine);
        txtlibfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlibfeeActionPerformed(evt);
            }
        });
        txtlibfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtlibfeeFocusLost(evt);
            }
        });
        txtlibfee.setBounds(700, 160, 100, 25);
        jLayeredPane1.add(txtlibfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel43.setText("Sports Fee :");
        jLabel43.setBounds(30, 400, 91, 20);
        jLayeredPane1.add(jLabel43, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel49.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel49.setText("Sch Dev Fee :");
        jLabel49.setBounds(540, 280, 110, 20);
        jLayeredPane1.add(jLabel49, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setOpaque(true);
        jLabel6.setBounds(10, 40, 270, 1);
        jLayeredPane1.add(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtexamfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtexamfee.setToolTipText("Use Only Digit(0-9)");
        txtexamfee.setNextFocusableComponent(txtsessionfee);
        txtexamfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtexamfeeActionPerformed(evt);
            }
        });
        txtexamfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtexamfeeFocusLost(evt);
            }
        });
        txtexamfee.setBounds(700, 320, 100, 25);
        jLayeredPane1.add(txtexamfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        cbclass.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cbclass.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Kids", "Nursery", "L.K.G", "U.K.G", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        cbclass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbclassActionPerformed(evt);
            }
        });
        cbclass.setBounds(430, 60, 90, 23);
        jLayeredPane1.add(cbclass, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtregfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtregfee.setToolTipText("Use Only Digit(0-9)");
        txtregfee.setNextFocusableComponent(txtadmfee);
        txtregfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtregfeeActionPerformed(evt);
            }
        });
        txtregfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtregfeeFocusLost(evt);
            }
        });
        txtregfee.setBounds(290, 120, 100, 25);
        jLayeredPane1.add(txtregfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnclear.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnclear.setText("Clear");
        btnclear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnclear.setNextFocusableComponent(btncancle);
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        btnclear.setBounds(390, 520, 67, 25);
        jLayeredPane1.add(btnclear, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtcompfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcompfee.setToolTipText("Use Only Digit(0-9)");
        txtcompfee.setNextFocusableComponent(txtelectfee);
        txtcompfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcompfeeActionPerformed(evt);
            }
        });
        txtcompfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcompfeeFocusLost(evt);
            }
        });
        txtcompfee.setBounds(290, 280, 100, 25);
        jLayeredPane1.add(txtcompfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel41.setText("Electric/Generator Charge :");
        jLabel41.setBounds(30, 320, 213, 20);
        jLayeredPane1.add(jLabel41, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtcaut.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcaut.setToolTipText("Use Only Digit(0-9)");
        txtcaut.setNextFocusableComponent(txttufee);
        txtcaut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcautActionPerformed(evt);
            }
        });
        txtcaut.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcautFocusLost(evt);
            }
        });
        txtcaut.setBounds(290, 200, 100, 25);
        jLayeredPane1.add(txtcaut, javax.swing.JLayeredPane.DEFAULT_LAYER);

        lbl4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbl4.setText("<html> <u> All Month </u>");
        lbl4.setBounds(400, 280, 90, 20);
        jLayeredPane1.add(lbl4, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txttransfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txttransfee.setToolTipText("Use Only Digit(0-9)");
        txttransfee.setNextFocusableComponent(txthostelfee);
        txttransfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttransfeeActionPerformed(evt);
            }
        });
        txttransfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txttransfeeFocusLost(evt);
            }
        });
        txttransfee.setBounds(800, 530, 100, 25);
        jLayeredPane1.add(txttransfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel40.setText("Computer Fee :");
        jLabel40.setBounds(30, 280, 120, 20);
        jLayeredPane1.add(jLabel40, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel51.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel51.setText("Session Fee :");
        jLabel51.setBounds(540, 360, 98, 20);
        jLayeredPane1.add(jLabel51, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel48.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel48.setText("Hostel Fee :");
        jLabel48.setBounds(540, 240, 91, 20);
        jLayeredPane1.add(jLabel48, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txttufee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txttufee.setToolTipText("Use Only Digit(0-9)");
        txttufee.setNextFocusableComponent(txtcompfee);
        txttufee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttufeeActionPerformed(evt);
            }
        });
        txttufee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txttufeeFocusLost(evt);
            }
        });
        txttufee.setBounds(290, 240, 100, 25);
        jLayeredPane1.add(txttufee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnsave.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnsave.setText("Save");
        btnsave.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave.setNextFocusableComponent(btnclear);
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        btnsave.setBounds(290, 520, 61, 25);
        jLayeredPane1.add(btnsave, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel29.setText("Tuition Fee :");
        jLabel29.setBounds(30, 240, 98, 20);
        jLayeredPane1.add(jLabel29, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btncancle.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncancle.setText("Home");
        btncancle.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncancle.setNextFocusableComponent(txtregfee);
        btncancle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncancleActionPerformed(evt);
            }
        });
        btncancle.setBounds(490, 520, 69, 25);
        jLayeredPane1.add(btncancle, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtsessionfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtsessionfee.setToolTipText("Use Only Digit(0-9)");
        txtsessionfee.setNextFocusableComponent(btnsave);
        txtsessionfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsessionfeeActionPerformed(evt);
            }
        });
        txtsessionfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtsessionfeeFocusLost(evt);
            }
        });
        txtsessionfee.setBounds(700, 360, 100, 25);
        jLayeredPane1.add(txtsessionfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtsmart.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtsmart.setToolTipText("Use Only Digit(0-9)");
        txtsmart.setNextFocusableComponent(txtsport);
        txtsmart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsmartActionPerformed(evt);
            }
        });
        txtsmart.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtsmartFocusLost(evt);
            }
        });
        txtsmart.setBounds(290, 360, 100, 25);
        jLayeredPane1.add(txtsmart, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtschdevfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtschdevfee.setToolTipText("Use Only Digit(0-9)");
        txtschdevfee.setNextFocusableComponent(txtexamfee);
        txtschdevfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtschdevfeeActionPerformed(evt);
            }
        });
        txtschdevfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtschdevfeeFocusLost(evt);
            }
        });
        txtschdevfee.setBounds(700, 280, 100, 25);
        jLayeredPane1.add(txtschdevfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel50.setText("Examination Fee :");
        jLabel50.setBounds(540, 320, 140, 20);
        jLayeredPane1.add(jLabel50, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtelectfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtelectfee.setToolTipText("Use Only Digit(0-9)");
        txtelectfee.setNextFocusableComponent(txtsmart);
        txtelectfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtelectfeeActionPerformed(evt);
            }
        });
        txtelectfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtelectfeeFocusLost(evt);
            }
        });
        txtelectfee.setBounds(290, 320, 100, 25);
        jLayeredPane1.add(txtelectfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel46.setText("Library Fine :");
        jLabel46.setBounds(540, 200, 107, 20);
        jLayeredPane1.add(jLabel46, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtsport.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtsport.setToolTipText("Use Only Digit(0-9)");
        txtsport.setNextFocusableComponent(txtpupil);
        txtsport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsportActionPerformed(evt);
            }
        });
        txtsport.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtsportFocusLost(evt);
            }
        });
        txtsport.setBounds(290, 400, 100, 25);
        jLayeredPane1.add(txtsport, javax.swing.JLayeredPane.DEFAULT_LAYER);

        lbl1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbl1.setText("<html> <u> One Time </u>");
        lbl1.setBounds(400, 120, 90, 20);
        jLayeredPane1.add(lbl1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtlibfine.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtlibfine.setToolTipText("Use Only Digit(0-9)");
        txtlibfine.setNextFocusableComponent(txthostelfee);
        txtlibfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlibfineActionPerformed(evt);
            }
        });
        txtlibfine.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtlibfineFocusLost(evt);
            }
        });
        txtlibfine.setBounds(700, 200, 100, 25);
        jLayeredPane1.add(txtlibfine, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txthostelfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txthostelfee.setToolTipText("Use Only Digit(0-9)");
        txthostelfee.setNextFocusableComponent(txtschdevfee);
        txthostelfee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txthostelfeeActionPerformed(evt);
            }
        });
        txthostelfee.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txthostelfeeFocusLost(evt);
            }
        });
        txthostelfee.setBounds(700, 240, 100, 25);
        jLayeredPane1.add(txthostelfee, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel42.setText("Smart Class Fee :");
        jLabel42.setBounds(30, 360, 134, 20);
        jLayeredPane1.add(jLabel42, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel44.setText("Pupil Fund :");
        jLabel44.setBounds(540, 120, 96, 20);
        jLayeredPane1.add(jLabel44, javax.swing.JLayeredPane.DEFAULT_LAYER);

        lbl3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lbl3.setText("<html> <u> All Month </u>");
        lbl3.setBounds(400, 240, 90, 20);
        jLayeredPane1.add(lbl3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("Select Class :");
        jLabel2.setBounds(310, 60, 101, 22);
        jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel39.setText("Registration Fee :");
        jLabel39.setBounds(30, 120, 136, 20);
        jLayeredPane1.add(jLabel39, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtpupil.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtpupil.setToolTipText("Use Only Digit(0-9)");
        txtpupil.setNextFocusableComponent(txtlibfee);
        txtpupil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpupilActionPerformed(evt);
            }
        });
        txtpupil.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtpupilFocusLost(evt);
            }
        });
        txtpupil.setBounds(700, 120, 100, 25);
        jLayeredPane1.add(txtpupil, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn4.setText("...");
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        btn4.setBounds(800, 120, 25, 25);
        jLayeredPane1.add(btn4, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn2.setText("...");
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        btn2.setBounds(390, 360, 25, 25);
        jLayeredPane1.add(btn2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn1.setText("...");
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        btn1.setBounds(390, 160, 25, 25);
        jLayeredPane1.add(btn1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn3.setText("...");
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        btn3.setBounds(390, 400, 25, 25);
        jLayeredPane1.add(btn3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn10.setText("...");
        btn10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn10ActionPerformed(evt);
            }
        });
        btn10.setBounds(800, 360, 25, 25);
        jLayeredPane1.add(btn10, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn9.setText("...");
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });
        btn9.setBounds(800, 320, 25, 25);
        jLayeredPane1.add(btn9, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn8.setText("...");
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });
        btn8.setBounds(800, 280, 25, 25);
        jLayeredPane1.add(btn8, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn7.setText("...");
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });
        btn7.setBounds(800, 240, 25, 25);
        jLayeredPane1.add(btn7, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn6.setText("...");
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });
        btn6.setBounds(800, 200, 25, 25);
        jLayeredPane1.add(btn6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btn5.setText("...");
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        btn5.setBounds(800, 160, 25, 25);
        jLayeredPane1.add(btn5, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 930, 570));

        jLabel5.setBackground(new java.awt.Color(204, 51, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setOpaque(true);
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 730, 1420, 37));

        jPanel2.setBackground(new java.awt.Color(204, 51, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        head1.setBackground(new java.awt.Color(204, 51, 0));
        head1.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        head1.setForeground(new java.awt.Color(255, 255, 0));
        head1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head1.setText("Holistic Heritage Academy");
        head1.setOpaque(true);
        jPanel2.add(head1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 610, -1));

        jLabel60.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 0));
        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel60.setText("(An English Medium School)");
        jLabel60.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel2.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 180, 20));

        head2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        head2.setForeground(new java.awt.Color(255, 255, 0));
        head2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head2.setText("\"Shanti Niketan\" Pali Road, Dehri-On-Sone, Rohtas (Bihar) Pin Code - 821307");
        head2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel2.add(head2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 820, 25));

        jLabel55.setBackground(new java.awt.Color(255, 255, 255));
        jLabel55.setOpaque(true);
        jPanel2.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 56, 585, 2));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1420, 110));

        jLayeredPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Transport Fee Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 36))); // NOI18N

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setOpaque(true);
        jLabel7.setBounds(10, 40, 300, 1);
        jLayeredPane2.add(jLabel7, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("<html> <u> Amount </u>");
        jLabel38.setBounds(250, 140, 80, 20);
        jLayeredPane2.add(jLabel38, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel52.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel52.setText("<html> <u> Villege Name </u>");
        jLabel52.setBounds(70, 140, 110, 20);
        jLayeredPane2.add(jLabel52, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtamt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtamt.setToolTipText("Use Only Digit(0-9)");
        txtamt.setNextFocusableComponent(txtlibfee);
        txtamt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtamtActionPerformed(evt);
            }
        });
        txtamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtamtFocusLost(evt);
            }
        });
        txtamt.setBounds(250, 170, 90, 20);
        jLayeredPane2.add(txtamt, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txtval.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtval.setToolTipText("Use Only Digit(0-9)");
        txtval.setNextFocusableComponent(txtlibfee);
        txtval.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtvalActionPerformed(evt);
            }
        });
        txtval.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtvalFocusLost(evt);
            }
        });
        txtval.setBounds(20, 170, 210, 20);
        jLayeredPane2.add(txtval, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnnew.setText("New");
        btnnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnewActionPerformed(evt);
            }
        });
        btnnew.setBounds(180, 290, 73, 23);
        jLayeredPane2.add(btnnew, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnnext.setText(">>");
        btnnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnextActionPerformed(evt);
            }
        });
        btnnext.setBounds(180, 240, 49, 23);
        jLayeredPane2.add(btnnext, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnsav.setText("Save");
        btnsav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsavActionPerformed(evt);
            }
        });
        btnsav.setBounds(90, 290, 70, 23);
        jLayeredPane2.add(btnsav, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnprev.setText("<<");
        btnprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprevActionPerformed(evt);
            }
        });
        btnprev.setBounds(110, 240, 49, 23);
        jLayeredPane2.add(btnprev, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 200, 350, 340));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void clear(){
        txtregfee.setText("");
        txtadmfee.setText("");
        txtcaut.setText("");
        txttufee.setText("");
        txtcompfee.setText("");
        txtelectfee.setText("");
        txtsmart.setText("");
        txtsport.setText("");
        txtpupil.setText("");
        txtlibfee.setText("");
        txtlibfine.setText("");
        txttransfee.setText("");
        txthostelfee.setText("");
        txtschdevfee.setText("");
        txtexamfee.setText("");
        txtsessionfee.setText("");     
        if(classfalse==1){
        }
        else{
        cbclass.setSelectedIndex(0);
        }
        classfalse=0;
}
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        AdmissionOpen.jmi21.setEnabled(true);
        AdmissionOpen.count15 = 0;
    }//GEN-LAST:event_formWindowClosing

    private void txtamtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtamtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtamtActionPerformed

    private void txtamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtamtFocusLost
        // TODO add your handling code here:
        if (txtamt.getText().matches("\\d+")) {
        } else {
            txtamt.setText("");
        }
        if (txtamt.getText().length() > 8) {
            txtamt.setText("");
        }
    }//GEN-LAST:event_txtamtFocusLost

    private void txtvalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtvalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtvalActionPerformed

    private void txtvalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtvalFocusLost
        // TODO add your handling code here:
        if (txtval.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtval.setText("");
        }
    }//GEN-LAST:event_txtvalFocusLost

    private void btnprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprevActionPerformed
        // TODO add your handling code here:
        if(tot>0)
        {
        ctr--;
        if(ctr>0)
        showRec(ctr);
        else
        ctr=1;
        }
    }//GEN-LAST:event_btnprevActionPerformed

    private void btnnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnextActionPerformed
        // TODO add your handling code here:
        if(tot>0&&ctr<tot)
        {
        ctr++;
        showRec(ctr);
        }
    }//GEN-LAST:event_btnnextActionPerformed

    private void btnsavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsavActionPerformed
        // TODO add your handling code here:
        boolean flag=false;
        if(txtval.getText().equals("")||txtamt.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Please Fillup The All Fields");
        }
        else
        {
        try {
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1="SELECT * FROM VILLEGE";
                rs=stmt.executeQuery(str1);
                while(rs.next()){
                    String sr=rs.getString(1);
                    if(sr.equalsIgnoreCase(txtval.getText()))
                    {
                    flag=true;
                    break;
                    }
                }
                if(flag==true){
                String str = ("UPDATE VILLEGE SET VILL_NAME = '" + txtval.getText() + "',AMOUNT = '" + txtamt.getText() + "' WHERE VILL_NAME='"+txtval.getText()+"'");
                stmt.executeQuery(str);
                con.setAutoCommit(true);
                JOptionPane.showMessageDialog(this, "Record is Successfelly Updated");
//                stmt.close();
//                con.close();
                }                
                else{
                String str = ("INSERT INTO VILLEGE VALUES('" + txtval.getText() + "','" + txtamt.getText() + "')");
                stmt=con.createStatement();
                stmt.executeUpdate(str);                               
                con.setAutoCommit(true);
                JOptionPane.showMessageDialog(this, "Data Saved Successfully");
                tot++;
//                stmt.close();
//                con.close();
                }                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, ex);
            }
        }
    }//GEN-LAST:event_btnsavActionPerformed

    private void btnnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnewActionPerformed
        // TODO add your handling code here:
        txtval.setText("");
        txtamt.setText("");
    }//GEN-LAST:event_btnnewActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=4;
            sl4 = click(d);            
        }
    }//GEN-LAST:event_btn4ActionPerformed

    private void txtpupilFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtpupilFocusLost
        // TODO add your handling code here:
        if (txtpupil.getText().matches("\\d+")) {
        } else {
            txtpupil.setText("");
        }
        if (txtpupil.getText().length() > 8) {
            txtpupil.setText("");
        }
    }//GEN-LAST:event_txtpupilFocusLost

    private void txtpupilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpupilActionPerformed
        // TODO add your handling code here:
        txtlibfee.grabFocus();
    }//GEN-LAST:event_txtpupilActionPerformed

    private void txthostelfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txthostelfeeFocusLost
        // TODO add your handling code here:
        if (txthostelfee.getText().matches("\\d+")) {
        } else {
            txthostelfee.setText("");
        }
        if (txthostelfee.getText().length() > 8) {
            txthostelfee.setText("");
        }
    }//GEN-LAST:event_txthostelfeeFocusLost

    private void txthostelfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txthostelfeeActionPerformed
        // TODO add your handling code here:
        txtschdevfee.grabFocus();
    }//GEN-LAST:event_txthostelfeeActionPerformed

    private void txtlibfineFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtlibfineFocusLost
        // TODO add your handling code here:
        if (txtlibfine.getText().matches("\\d+")) {
        } else {
            txtlibfine.setText("");
        }
        if (txtlibfine.getText().length() > 8) {
            txtlibfine.setText("");
        }
    }//GEN-LAST:event_txtlibfineFocusLost

    private void txtlibfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlibfineActionPerformed
        // TODO add your handling code here:
//        txttransfee.grabFocus();
        txthostelfee.grabFocus();
    }//GEN-LAST:event_txtlibfineActionPerformed

    private void txtsportFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtsportFocusLost
        // TODO add your handling code here:
        if (txtsport.getText().matches("\\d+")) {
        } else {
            txtsport.setText("");
        }
        if (txtsport.getText().length() > 8) {
            txtsport.setText("");
        }
    }//GEN-LAST:event_txtsportFocusLost

    private void txtsportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsportActionPerformed
        // TODO add your handling code here:
        txtpupil.grabFocus();
    }//GEN-LAST:event_txtsportActionPerformed

    private void txtelectfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtelectfeeFocusLost
        // TODO add your handling code here:
        if (txtelectfee.getText().matches("\\d+")) {
        } else {
            txtelectfee.setText("");
        }
        if (txtelectfee.getText().length() > 8) {
            txtelectfee.setText("");
        }
    }//GEN-LAST:event_txtelectfeeFocusLost

    private void txtelectfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtelectfeeActionPerformed
        // TODO add your handling code here:
        txtsmart.grabFocus();
    }//GEN-LAST:event_txtelectfeeActionPerformed

    private void txtschdevfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtschdevfeeFocusLost
        // TODO add your handling code here:
        if (txtschdevfee.getText().matches("\\d+")) {
        } else {
            txtschdevfee.setText("");
        }
        if (txtschdevfee.getText().length() > 8) {
            txtschdevfee.setText("");
        }
    }//GEN-LAST:event_txtschdevfeeFocusLost

    private void txtschdevfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtschdevfeeActionPerformed
        // TODO add your handling code here:
        txtexamfee.grabFocus();
    }//GEN-LAST:event_txtschdevfeeActionPerformed

    private void txtsmartFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtsmartFocusLost
        // TODO add your handling code here:
        if (txtsmart.getText().matches("\\d+")) {
        } else {
            txtsmart.setText("");
        }
        if (txtsmart.getText().length() > 8) {
            txtsmart.setText("");
        }
    }//GEN-LAST:event_txtsmartFocusLost

    private void txtsmartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsmartActionPerformed
        // TODO add your handling code here:
        txtsport.grabFocus();
    }//GEN-LAST:event_txtsmartActionPerformed

    private void txtsessionfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtsessionfeeFocusLost
        // TODO add your handling code here:
        if (txtsessionfee.getText().matches("\\d+")) {
        } else {
            txtsessionfee.setText("");
        }
        if (txtsessionfee.getText().length() > 8) {
            txtsessionfee.setText("");
        }
    }//GEN-LAST:event_txtsessionfeeFocusLost

    private void txtsessionfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsessionfeeActionPerformed
        // TODO add your handling code here:
        btnsave.grabFocus();
    }//GEN-LAST:event_txtsessionfeeActionPerformed

    private void btncancleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancleActionPerformed
        // TODO add your handling code here:
        AdmissionOpen.jmi21.setEnabled(true);
        dispose();
        AdmissionOpen.count15 = 0;
    }//GEN-LAST:event_btncancleActionPerformed

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        // TODO add your handling code here:
        boolean flag = false;
        if (cbclass.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(rootPane, "Please Select a Class or Fee Date");
        } else {
            if (txtregfee.getText().equals("")) {
                txtregfee.setText("0");
            }
            if (txtadmfee.getText().equals("")) {
                txtadmfee.setText("0");
            }
            if (txtcaut.getText().equals("")) {
                txtcaut.setText("0");
            }
            if (txttufee.getText().equals("")) {
                txttufee.setText("0");
            }
            if (txtcompfee.getText().equals("")) {
                txtcompfee.setText("0");
            }
            if (txtelectfee.getText().equals("")) {
                txtelectfee.setText("0");
            }
            if (txtsmart.getText().equals("")) {
                txtsmart.setText("0");
            }
            if (txtsport.getText().equals("")) {
                txtsport.setText("0");
            }
            if (txtpupil.getText().equals("")) {
                txtpupil.setText("0");
            }
            if (txtlibfee.getText().equals("")) {
                txtlibfee.setText("0");
            }
            if (txtlibfine.getText().equals("")) {
                txtlibfine.setText("0");
            }
            if (txttransfee.getText().equals("")) {
                txttransfee.setText("0");
            }
            if (txthostelfee.getText().equals("")) {
                txthostelfee.setText("0");
            }
            if (txtschdevfee.getText().equals("")) {
                txtschdevfee.setText("0");
            }
            if (txtexamfee.getText().equals("")) {
                txtexamfee.setText("0");
            }
            if (txtsessionfee.getText().equals("")) {
                txtsessionfee.setText("0");
            }
            String class1 = String.valueOf(cbclass.getSelectedItem());
            String regfee = txtregfee.getText().concat("/One Time");
            String admfee = txtadmfee.getText().concat("/")+sl1;
            String caut = txtcaut.getText().concat("/One Time");
            String tufee = txttufee.getText().concat("/All Month");
            String compfee = txtcompfee.getText().concat("/All Month");
            String electfee = txtelectfee.getText().concat("/All Month");
            String smart = txtsmart.getText().concat("/")+sl2;
            String sport = txtsport.getText().concat("/")+sl3;
            String pupil = txtpupil.getText().concat("/")+sl4;
            String libfee = txtlibfee.getText().concat("/")+sl5;
            String libfine = txtlibfine.getText().concat("/")+sl6;
            String transfee = txttransfee.getText();
            String hostelfee = txthostelfee.getText().concat("/")+sl7;
            String schdevfee = txtschdevfee.getText().concat("/")+sl8;
            String examfee = txtexamfee.getText().concat("/")+sl9;
            String sessionfee = txtsessionfee.getText().concat("/")+sl10;
            try {

                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1 = "SELECT * FROM FEE_DETAILS WHERE CLASS='" + class1 + "'";
                rs = stmt.executeQuery(str1);
                while (rs.next()) {
                    String sr = rs.getString(1);
                    flag = true;
                    break;
                }
                if (flag == true) {
                    String str = ("UPDATE FEE_DETAILS SET REG_FEE = '" + regfee + "',ADM_FEE = '" + admfee + "',TUT_FEE='" + tufee + "',COMPUTER='" + compfee + "',ELECT_FEE='" + electfee + "',SMART_FEE='" + smart + "',SPORTS_FEE='" + sport + "',PUPIL_FUND='" + pupil + "',LIB_FEE='" + libfee + "',LIB_FINE='" + libfine + "',TRANS_FEE='" + transfee + "',HOSTEL_FEE='" + hostelfee + "',SCHOOLDEV_FEE='" + schdevfee + "',EXAM_FEE='" + examfee + "',SESSION_FEE='" + sessionfee + "',CAUTION_MONEY='" + caut + "' WHERE CLASS='" + class1 + "'");
                    stmt.executeQuery(str);
                    con.setAutoCommit(true);
                    JOptionPane.showMessageDialog(this, "Record is Successfelly Updated");
                    getData(class1);
//                stmt.close();
//                con.close();
                } else {
                    String str = ("INSERT INTO FEE_DETAILS VALUES('" + class1 + "','" + regfee + "','" + admfee + "','" + tufee + "','" + compfee + "','" + electfee + "','" + smart + "','" + sport + "','" + pupil + "','" + libfee + "','" + libfine + "','" + transfee + "','" + hostelfee + "','" + schdevfee + "','" + examfee + "','" + sessionfee + "','" + caut + "')");
                    stmt = con.createStatement();
                    stmt.executeUpdate(str);
                    con.setAutoCommit(true);
                    JOptionPane.showMessageDialog(this, "Data Saved Successfully");
                    getData(class1);
//                stmt.close();
//                con.close();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, ex);
            }
        }
    }//GEN-LAST:event_btnsaveActionPerformed

    private void txttufeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txttufeeFocusLost
        // TODO add your handling code here:
        if (txttufee.getText().matches("\\d+")) {
        } else {
            txttufee.setText("");
        }
        if (txttufee.getText().length() > 8) {
            txttufee.setText("");
        }
    }//GEN-LAST:event_txttufeeFocusLost

    private void txttufeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttufeeActionPerformed
        // TODO add your handling code here:
        txtcompfee.grabFocus();
    }//GEN-LAST:event_txttufeeActionPerformed

    private void txttransfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txttransfeeFocusLost
        // TODO add your handling code here:
        if (txttransfee.getText().matches("\\d+")) {
        } else {
            txttransfee.setText("");
        }
        if (txttransfee.getText().length() > 8) {
            txttransfee.setText("");
        }
    }//GEN-LAST:event_txttransfeeFocusLost

    private void txttransfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttransfeeActionPerformed
        // TODO add your handling code here:
        txthostelfee.grabFocus();
    }//GEN-LAST:event_txttransfeeActionPerformed

    private void txtcautFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcautFocusLost
        // TODO add your handling code here:
        if (txtcaut.getText().matches("\\d+")) {
        } else {
            txtcaut.setText("");
        }
        if (txtcaut.getText().length() > 8) {
            txtcaut.setText("");
        }
    }//GEN-LAST:event_txtcautFocusLost

    private void txtcautActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcautActionPerformed
        // TODO add your handling code here:
        txttufee.grabFocus();
    }//GEN-LAST:event_txtcautActionPerformed

    private void txtcompfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcompfeeFocusLost
        // TODO add your handling code here:
        if (txtcompfee.getText().matches("\\d+")) {
        } else {
            txtcompfee.setText("");
        }
        if (txtcompfee.getText().length() > 8) {
            txtcompfee.setText("");
        }
    }//GEN-LAST:event_txtcompfeeFocusLost

    private void txtcompfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcompfeeActionPerformed
        // TODO add your handling code here:
        txtelectfee.grabFocus();
    }//GEN-LAST:event_txtcompfeeActionPerformed

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_btnclearActionPerformed

    private void txtregfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtregfeeFocusLost
        // TODO add your handling code here:
        if (txtregfee.getText().matches("\\d+")) {
        } else {
            txtregfee.setText("");
        }
        if (txtregfee.getText().length() > 8) {
            txtregfee.setText("");
        }
    }//GEN-LAST:event_txtregfeeFocusLost

    private void txtregfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtregfeeActionPerformed
        // TODO add your handling code here:
        txtadmfee.grabFocus();
    }//GEN-LAST:event_txtregfeeActionPerformed

    private void cbclassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbclassActionPerformed
        // TODO add your handling code here:
        String str = "";
        if (cbclass.getSelectedIndex() == 0) {
        } else {
            str = String.valueOf(cbclass.getSelectedItem());
            getData(str);
        }
    }//GEN-LAST:event_cbclassActionPerformed

    private void txtexamfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtexamfeeFocusLost
        // TODO add your handling code here:
        if (txtexamfee.getText().matches("\\d+")) {
        } else {
            txtexamfee.setText("");
        }
        if (txtexamfee.getText().length() > 8) {
            txtexamfee.setText("");
        }
    }//GEN-LAST:event_txtexamfeeFocusLost

    private void txtexamfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtexamfeeActionPerformed
        // TODO add your handling code here:
        txtsessionfee.grabFocus();
    }//GEN-LAST:event_txtexamfeeActionPerformed

    private void txtlibfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtlibfeeFocusLost
        // TODO add your handling code here:
        if (txtlibfee.getText().matches("\\d+")) {
        } else {
            txtlibfee.setText("");
        }
        if (txtlibfee.getText().length() > 8) {
            txtlibfee.setText("");
        }
    }//GEN-LAST:event_txtlibfeeFocusLost

    private void txtlibfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlibfeeActionPerformed
        // TODO add your handling code here:
        txtlibfine.grabFocus();
    }//GEN-LAST:event_txtlibfeeActionPerformed

    private void txtadmfeeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtadmfeeFocusLost
        // TODO add your handling code here:
        if (txtadmfee.getText().matches("\\d+")) {
        } else {
            txtadmfee.setText("");
        }
        if (txtadmfee.getText().length() > 8) {
            txtadmfee.setText("");
        }
    }//GEN-LAST:event_txtadmfeeFocusLost

    private void txtadmfeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtadmfeeActionPerformed
        // TODO add your handling code here:
        txtcaut.grabFocus();
    }//GEN-LAST:event_txtadmfeeActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=2;
            sl2 = click(b);           
        }
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {  
            p=1;
            sl1 = click(a);
        }
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {
             p=3;
            sl3 = click(c);           
        }
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn10ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {
             p=10;
            sl10 = click(j);            
        }
    }//GEN-LAST:event_btn10ActionPerformed
private String click(int com[])
{
            MonthChooser.list.clear();
            int arr[] = new int[com.length];
            System.arraycopy(com, 0, arr, 0, com.length);
            months = new MonthChooser(this, true, arr);
            months.setLocation(300, 200);
            months.setVisible(true);
            String chstr = MonthChooser.listitem;
            MonthChooser.listitem="Select";
            return chstr;
}
    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=9;
            sl9 = click(i);            
        }
    }//GEN-LAST:event_btn9ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=8;
            sl8 = click(h);            
        }
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=7;
            sl7 = click(g);            
        }
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=6;
            sl6 = click(f);            
        }
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
        // TODO add your handling code here:
        if (cbclass.getSelectedIndex() != 0) {            
            p=5;
            sl5 = click(e);            
        }
    }//GEN-LAST:event_btn5ActionPerformed
private void showRec(int ctr)
{
    try {
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str = "select * from villege";
                rs = stmt.executeQuery(str);
                rs.absolute(ctr);
                txtval.setText(rs.getString(1));
                txtamt.setText(rs.getString(2));
        }
                catch(SQLException xe)
                {
                    xe.printStackTrace();
                }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FeeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FeeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FeeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FeeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new FeeDetails().setVisible(true);
            }
        });
    }
    MonthChooser months;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn10;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btncancle;
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btnnew;
    private javax.swing.JButton btnnext;
    private javax.swing.JButton btnprev;
    private javax.swing.JButton btnsav;
    private javax.swing.JButton btnsave;
    private javax.swing.JComboBox cbclass;
    public static javax.swing.JLabel head1;
    private javax.swing.JLabel head2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    public static javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel lbl2;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lbl4;
    private javax.swing.JLabel lbl5;
    private javax.swing.JTextField txtadmfee;
    public static javax.swing.JTextField txtamt;
    private javax.swing.JTextField txtcaut;
    private javax.swing.JTextField txtcompfee;
    private javax.swing.JTextField txtelectfee;
    private javax.swing.JTextField txtexamfee;
    private javax.swing.JTextField txthostelfee;
    private javax.swing.JTextField txtlibfee;
    private javax.swing.JTextField txtlibfine;
    private javax.swing.JTextField txtpupil;
    private javax.swing.JTextField txtregfee;
    private javax.swing.JTextField txtschdevfee;
    private javax.swing.JTextField txtsessionfee;
    private javax.swing.JTextField txtsmart;
    private javax.swing.JTextField txtsport;
    private javax.swing.JTextField txttransfee;
    private javax.swing.JTextField txttufee;
    public static javax.swing.JTextField txtval;
    // End of variables declaration//GEN-END:variables
}
