/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.Color;
import java.awt.event.ItemEvent;
public class StaffDetail extends javax.swing.JPanel {

   boolean present= false;
   
    public StaffDetail() {
        initComponents();
     
    }
    // if state is true then checkbox is selected .....
    public StaffDetail(int srno, String name,String desgnt, String mo,boolean state) {
        initComponents();
        sr.setText(""+srno);
        sname.setText(" "+name);
        desg.setText(""+desgnt);
        mobile.setText("Mobile:  "+mo);
        if(state)attn.setSelected(state);
        mobile.setVisible(false); 
    }
    public StaffDetail(String data) {
        initComponents();
        String dd[] = data.split("\t");
         sr.setText(""+dd[0]);
        sname.setText(" "+dd[1]);
        desg.setText(""+dd[2]);
        mobile.setText("Mobile:  "+dd[3]);
          mobile.setVisible(false); 
     
    }
    
public void makeAttendece()
{
    present = true;
    attn.setSelected(true);
}
public void absenthim()
{
    present = false;
    attn.setSelected(false);
    prescolor();
     mobile.setVisible(false); 
}
public boolean getAttn()
{
    return present;
}
public String getStaffID()
{
    return  sr.getText();
}
private void abscolor()
{
      sr.setForeground(Color.red);
      sname.setForeground(Color.red);
      desg.setForeground(Color.red);
      mobile.setForeground(Color.red);
}

private void prescolor()
{
      sr.setForeground(Color.black);
      sname.setForeground(Color.black);
      desg.setForeground(Color.black);
      mobile.setForeground(Color.black); 
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sname = new javax.swing.JLabel();
        attn = new javax.swing.JCheckBox();
        mobile = new javax.swing.JLabel();
        sr = new javax.swing.JLabel();
        desg = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });

        sname.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        sname.setText(" Mr. Sanjay Kumar Singh");

        attn.setOpaque(false);
        attn.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                attnItemStateChanged(evt);
            }
        });

        mobile.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        mobile.setText("Mobile:  9162162585");

        sr.setBackground(new java.awt.Color(51, 0, 102));
        sr.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        sr.setText("sr");

        desg.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        desg.setText("Principal");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sr, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sname, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(desg, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(attn)
                .addGap(18, 18, 18)
                .addComponent(mobile)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(sr)
                .addComponent(sname)
                .addComponent(desg))
            .addComponent(attn)
            .addComponent(mobile)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void attnItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_attnItemStateChanged
        // TODO add your handling code here:
        if(evt.getStateChange()==ItemEvent.DESELECTED)
        { mobile.setVisible(true); 
            present = false;
            abscolor();
            
        }
        else if (evt.getStateChange()==ItemEvent.SELECTED)
        {
           mobile.setVisible(false);
            present = true;
            prescolor();
        }
    }//GEN-LAST:event_attnItemStateChanged

    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
       this.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_formMouseEntered

    private void formMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseExited
        this.setBackground(Color.white);
    }//GEN-LAST:event_formMouseExited

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox attn;
    private javax.swing.JLabel desg;
    private javax.swing.JLabel mobile;
    private javax.swing.JLabel sname;
    private javax.swing.JLabel sr;
    // End of variables declaration//GEN-END:variables
}
