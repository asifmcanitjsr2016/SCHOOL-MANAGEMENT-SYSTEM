package SchoolProject;


import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;


public class MonthChooser extends javax.swing.JDialog {

   static javax.swing.JTextField field;
   public static  java.util.ArrayList<String> list = new java.util.ArrayList<>();
   public static String listitem="Select";
   boolean flag=false;
    public MonthChooser(java.awt.Frame parent, boolean modal,int indx[]) {
        super(parent, modal);
        initComponents();
        for(int i=0;i<12;i++)
        {
            if(indx.length!=0)
            {
                for(int j=0;j<indx.length;j++)
                    if(i==indx[j])
                    {
                        flag=true;
                        break;
                    }
                else
                    flag=false;   
            }
            if(flag)
                jPanel2.add(new MonthName(i,i));
            else
                jPanel2.add(new MonthName(i,-1));
        }
        this.revalidate();
    }
    
    public void setField(javax.swing.JTextField tf) {
        this.field =tf; tf.setText("");
       int x= tf.getLocation().x+ tf.getWidth()+10;
       int y = tf.getLocation().y +tf.getHeight()+5;
       
        this.setLocation(x, y);
    }
   
    
    public static void addData(String mn) {list.add(mn);}
    
    public static void removeData(String mn){ list.remove(mn);}
    
    public  static void setData(){
        String temp ="";
        for(int i=0; i<list.size(); i++)
           temp = temp +list.get(i) +",";
        if(!temp.equals(""))
        temp = temp.substring(0, temp.lastIndexOf(","));
        listitem="["+temp+"]";
        if(listitem.equals(""))
            listitem.concat("Select");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new java.awt.GridLayout(3, 4, 9, 8));

        jPanel3.setBackground(new java.awt.Color(102, 153, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(194, 31));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(102, 153, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("<html><u>::Month Chooser::</u></html>");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel1.setOpaque(true);
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 0, 290, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("X");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 51)));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 20, 20));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        if(!(listitem.equals(FeeDetails.admfee))&&FeeDetails.p==1)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.admfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.smartfee))&&FeeDetails.p==2)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.smartfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.sportfee))&&FeeDetails.p==3)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.sportfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.pipulfee))&&FeeDetails.p==4)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.pipulfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.libfee))&&FeeDetails.p==5)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.libfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.libfine))&&FeeDetails.p==6)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.libfine;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.hostelfee))&&FeeDetails.p==7)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.hostelfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.schdevfee))&&FeeDetails.p==8)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.schdevfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.examfee))&&FeeDetails.p==9)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.examfee;
                dispose();
            }
        }
        if(!(listitem.equals(FeeDetails.sessionfee))&&FeeDetails.p==10)
        {
            int k=JOptionPane.showConfirmDialog(rootPane, "Do You Want TO Change Month");
            if(k!=JOptionPane.YES_OPTION){           
                listitem=FeeDetails.sessionfee;
                dispose();
            }
        }
        dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
class MonthName extends javax.swing.JLabel implements MouseListener
{
    private static String month[]= {"January","Feburary","March","April","May","June","July","August","September","October","November","December"};
    private static String mnth[] ={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    private  String data="",d=""; //currently selected data...month name
    private  boolean selected= false; 
    
    public MonthName(int index,int indx)
    {
       super();
       this.setText(month[index]);
       data = mnth[index];
       d = month[index];
       setBackground(Color.white);
       setForeground(new java.awt.Color(0,153,255));
       setFont(new java.awt.Font("tahoma", java.awt.Font.PLAIN, 13));
       setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153,204,255)));
       setOpaque(true);
       setVisible(true);
       setHorizontalAlignment(this.CENTER);
       addMouseListener(this);
       this.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
       if(indx>=0)
       {
            String data1=mnth[indx];
            MonthChooser.addData(data1);
            setBackground(new java.awt.Color(0,153,255));
            setForeground(Color.white);
            setBorder(null);
            MonthChooser.setData();
            selected = true;
       }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
        if(selected)  //control come here ,if label is already selected
        {
            MonthChooser.removeData(data);
            setBackground(Color.white);
            setForeground(new java.awt.Color(0,153,255));
            setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153,204,255)));
            MonthChooser.setData();
            selected = false;
        }else { // new selection of label
            MonthChooser.addData(data);
            setBackground(new java.awt.Color(0,153,255));
            setForeground(Color.white);
            setBorder(null);
            MonthChooser.setData();
            selected = true;
        }    
    }
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {setText("<html><b>"+d+"</b></html>"); }
    public void mouseExited(MouseEvent e) { setText(d); }
    
      
    }