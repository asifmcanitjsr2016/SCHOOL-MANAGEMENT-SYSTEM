/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

/**
 *
 * @author ASIF
 */
public class AllRecordPanel extends JPanel {

    public static Statement stmt;
    public static ResultSet rs;
    public static Object[][] rows;
    private static String[] alladmno;
    public static int totalRows = 0,total=0;
    public static JTable jTable1,jTable2,jTable3,jTable4,jTable5,jTable6,jTable7;
    private JScrollPane jsp;//, "COURSE_NAME", "COURSE_NAME1", "SUBJECT1", "SUBJECT2", "SUBJECT3", "SUBJECT4", "SUBJECT5", "SUBJECT6", "SUBJECT7", "SUBJECT8", "SUBJECT9", "SUBJECT10", "SUBJECT11", 
    public static String[] records = {"ADMISSION_NO","ADMISSION_RECEIPT_NO","FEE_DETAILS","STUDENT_NAME", "STUDENT_DATE OF BIRTH","AGE", "ROLL_NO", "CLASS", "SECTION", "RELIGION", "CASTE", "GENDER", "BLOOD_GROUP", "IDENTIFICATION_MARKS", "CORRESPONDENCE_ADDRESS", "ADMISSION_FEE", "ADMISSION_DATE", "ADMISSION_TIME", "FATHER'S_NAME", "FATHER'S_QUALIFICATION", "FATHER'S_OCCUPATION","FATHER'S_CONTACT", "FATHER'S_DESIGNATION", "FATHER'S_COMPANY NAME", "PERMANENT_ADDRESS", "MOTHER'S_NAME", "MOTHER'S_QUALIFICATION", "MOTHER'S_OCCUPATION","MOTHER'S_CONTACT", "MOTHER'S_DESIGNATION", "MOTHER'S_COMPANY NAME", "PRESENT_ADDRESS","SLC_NO", "SCHOOL_NAME", "SCHOOL_ADDRESS", "STUDENT_CHARACTER", "CERTIFICATE ISSUE_DATE"};
    public static String[] records1 = {"RECEIPT_NO", "ROLL_NO", "CLASS", "SECTION", "STUDENT_NAME","VILLAGE", "REGISTRATION_FEE","ADMISSION_FEE","CAUTION_MONEY","TUITION_FEE","MISCELLANEOUS_CHARGE","COMPUTER_FEE","ELECTRIC/GENERATOR_CHARGE","SMART_CLASS_FEE","SPORTS_FEE","PUPIL_FUND","LIBRARY_FEE","LIBRARY_FINE","TRANSPORT_FEE","HOSTEL_FEE","SCHOOL_DEVELOPMENT_FEE","EXAMINATION_FEE","SESSION_FEE", "TOTAL_PAYABLE_AMOUNT", "PAID_AMOUNT", "DUE_AMOUNT", "PAY_TYPE","ACCOUNT_NO", "CHEQUE_NO", "CHEQUE_DATE", "BANK_NAME", "PAYMENT_DATE", "PAYMENT_TIME","PAY_MONTH"};
    public static String[] records2 = {"LOAN_REASON", "LOAN_AMOUNT", "LOAN_DATE", "LOAN_AUTHORITY", "LOAN_TYPE", "INTEREST_RATE", "INTEREST_AMOUNT", "AUTHORITY_NO.", "AUTHORITY_DATE", "CHEQUE_AMOUNT", "CHEQUE_NO.", "CHEQUE_DATE", "BANK_NAME", "ENTRY_DATE", "ENTRY_TIME"};
    public static String[] records3 = {"SERIAL_NO","DONNER_NAME","DONNER_ADDRESS","CONTACT_NO","DONATION_PURPOSE", "DONATION_TYPE", "DONATION_DATE", "CASH_AMOUNT","ACCOUNT_NO", "PROPERTY_DETAILS", "CHEQUE_AMOUNT", "CHEQUE_NO.", "CHEQUE_DATE", "BANK_NAME", "ENTRY_DATE", "ENTRY_TIME"};
    public static String[] records4 = {"STAFF_ID", "STAFF_NAME", "STAFF_DESIGNATION", "QUALIFICATION", "EXPERIANCE", "CONTACT NO.", "EMAIL ID", "STAFF_ADDRESS.", "DATE_OF_BIRTH", "DATE_OF_JOIN","BASIC_PAY","DA","CASUAL_LEAVE","CONVENIENCE_ALLOWANCE","ANUALLY_INCREAMENT", "TOTAL_SALARY", "ENTRY_DATE", "ENTRY_TIME"};
    public static String[] records5 = {"STAFF_ID","RECEIPT_NO", "STAFF_NAME", "STAFF_DESIGNATION", "AUTHORITY", "SALARY","BASIC_PAY","DA","CASUAL_LEAVE","CONVENIENCE_ALLOWANCE","ARREAR","MISC", "PAYABLE_AMOUNT","PF","G/S","ADVANCE","LEAVE_WITHOUT_PAYMENT", "DEDUCTION_AMOUNT", "TOTAL_PAID_AMOUNT", "PAYMENT_TYPE", "ACCOUNT_NO", "CHEQUE_NO.", "CHEQUE_DATE", "BANK_NAME","PAY_MONTH", "PAYMENT_DATE", "PAYMENT_TIME"};
    public static String[] records6 = {"RECEIPT_NO","STAFF_NAME", "AUTHORITY", "AUTHORITY_NO.", "AUTHORITY_DATE", "PAYMENT_REASON", "PAYMENT_TYPE", "PAID_AMOUNT", "ACCOUNT_NO", "CHEQUE_NO.", "CHEQUE_DATE", "BANK_NAME", "PAYMENT_DATE", "PAYMENT_TIME"};
    public static String[] records7 = {"BANK_NAME", "AUTHORITY", "AUTHORITY_NO.", "AUTHORITY_DATE", "AMOUNT", "CHEQUE_NO.", "ENTRY_DATE", "ENTRY_TIME"};
    public static String[] records8 = {"FUND_NAME", "AUTHORITY", "AUTHORITY_NO.", "AUTHORITY_DATE", "AMOUNT", "CHEQUE_NO.", "ENTRY_DATE", "ENTRY_TIME"};
    public static String[] records9 = {"RECEIPT_NO","STUDENT_NAME","ROLL","CLASS","SECTION","NO_OF_BOOKS", "AMOUNT", "NO_OF_NOTEBOOKS", "AMOUNT", "NO_OF_DRESS", "AMOUNT","NO_OF_TYE","AMOUNT","NO_OF_BELT","AMOUNT","NO_OF_ICARD","AMOUNT","NO_OF_DIARY","AMOUNT","MISCELLANEOUS_AMOUNT","TOTAL_AMOUNT", "ENTRY_DATE", "ENTRY_TIME"};
    private static String[] record = {"LOGIN_DATE", "LOGIN_TIME", "USER_ID.", "USER_NAME"};
    private static String[] record10 = {"VEHICLE_REG_NO.", "TAX_PAY_DATE", "TAX_AMOUNT","TAX_PERIOD", "NEXT_DUE_DATE","ENTRY_DATE","ENTRY_TIME"};
    private static String[] record11 = {"VEHICLE_REG_NO.", "FITNESS_DATE", "FITNESS_AMOUNT","FITNESS_PERIOD", "NEXT_DUE_DATE","ENTRY_DATE","ENTRY_TIME"};
    private static String[] record12 = {"VEHICLE_REG_NO.", "INSURANCE_DATE", "INSURANCE_AMOUNT","INSURANCE_PERIOD", "NEXT_DUE_DATE","ENTRY_DATE","ENTRY_TIME"};
    private static String[] record13 = {"VEHICLE_REG_NO.", "VEHICLE_NAME/NO.", "PURCHAGE_DATE","REGISTRATION_DATE", "MAKE", "VEHICLE_TYPE", "FUEL_TYPE", "CAPACITY","ENTRY_DATE","ENTRY_TIME"};
    private static String[] record14 = {"ADMISSION_NO.", "NOC_DATE", "STUDENT_NAME","FATHER_NAME", "ADMISSION_DATE", "ADDRESS","ENTRY_DATE","ENTRY_TIME"};
    private static String[] record15 = {"ADMISSION_NO.", "RECEIPT_NO", "STUDENT_NAME","CLASS", "TOTAL_AMOUNT", "PAID_AMOUNT", "DUE_AMOUNT", "PAYMENT_TYPE", "PAY_MONTH","PAY_DATE","PAY_TIME"};
    private static String[] record16 = {"ADMISSION_NO.", "RECEIPT_NO", "STUDENT_NAME","CLASS", "TOTAL_AMOUNT", "PAYMENT_STATUS","ADMISSION_DATE","ADMISSION_TIME"};
    private static String[] record17 = {"RECEIPT_NO", "PAYMENT_MADE_TO", "PAID_AMOUNT", "PAYMENT_TYPE","PAYMENT_REASON","PAYMENT_DATE","PAYMENT_TIME"};
    private static String[] record18 = {"RECEIPT_NO", "STAFF_ID", "STAFF_NAME", "SALARY","PAYABLE_AMOUNT","DEDUCTION_AMOUNT","PAID_AMOUNT","PAY_TYPE","PAYMENT_MONTH","BASIC_PAYMENT","DA","CASUAL_LEAVE","CONVENIENCE_ALLOWANCE","ARREAR","MISCELLANEOUS","PF","G/S","ADVANCE","LEAVE_WITHOUT_PAY","PAYMENT_DATE","PAYMENT_TIME"};
    private static String[] record19 ={"RECEIPT_NO", "STUDENT_NAME","CLASS", "PAID_AMOUNT", "PAYMENT_TYPE"};
    private static String[] record20 ={"RECEIPT_NO", "STAFF_NAME", "PAYABLE_AMOUNT","DEDUCTION_AMOUNT", "AMOUNT_PAID"};
    private static String[] record21 ={"RECEIPT_NO", "NAME", "AMOUNT_PAID","PURPOSE_OF_PAYMENT", "PAYMENT_TYPE"};
    private static String[] record22 ={"STUDENT_NAME", "CLASS", "ROLL","FEE_LAST_PAID_MONTH", "FEE_DUES_IN_AMOUNT"};
    private static String[] record23 ={"ADMISSION_NO","STUDENT_NAME", "CLASS", "ROLL","LAST_PAYMENT_MONTH", "LAST_PAID_AMOUNT","TUTION_FEE","TRANSPORT_FEE","EXAMINATION_FEE","SCHOOL_DEVELOPMENT_FEE","PREVIOUS_DUES","TOTAL_DUES_AMOUNT"};
    private static String[] month={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    private static String admn[];
    public static String str = "";
    public static String roll = "", roll1 = "", lonres = "", donname = "", staffid = "",staffid1 = "", stfname = "", bkname = "", fdname = "",books="",regno="",regno1="",admno="",admno1="",admno2="",slipno="";
    public static boolean flag = false,flag1 = false,flag2 = false,flag3 = false;
    AllRecordPanel() {
        if (RecordWindow.value1 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            AdmissionRecord rd = new AdmissionRecord();
            rd.setBounds(0, 0, 971, 200);
            add(rd);
            RecordWindow.value1 = 0;
        } else if (RecordWindow.value2 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            StdFeeRecord sfr = new StdFeeRecord();
            sfr.setBounds(0, 0, 971, 200);
            add(sfr);
            RecordWindow.value2 = 0;
        } else if (RecordWindow.value3 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            LoanRecord lonr = new LoanRecord();
            lonr.setBounds(0, 0, 971, 200);
            add(lonr);
            RecordWindow.value3 = 0;
        } else if (RecordWindow.value4 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            DonationRecord donr = new DonationRecord();
            donr.setBounds(0, 0, 971, 200);
            add(donr);
            RecordWindow.value4 = 0;
        } else if (RecordWindow.value5 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            SchoolStaffRecord schstfr = new SchoolStaffRecord();
            schstfr.setBounds(0, 0, 971, 200);
            add(schstfr);
            RecordWindow.value5 = 0;
        } else if (RecordWindow.value6 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            StaffPaymentRecord stfpr = new StaffPaymentRecord();
            stfpr.setBounds(0, 0, 971, 245);
            add(stfpr);
            RecordWindow.value6 = 0;
        } else if (RecordWindow.value7 == 1) {
            setLayout(null);
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            BankRecord bkrec = new BankRecord();
            bkrec.setBounds(0, 0, 971, 245);
            add(bkrec);
            RecordWindow.value7 = 0;
        }
        if (NewJPanel.totstd == 1||NewJPanel.totnewadm==1||AdmissionOpen.totcollect==1||AdmissionOpen.totalexp==1||AdmissionOpen.stscount==1||AdmissionOpen.vehcount==1||AdmissionOpen.totrept==1||AdmissionOpen.duesrept==1||DuesReport.flag==true) {
            setLayout(null);
        }
    }

    public static void roll() {
        if (AdmissionRecord.a == 1) {
            str = "SELECT * FROM NEWADMISSION WHERE ADMISSION_NO='" + AdmissionRecord.getroll.toUpperCase() + "'";
        } else if (AdmissionRecord.a == 2) {
            str = "SELECT * FROM NEWADMISSION WHERE ADMISSION_DATE='" + AdmissionRecord.getdate + "' ORDER BY ADMISSION_DATE ASC";
        } else if (AdmissionRecord.a == 3) {
            str = "SELECT * FROM NEWADMISSION WHERE ADMISSION_DATE BETWEEN '" + AdmissionRecord.getdate + "' AND '" + AdmissionRecord.getbtwdate + "' ORDER BY ADMISSION_DATE ASC ";
        }
        else if(AdmissionRecord.a == 4){
            str = "SELECT * FROM NEWADMISSION WHERE CLASS='" + AdmissionRecord.getclass + "' ORDER BY ADMISSION_NO ASC";
        }
        admrecord(str);
    }
    public static void admrecord(String query){
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            total=totalRows;
            rows = new Object[totalRows][records.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String admno = rs.getString(1);
                rows[i][0] = admno;
                String admrecpt=rs.getString(2);
                rows[i][1] = admrecpt;
                String admfee=rs.getString(3);
                rows[i][2] = admfee;
                String name = rs.getString(4);
                rows[i][3] = name;
                String dob = String.valueOf(rs.getDate(5));//"1992-04-03"
                String st1 = dob.substring(0, 4);
                String st2 = dob.substring(5, 7);
                String st3 = dob.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                rows[i][4] = st4;
                String age = rs.getString(6);
                rows[i][5] = age;
                roll = rs.getString(7);
                rows[i][6] = roll;
                String class1 = rs.getString(8);
                rows[i][7] = class1;
                String section = rs.getString(9);
                rows[i][8] = section;
                String admdate = String.valueOf(rs.getDate(45));
                String d1 = admdate.substring(0, 4);
                String d2 = admdate.substring(5, 7);
                String d3 = admdate.substring(8, 10);
                String d4 = d3.concat("-").concat(d2).concat("-").concat(d1);
                rows[i][16] = d4;
                String time = rs.getString(46);
                rows[i][17] = time;
                String religion = rs.getString(48);
                rows[i][9] = religion;                
                String caste = rs.getString(10);
                rows[i][10] = caste;
                String gender = rs.getString(11);
                rows[i][11] = gender;
                String blood = rs.getString(49);
                rows[i][12] = blood;
                String idmark = rs.getString(50);
                rows[i][13] = idmark;
                String stdadd = rs.getString(51);
                rows[i][14] = stdadd;
                String fee = rs.getString(72);
                rows[i][15] = fee;
                String fname = rs.getString(13);
                rows[i][18] = fname;
                String fquali = rs.getString(14);
                rows[i][19] = fquali;
                String foccup = rs.getString(15);
                rows[i][20] = foccup;
                String fcontact=rs.getString(16);
                rows[i][21]=fcontact;
                String fdesig = rs.getString(17);
                rows[i][22] = fdesig;
                String fcomp = rs.getString(18);
                rows[i][23] = fcomp;
                String fcompadd = rs.getString(19);
                rows[i][24] = fcompadd;
                String mname = rs.getString(20);
                rows[i][25] = mname;
                String mquali = rs.getString(21);
                rows[i][26] = mquali;
                String moccup = rs.getString(22);
                rows[i][27] = moccup;
                String mcontact=rs.getString(23);
                rows[i][28]=mcontact;
                String mdesig = rs.getString(24);
                rows[i][29] = mdesig;
                String mcomp = rs.getString(25);
                rows[i][30] = mcomp;
                String mcompadd = rs.getString(26);
                rows[i][31] = mcompadd;
//                String curname = rs.getString(27);
//                rows[i][27] = curname;
//                String curname1 = rs.getString(28);
//                rows[i][28] = curname1;
//                String sub1 = rs.getString(29);
//                rows[i][29] = sub1;
//                String sub2 = rs.getString(30);
//                rows[i][30] = sub2;
//                String sub3 = rs.getString(31);
//                rows[i][31] = sub3;
//                String sub4 = rs.getString(32);
//                rows[i][32] = sub4;
//                String sub5 = rs.getString(33);
//                rows[i][33] = sub5;
//                String sub6 = rs.getString(34);
//                rows[i][34] = sub6;
//                String sub7 = rs.getString(35);
//                rows[i][35] = sub7;
//                String sub8 = rs.getString(36);
//                rows[i][36] = sub8;
//                String sub9 = rs.getString(37);
//                rows[i][37] = sub9;
//                String sub10 = rs.getString(38);
//                rows[i][38] = sub10;
//                String sub11 = rs.getString(39);
//                rows[i][39] = sub11;
                String slcno = rs.getString(40);
                rows[i][32] = slcno;
                String schoolname = rs.getString(41);
                rows[i][33] = schoolname;
                String schooladd = rs.getString(42);
                rows[i][34] = schooladd;
                String stdchar = rs.getString(43);
                rows[i][35] = stdchar;
                String issuedate = String.valueOf(rs.getDate(44));
                String dd4 = "";
                if (issuedate.equals("null")) {
                    dd4 = "";
                } else {
                    String dd1 = issuedate.substring(0, 4);
                    String dd2 = issuedate.substring(5, 7);
                    String dd3 = issuedate.substring(8, 10);
                    dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                }
                rows[i][36] = dd4;
            }
            jTable1 = new JTable(rows, records);
            if (roll.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 8 || i == 6  ||i==5) {
                    column.setPreferredWidth(100);
                } else if ( i == 1||i == 2||i==36 || i == 7 || i==12 ||i==21 ||i==17 || i==4||i == 9||i == 11||i == 16||i==28||i==15) {
                    column.setPreferredWidth(150);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            roll = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void stdFeeAll() {
        if (StdFeeRecord.b == 1) {
            str = "SELECT * FROM STUDENT_FEE";
        } else if (StdFeeRecord.b == 2) {
            str = "SELECT * FROM STUDENT_FEE WHERE ADMISSION_NO='" + StdFeeRecord.getroll + "'";
        } else if (StdFeeRecord.b == 3) {
            str = "SELECT * FROM STUDENT_FEE WHERE ADMISSION_NO='" + StdFeeRecord.getroll1 + "' AND PAY_DATE='" + StdFeeRecord.getdate + "' ORDER BY PAY_DATE ASC ";
        }
        studentFee(str);
    }
    public static void studentFee(String query){
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records1.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(1);
                rows[i][0] = slno;
                roll1 = rs.getString(2);
                rows[i][1] = roll1;
                String class1 = rs.getString(3);
                rows[i][2] = class1;
                String section = rs.getString(4);
                rows[i][3] = section;
                String name = rs.getString(5);
                rows[i][4] = name;
                String vill = rs.getString(36);
                rows[i][5] = vill;
                String regfee = rs.getString(6);
                rows[i][6] = regfee;
                String admfee = rs.getString(7);
                rows[i][7] = admfee;
                String cautamt = rs.getString(8);
                rows[i][8] = cautamt;
                String tutfee = rs.getString(9);
                rows[i][9] = tutfee;
                String latefee = rs.getString(10);
                rows[i][10] = latefee;
                String compfee = rs.getString(11);
                rows[i][11] = compfee;
                String electfee = rs.getString(12);
                rows[i][12] = electfee;
                String smartfee = rs.getString(13);
                rows[i][13] = smartfee;
                String sportfee = rs.getString(14);
                rows[i][14] = sportfee;
                String pupilfund = rs.getString(15);
                rows[i][15] = pupilfund;
                String libfee = rs.getString(16);
                rows[i][16] = libfee;
                String libfine = rs.getString(17);
                rows[i][17] = libfine;
                String transfee = rs.getString(18);
                rows[i][18] = transfee;
                String hostelfee = rs.getString(19);
                rows[i][19] = hostelfee;
                String schdevfee = rs.getString(20);
                rows[i][20] = schdevfee;
                String examfee = rs.getString(21);
                rows[i][21] = examfee;
                String sessionfee = rs.getString(22);
                rows[i][22] = sessionfee;
                String da = rs.getString(23);
                rows[i][25] = da;
                String tpamt = rs.getString(24);
                rows[i][23] = tpamt;
                String paytype=rs.getString(25);
                rows[i][26] = paytype;
                String cash = rs.getString(26);
                String pdate = String.valueOf(rs.getDate(27));//"1992-04-03"
                String st1 = pdate.substring(0, 4);
                String st2 = pdate.substring(5, 7);
                String st3 = pdate.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                rows[i][31] = st4;
                String chamt = rs.getString(28);
                if (chamt.equals("0")) {
                    rows[i][24] = cash;
                } else {
                    rows[i][24] = chamt;
                }
                String chno = rs.getString(29);
                rows[i][28] = chno;
                String chdate = String.valueOf(rs.getDate(30));
                String dd4 = "";
                if (chdate.equals("null")) {
                    dd4 = "";
                } else {
                    String dd1 = chdate.substring(0, 4);
                    String dd2 = chdate.substring(5, 7);
                    String dd3 = chdate.substring(8, 10);
                    dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                }
                rows[i][29] = dd4;
                String bkname = rs.getString(31);
                rows[i][30] = bkname;
                String acno = rs.getString(32);
                rows[i][27] = acno;
                String ptime = rs.getString(33);
                rows[i][32] = ptime;
                String pmonth = rs.getString(34);
                rows[i][33] = pmonth;
            }
            jTable1 = new JTable(rows, records1);
            if (roll1.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records1.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 0 || i == 10 || i == 7 || i == 5 || i == 8||i==11||i==23||i==20||i==29||i==24|| i == 9|| i == 12||i==32||i==31|| i == 6 ||i==13||i==21||i==33) {
                    column.setPreferredWidth(150);
                } else if (i == 1 || i == 2||i==17 || i == 3 || i == 14 || i == 15||i==16||i==18||i==19||i==22||i==25) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            roll1 = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void loanRecord() {
        if (LoanRecord.c == 1) {
            str = "SELECT * FROM LOAN";
        } else if (LoanRecord.c == 2) {
            str = "SELECT * FROM LOAN WHERE LOAN_DATE='" + LoanRecord.getdate + "' ORDER BY LOAN_DATE ASC";
        } else if (LoanRecord.c == 3) {
            str = "SELECT * FROM LOAN WHERE LOAN_DATE BETWEEN '" + LoanRecord.getdate + "' AND '" + LoanRecord.getbtwdate + "' ORDER BY LOAN_DATE ASC";
        }
        loanRec(str);
    }
    public static void loanRec(String query){
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records2.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                lonres = rs.getString(1);
                rows[i][0] = lonres;
                String loanamt = rs.getString(2);
                rows[i][1] = loanamt;
                String loanauth = rs.getString(3);
                rows[i][3] = loanauth;
                String loantype = rs.getString(4);
                rows[i][4] = loantype;
                String intrate = rs.getString(5);
                rows[i][5] = intrate.concat("%");
                String intamt = rs.getString(6);
                rows[i][6] = intamt;
                String authno = rs.getString(7);
                rows[i][7] = authno;
                String authdate = String.valueOf(rs.getDate(8));//"1992-04-03"
                String st1 = authdate.substring(0, 4);
                String st2 = authdate.substring(5, 7);
                String st3 = authdate.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                rows[i][8] = st4;
                String chamt = rs.getString(9);
                rows[i][9] = chamt;
                String chno = rs.getString(10);
                rows[i][10] = chno;
                String chdate = String.valueOf(rs.getDate(11));
                String dd1 = chdate.substring(0, 4);
                String dd2 = chdate.substring(5, 7);
                String dd3 = chdate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][11] = dd4;
                String bkname = rs.getString(12);
                rows[i][12] = bkname;
                String londate = String.valueOf(rs.getDate(13));
                String ld1 = londate.substring(0, 4);
                String ld2 = londate.substring(5, 7);
                String ld3 = londate.substring(8, 10);
                String ldd = ld3.concat("-").concat(ld2).concat("-").concat(ld1);
                rows[i][2] = ldd;
                String entdate = String.valueOf(rs.getDate(14));
                String end1 = entdate.substring(0, 4);
                String end2 = entdate.substring(5, 7);
                String end3 = entdate.substring(8, 10);
                String endd = end3.concat("-").concat(end2).concat("-").concat(end1);
                rows[i][13] = endd;
                String ptime = rs.getString(15);
                rows[i][14] = ptime;
            }
            jTable1 = new JTable(rows, records2);
            if (lonres.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records2.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 14 || i == 2 || i == 3 || i == 13 || i == 4 || i == 8 || i == 11 || i == 6) {
                    column.setPreferredWidth(150);
                } else if (i == 1 || i == 5 || i == 9) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            lonres = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void donationRecord() {
        if (DonationRecord.d == 1) {
            str = "SELECT * FROM DONATION";
        } else if (DonationRecord.d == 2) {
            str = "SELECT * FROM DONATION WHERE DON_NAME='" + DonationRecord.name + "'";
        } else if (DonationRecord.d == 3) {
            str = "SELECT * FROM DONATION WHERE DON_DATE ='" + DonationRecord.getdate + "' ORDER BY DON_DATE ASC";
        }
        donationRec(str);
    }
    public static void donationRec(String query){
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            //"SERIAL_NO 0","DONNER_NAME0","DONNER_ADDRESS1","CONTACT_NO2",
            //"DONATION_PURPOSE3", "DONATION_TYPE4",
            //"DONATION_DATE5", "CASH_AMOUNT6","ACCOUNT_NO7", "PROPERTY_DETAILS8",
            //"CHEQUE_AMOUNT9", "CHEQUE_NO.10", "CHEQUE_DATE11", "BANK_NAME12",
            //"ENTRY_DATE13", "ENTRY_TIME14"
            rows = new Object[totalRows][records3.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String sno=rs.getString(16);
                rows[i][0] = sno;
                donname = rs.getString(1);
                rows[i][1] = donname;
                String donadd = rs.getString(13);
                rows[i][2] = donadd;
                String cont = rs.getString(14);
                rows[i][3] = cont;
                String purpose = rs.getString(15);
                rows[i][4] = purpose;
                String dontype = rs.getString(2);
                rows[i][5] = dontype;
                String cashamt = rs.getString(3);
                rows[i][7] = cashamt;
                String acno = rs.getString(12);
                rows[i][8] = acno;
                String prodetails = rs.getString(4);
                rows[i][9] = prodetails;
                String chamt = rs.getString(5);
                rows[i][10] = chamt;
                String chno = rs.getString(6);
                rows[i][11] = chno;
                String chdate = String.valueOf(rs.getDate(7));
                String dd4 = "";
                if (chdate.equals("null")) {
                    dd4 = "";
                } else {
                    String dd1 = chdate.substring(0, 4);
                    String dd2 = chdate.substring(5, 7);
                    String dd3 = chdate.substring(8, 10);
                    dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                }
                rows[i][12] = dd4;
                String bkname = rs.getString(8);
                rows[i][13] = bkname;
                String entdate = String.valueOf(rs.getDate(9));
                String end1 = entdate.substring(0, 4);
                String end2 = entdate.substring(5, 7);
                String end3 = entdate.substring(8, 10);
                String endd = end3.concat("-").concat(end2).concat("-").concat(end1);
                rows[i][14] = endd;
                String etime = rs.getString(10);
                rows[i][15] = etime;
                String dondate = String.valueOf(rs.getDate(11));
                String ld1 = dondate.substring(0, 4);
                String ld2 = dondate.substring(5, 7);
                String ld3 = dondate.substring(8, 10);
                String ldd = ld3.concat("-").concat(ld2).concat("-").concat(ld1);
                rows[i][6] = ldd;
            }
            jTable1 = new JTable(rows, records3);
            if (donname.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records3.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 3 || i == 12 || i == 10||i == 6 ||i == 14||i == 15||i == 0) {
                    column.setPreferredWidth(150);
                } else if ( i == 7) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            donname = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void staffRecord() {
        if (SchoolStaffRecord.e == 1||AdmissionOpen.old==1) {
            str = "SELECT * FROM STAFF_DETAILS ORDER BY STF_ID ASC";
        } else if (SchoolStaffRecord.e == 2) {
            str = "SELECT * FROM STAFF_DETAILS WHERE STF_ID='" + SchoolStaffRecord.stfid + "'";
        } else if (SchoolStaffRecord.e == 3) {
            str = "SELECT * FROM STAFF_DETAILS WHERE STF_NAME ='" + SchoolStaffRecord.name + "'ORDER BY STF_NAME ASC";
        }
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(str);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            //"STAFF_ID0", "STAFF_NAME1", "STAFF_DESIGNATION2", 
            //"QUALIFICATION3", "EXPERIANCE4", "CONTACT NO.5", 
            //"EMAIL ID6", "STAFF_ADDRESS.7", "DATE_OF_BIRTH8", 
            //"DATE_OF_JOIN9","BASIC_PAY10","DA11","HR12",
            //"CONVENIENCE ALLOWANCE13","ANUALLY_INCREAMENT14", 
            //"TOTAL_SALARY15", "ENTRY_DATE16", "ENTRY_TIME17"
            rows = new Object[totalRows][records4.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                staffid = rs.getString(1);
                rows[i][0] = staffid;
                String stfname = rs.getString(2);
                rows[i][1] = stfname;
                String desname = rs.getString(3);
                rows[i][2] = desname;
                String quali = rs.getString(4);
                rows[i][3] = quali;
                String exp = rs.getString(5);
                rows[i][4] = exp;
                String contact = rs.getString(6);
                rows[i][5] = contact;
                String email = rs.getString(7);
                rows[i][6] = email;
                String stfadd = rs.getString(8);
                rows[i][7] = stfadd;
                String dob = String.valueOf(rs.getDate(9));
                String dd1 = dob.substring(0, 4);
                String dd2 = dob.substring(5, 7);
                String dd3 = dob.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][8] = dd4;
                String doj = String.valueOf(rs.getDate(10));
                String doj1 = doj.substring(0, 4);
                String doj2 = doj.substring(5, 7);
                String doj3 = doj.substring(8, 10);
                String doj4 = doj3.concat("-").concat(doj2).concat("-").concat(doj1);
                rows[i][9] = doj4;
                String sal = rs.getString(14);
                rows[i][10] = sal;
                String da = rs.getString(19);
                rows[i][11] = da;
                String hr = rs.getString(12);
                rows[i][12] = hr;
                String conv = rs.getString(13);
                rows[i][13] = conv;
                String incr = rs.getString(11);
                rows[i][14] = incr;
                String totsal = rs.getString(15);
                rows[i][15] = totsal;
                String entdate = String.valueOf(rs.getDate(16));
                String end1 = entdate.substring(0, 4);
                String end2 = entdate.substring(5, 7);
                String end3 = entdate.substring(8, 10);
                String endd = end3.concat("-").concat(end2).concat("-").concat(end1);
                rows[i][16] = endd;
                String etime = rs.getString(17);
                rows[i][17] = etime;
            }
            jTable1 = new JTable(rows, records4);
            if (staffid.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records4.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if ( i == 5 || i == 8 || i == 11|| i == 9 || i == 12|| i == 10|| i == 13|| i == 14|| i == 15|| i == 16|| i == 17) {
                    column.setPreferredWidth(150);
                } else if (i == 0) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            staffid = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void schstaffPayment() {
        if (SchStaff.f == 1) {
            str = "SELECT * FROM STAFF_PAYMENT";
        } else if (SchStaff.f == 2) {
            str = "SELECT * FROM STAFF_PAYMENT WHERE STF_ID='" + SchStaff.stfid + "' ORDER BY STF_ID ASC";
        } else if (SchStaff.f == 3) {
            str = "SELECT * FROM STAFF_PAYMENT WHERE PAY_DATE ='" + SchStaff.getdate + "'ORDER BY PAY_DATE ASC";
        }
        schoolStaffPayment(str);
    }
    public static void schoolStaffPayment(String query){
        try {
//"STAFF_ID0","RECIEPT_NO1", "STAFF_NAME1", "STAFF_DESIGNATION2", "AUTHORITY3", "SALARY4","BASIC_PAY5","DA6","HR7","CONVENIENCE_ALLOWANCE8"
//,"ARREAR9","MISC10", "PAYABLE_AMOUNT11","PF12","G/S13","ADVANCE14","LOAN15", "DEDUCTION_AMOUNT16", "TOTAL_PAID_AMOUNT17", "PAYMENT_TYPE18", 
//"ACCOUNT_NO19", "CHEQUE_NO.20", "CHEQUE_DATE21", "BANK_NAME22","PAY_MONTH23", "PAYMENT_DATE24", "PAYMENT_TIME25"
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records5.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                staffid = rs.getString(1);
                rows[i][0] = staffid;
                String slno = rs.getString(28);
                rows[i][1] = slno;
                String stfname = rs.getString(2);
                rows[i][2] = stfname;
                String desname = rs.getString(3);
                rows[i][3] = desname;
                String auth = rs.getString(4);
                rows[i][4] = auth;
                String sal = rs.getString(5);
                rows[i][5] = sal;
                String paytype = rs.getString(6);
                rows[i][19] = paytype;
                String padamt = rs.getString(7);
                rows[i][12] = padamt;
                String deductamt = rs.getString(8);
                rows[i][17] = deductamt;
                String paydate = String.valueOf(rs.getDate(9));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                String etime = rs.getString(10);
                String totpamt = rs.getString(11);
                String chamt = rs.getString(12);
                if(chamt.equals("0")){
                    rows[i][18] = totpamt;
                }
                else{
                    rows[i][18] = chamt;
                }
                String chno = rs.getString(13);
                rows[i][21] = chno;
                String chdate = String.valueOf(rs.getDate(14));
                String chdd4 = "";
                if (chdate.equals("null")) {
                    chdd4 = "";
                } else {
                    String chdd1 = chdate.substring(0, 4);
                    String chdd2 = chdate.substring(5, 7);
                    String chdd3 = chdate.substring(8, 10);
                    chdd4 = chdd3.concat("-").concat(chdd2).concat("-").concat(chdd1);
                }
                rows[i][22] = chdd4;
                String bkname = rs.getString(15);
                rows[i][23] = bkname;
                rows[i][25] = dd4;
                rows[i][26] = etime;
                String acno = rs.getString(16);
                rows[i][20] = acno;
                String salmonth = rs.getString(17);
                rows[i][24] = salmonth;
                
                String basic = rs.getString(18);
                rows[i][6] = basic;
                String da = rs.getString(19);
                rows[i][7] = da;
                String hr = rs.getString(20);
                rows[i][8] = hr;
                String conv = rs.getString(21);
                rows[i][9] = conv;
                String arr = rs.getString(22);
                rows[i][10] = arr;
                String misc = rs.getString(23);
                rows[i][11] = misc;
                String pf = rs.getString(24);
                rows[i][13] = pf;
                String gs = rs.getString(25);
                rows[i][14] = gs;
                String adv = rs.getString(26);
                rows[i][15] = adv;
                String loan = rs.getString(27);
                rows[i][16] = loan;
            }
            jTable1 = new JTable(rows, records5);
            if (staffid.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records5.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 0 ||i == 1 ||i == 24 || i == 26 || i == 17  || i == 25|| i == 22|| i == 9|| i == 12|| i == 18|| i == 16) {
                    column.setPreferredWidth(150);
                } else if ( i == 5|| i == 6|| i == 7|| i == 10|| i == 13|| i == 14|| i == 15|| i == 8|| i == 11) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            staffid = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void miscPayRecord() {
        if (MiscPay.g == 1) {
            str = "SELECT * FROM MISC_PAYMENT";
        } else if (MiscPay.g == 2) {
            str = "SELECT * FROM MISC_PAYMENT WHERE NAME='" + MiscPay.name + "' ORDER BY NAME ASC";
        } else if (MiscPay.g == 3) {
            str = "SELECT * FROM MISC_PAYMENT WHERE PAY_DATE ='" + MiscPay.getdate + "'ORDER BY PAY_DATE ASC";
        }
        miscPaymentRecord(str);
    }
    public static void miscPaymentRecord(String query){
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records6.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(15);
                rows[i][0] = slno;
                stfname = rs.getString(1);
                rows[i][1] = stfname;
                String auth = rs.getString(2);
                rows[i][2] = auth;
                String authno = rs.getString(3);
                rows[i][3] = authno;
                String authdate = String.valueOf(rs.getDate(4));
                String autdd1 = authdate.substring(0, 4);
                String autdd2 = authdate.substring(5, 7);
                String autdd3 = authdate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][4] = autdd4;
                String payres = rs.getString(5);
                rows[i][5] = payres;
                String paytype = rs.getString(6);
                rows[i][6] = paytype;
                String padamt = rs.getString(7);            
                String chamt = rs.getString(8);
                if(chamt.equals("0")){
                    rows[i][7] = padamt;
                }
                else{
                rows[i][7] = chamt;
            }
                String chno = rs.getString(9);
                rows[i][9] = chno;
                String chdate = String.valueOf(rs.getDate(10));
                String chdd4 = "";
                if (chdate.equals("null")) {
                    chdd4 = "";
                } else {
                    String chdd1 = chdate.substring(0, 4);
                    String chdd2 = chdate.substring(5, 7);
                    String chdd3 = chdate.substring(8, 10);
                    chdd4 = chdd3.concat("-").concat(chdd2).concat("-").concat(chdd1);
                }
                rows[i][10] = chdd4;
                String bkname = rs.getString(11);
                rows[i][11] = bkname;
                String paydate = String.valueOf(rs.getDate(12));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][12] = dd4;
                String etime = rs.getString(13);
                rows[i][13] = etime;
                String acno = rs.getString(14);
                rows[i][8] = acno;
            }
            jTable1 = new JTable(rows, records6);
            if (stfname.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records6.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 0 ||i == 4 || i == 10 || i == 13 || i == 12) {
                    column.setPreferredWidth(150);
                } else if ( i == 7 ) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            stfname = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void bankRec() {
        if (Bank.h == 1) {
            str = "SELECT * FROM TO_BANK";
        } else if (Bank.h == 2) {
            str = "SELECT * FROM TO_BANK WHERE CHEK_NO='" + Bank.chno + "'";
        } else if (Bank.h == 3) {
            str = "SELECT * FROM TO_BANK WHERE ENTRY_DATE ='" + Bank.getdate + "'";
        }
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(str);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records7.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                bkname = rs.getString(1);
                rows[i][0] = bkname;
                String auth = rs.getString(2);
                rows[i][1] = auth;
                String authno = rs.getString(3);
                rows[i][2] = authno;
                String authdate = String.valueOf(rs.getDate(4));
                String autdd1 = authdate.substring(0, 4);
                String autdd2 = authdate.substring(5, 7);
                String autdd3 = authdate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][3] = autdd4;
                String amt = rs.getString(5);
                rows[i][4] = amt;
                String chno = rs.getString(6);
                rows[i][5] = chno;
                String entrydate = String.valueOf(rs.getDate(7));
                String dd1 = entrydate.substring(0, 4);
                String dd2 = entrydate.substring(5, 7);
                String dd3 = entrydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][6] = dd4;
                String etime = rs.getString(8);
                rows[i][7] = etime;
            }
            jTable1 = new JTable(rows, records7);
            if (bkname.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records7.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 4 || i == 6 || i == 7 || i == 3) {
                    column.setPreferredWidth(150);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            bkname = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }

    public static void fundRec() {
        if (Fund.i == 1) {
            str = "SELECT * FROM TO_FUND";
        } else if (Fund.i == 2) {
            str = "SELECT * FROM TO_FUND WHERE FUND_NAME='" + Fund.fdname + "'";
        } else if (Fund.i == 3) {
            str = "SELECT * FROM TO_FUND WHERE CHEK_NO ='" + Fund.chno + "'";
        }
        try {

            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(str);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][records8.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                fdname = rs.getString(1);
                rows[i][0] = fdname;
                String auth = rs.getString(2);
                rows[i][1] = auth;
                String authno = rs.getString(3);
                rows[i][2] = authno;
                String authdate = String.valueOf(rs.getDate(4));
                String autdd1 = authdate.substring(0, 4);
                String autdd2 = authdate.substring(5, 7);
                String autdd3 = authdate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][3] = autdd4;
                String amt = rs.getString(5);
                rows[i][4] = amt;
                String chno = rs.getString(6);
                rows[i][5] = chno;
                String entrydate = String.valueOf(rs.getDate(7));
                String dd1 = entrydate.substring(0, 4);
                String dd2 = entrydate.substring(5, 7);
                String dd3 = entrydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][6] = dd4;
                String etime = rs.getString(8);
                rows[i][7] = etime;
            }
            jTable1 = new JTable(rows, records8);
            if (fdname.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records8.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 4 || i == 6 || i == 7 || i == 3) {
                    column.setPreferredWidth(150);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            fdname = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public void loginRecord(){
        try {

           java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String strt="SELECT * FROM LOGIN_RECORD ORDER BY LOGIN_DATE ASC";
            rs = stmt.executeQuery(strt);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String logindate = String.valueOf(rs.getDate(1));
                String autdd1 = logindate.substring(0, 4);
                String autdd2 = logindate.substring(5, 7);
                String autdd3 = logindate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][0] = autdd4;
                String logintime = rs.getString(2);
                rows[i][1] = logintime;
                String userid = rs.getString(3);
                rows[i][2] = userid;
                String username = rs.getString(4);
                rows[i][3] = username;
            }
            jTable1 = new JTable(rows, record);
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 14));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 0 || i == 1 ) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(181);
                }
            }
            totalRows = 0;
            jsp= new JScrollPane(jTable1);
            add(jsp);
            con.close();
            stmt.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            flag = false;
        }
    }
    public void stationeryRecord(String query){
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            //"RECEIPT_NO","STUDENT_NAME","CLASS","NO_OF_BOOKS0", "AMOUNT1", "NO_OF_NOTEBOOKS.2", "AMOUNT3", 
            //"NO_OF_DRESS4", "AMOUNT5","NO_OF_TYE6","AMOUNT7","NO_OF_BELT8",
            //"AMOUNT9","NO_OF_ICARD10","AMOUNT11","NO_OF_DIARY","AMOUNT","MISCELLANEOUS_AMOUNT","TOTAL_AMOUNT12", "ENTRY_DATE13", "ENTRY_TIME14"
            rows = new Object[totalRows][records9.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(21);
                rows[i][0] = slno;
                String name = rs.getString(16);
                rows[i][1] = name;
                String roll2 = rs.getString(22);
                rows[i][2] = roll2;
                String class1 = rs.getString(17);
                rows[i][3] = class1;
                String section = rs.getString(23);
                rows[i][4] = section;
                books = rs.getString(10);
                rows[i][5] = books;
                String bkamt = rs.getString(1);
                rows[i][6] = bkamt;
                String notebook = rs.getString(11);
                rows[i][7] = notebook;
                String nbamt = rs.getString(2);
                rows[i][8] = nbamt;
                String dress = rs.getString(12);
                rows[i][9] = dress;
                String dressamt = rs.getString(3);
                rows[i][10] = dressamt;
                String tye = rs.getString(13);
                rows[i][11] = tye;
                String tyeamt = rs.getString(4);
                rows[i][12] = tyeamt;
                String belt = rs.getString(14);
                rows[i][13] = belt;
                String beltamt = rs.getString(5);
                rows[i][14] = beltamt;
                String icard = rs.getString(15);
                rows[i][15] = icard;
                String icardamt = rs.getString(6);
                rows[i][16] = icardamt;
                String diary = rs.getString(19);
                rows[i][17] = diary;
                String diaryamt = rs.getString(18);
                rows[i][18] = diaryamt;
                String miscamt = rs.getString(20);
                rows[i][19] = miscamt;
                String totalamt = rs.getString(9);
                rows[i][20] = totalamt;
                String entrydate = String.valueOf(rs.getDate(7));
                String dd1 = entrydate.substring(0, 4);
                String dd2 = entrydate.substring(5, 7);
                String dd3 = entrydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][21] = dd4;
                String etime = rs.getString(8);
                rows[i][22] = etime;
            }
            jTable1 = new JTable(rows, records9);
            if (books.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < records9.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i==0||i == 3||i==19||i==20||i==7||i==21||i==22) {
                    column.setPreferredWidth(150);
                }
                else if(i==4||i==6||i==8||i==9||i==10||i==11||i==12|| i == 14||i==15||i==16||i == 2||i==5|| i == 13||i==17||i==18){
                    column.setPreferredWidth(100);
                }
                else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            books = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void vehicleTax(String query) {    
        try {
           java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            rs.last();
            totalRows++;            
            rows = new Object[totalRows][record10.length];            
                regno = rs.getString(1);
                rows[0][0] = regno;
                String paydate = String.valueOf(rs.getDate(2));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[0][1] = dd4;
                String taxamt = rs.getString(3);
                rows[0][2] = taxamt;
                String period=rs.getString(4);
                rows[0][3] = period;    
                String nextduedate = String.valueOf(rs.getDate(5));
                String ddr1 = nextduedate.substring(0, 4);
                String ddr2 = nextduedate.substring(5, 7);
                String ddr3 = nextduedate.substring(8, 10);
                String ddr4 = ddr3.concat("-").concat(ddr2).concat("-").concat(ddr1);
                rows[0][4] = ddr4;
                String entrydate = String.valueOf(rs.getDate(6));
                String dd11 = entrydate.substring(0, 4);
                String dd22 = entrydate.substring(5, 7);
                String dd33 = entrydate.substring(8, 10);
                String dd44 = dd33.concat("-").concat(dd22).concat("-").concat(dd11);
                rows[0][5] = dd44;
                String etime = rs.getString(7);
                rows[0][6] = etime;
            jTable2 = new JTable(rows, record10);
            if (regno.equals("")) {
                flag1 = false;
            } else {
                flag1 = true;
            }
            jTable2.setRowHeight(30);
            jTable2.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable2.setShowVerticalLines(true);
            jTable2.setShowHorizontalLines(true);
            jTable2.setShowGrid(true);
            jTable2.setGridColor(Color.BLACK);
            jTable2.setForeground(Color.BLACK.brighter());
            jTable2.setEnabled(false);
            jTable2.setSelectionBackground(Color.black);
            jTable2.setBackground(Color.WHITE);
            jTable2.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record10.length; i++) {
                column = jTable2.getColumnModel().getColumn(i);
                column.setPreferredWidth(150); 
            }
            totalRows = 0;
            regno = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag1 = false;
        }
    }
    public static void vehicleFitness(String query) {    
        try {
           java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            rs.last();
            totalRows++;
            rows = new Object[totalRows][record11.length];
                regno = rs.getString(1);
                rows[0][0] = regno;
                String paydate = String.valueOf(rs.getDate(2));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[0][1] = dd4;
                String fitamt = rs.getString(3);
                rows[0][2] = fitamt;
                String period=rs.getString(4);
                rows[0][3] = period;    
                String nextduedate = String.valueOf(rs.getDate(5));
                String ddr1 = nextduedate.substring(0, 4);
                String ddr2 = nextduedate.substring(5, 7);
                String ddr3 = nextduedate.substring(8, 10);
                String ddr4 = ddr3.concat("-").concat(ddr2).concat("-").concat(ddr1);
                rows[0][4] = ddr4;
                String entrydate = String.valueOf(rs.getDate(6));
                String dd11 = entrydate.substring(0, 4);
                String dd22 = entrydate.substring(5, 7);
                String dd33 = entrydate.substring(8, 10);
                String dd44 = dd33.concat("-").concat(dd22).concat("-").concat(dd11);
                rows[0][5] = dd44;
                String etime = rs.getString(7);
                rows[0][6] = etime;          
            jTable3 = new JTable(rows, record11);
            if (regno.equals("")) {
                flag2 = false;
            } else {
                flag2 = true;
            }
            jTable3.setRowHeight(30);
            jTable3.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable3.setShowVerticalLines(true);
            jTable3.setShowHorizontalLines(true);
            jTable3.setShowGrid(true);
            jTable3.setGridColor(Color.BLACK);
            jTable3.setForeground(Color.BLACK.brighter());
            jTable3.setEnabled(false);
            jTable3.setSelectionBackground(Color.black);
            jTable3.setBackground(Color.WHITE);
            jTable3.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record10.length; i++) {
                column = jTable3.getColumnModel().getColumn(i);
                column.setPreferredWidth(150); 
            }
            totalRows = 0;
            regno = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag2 = false;
        }
    }
    public static void vehicleInsurance(String query) {    
        try {
           java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            rs.last();
            totalRows++;
            rows = new Object[totalRows][record12.length];           
                regno = rs.getString(1);
                rows[0][0] = regno;
                String paydate = String.valueOf(rs.getDate(2));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[0][1] = dd4;
                String incamt = rs.getString(3);
                rows[0][2] = incamt;
                String period=rs.getString(4);
                rows[0][3] = period;    
                String nextduedate = String.valueOf(rs.getDate(5));
                String ddr1 = nextduedate.substring(0, 4);
                String ddr2 = nextduedate.substring(5, 7);
                String ddr3 = nextduedate.substring(8, 10);
                String ddr4 = ddr3.concat("-").concat(ddr2).concat("-").concat(ddr1);
                rows[0][4] = ddr4;
                String entrydate = String.valueOf(rs.getDate(6));
                String dd11 = entrydate.substring(0, 4);
                String dd22 = entrydate.substring(5, 7);
                String dd33 = entrydate.substring(8, 10);
                String dd44 = dd33.concat("-").concat(dd22).concat("-").concat(dd11);
                rows[0][5] = dd44;
                String etime = rs.getString(7);
                rows[0][6] = etime;                
            
            jTable4 = new JTable(rows, record12);
            if (regno.equals("")) {
                flag3 = false;
            } else {
                flag3 = true;
            }
            jTable4.setRowHeight(30);
            jTable4.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable4.setShowVerticalLines(true);
            jTable4.setShowHorizontalLines(true);
            jTable4.setShowGrid(true);
            jTable4.setGridColor(Color.BLACK);
            jTable4.setForeground(Color.BLACK.brighter());
            jTable4.setEnabled(false);
            jTable4.setSelectionBackground(Color.black);
            jTable4.setBackground(Color.WHITE);
            jTable4.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable4.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record12.length; i++) {
                column = jTable4.getColumnModel().getColumn(i);
                    column.setPreferredWidth(150);
            }
            totalRows = 0;
            regno = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag3 = false;
        }
    }
    public static void vehicleRecord(String query) {
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record13.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                regno1 = rs.getString(1);
                rows[i][0] = regno1;
                String name = rs.getString(2);
                rows[i][1] = name;
                String purchdate = String.valueOf(rs.getDate(3));
                String dd1 = purchdate.substring(0, 4);
                String dd2 = purchdate.substring(5, 7);
                String dd3 = purchdate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][2] = dd4;
                String regdate = String.valueOf(rs.getDate(4));
                String autdd1 = regdate.substring(0, 4);
                String autdd2 = regdate.substring(5, 7);
                String autdd3 = regdate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][3] = autdd4;
                String make = rs.getString(5);
                rows[i][4] = make;               
                String vtype = rs.getString(6);
                rows[i][5] = vtype;
                String ftype = rs.getString(7);
                rows[i][6] = ftype;
                String cap = rs.getString(8);
                rows[i][7] = cap;
                String entrydate = String.valueOf(rs.getDate(9));
                String ddr1 = entrydate.substring(0, 4);
                String ddr2 = entrydate.substring(5, 7);
                String ddr3 = entrydate.substring(8, 10);
                String ddr4 = ddr3.concat("-").concat(ddr2).concat("-").concat(ddr1);
                rows[i][8] = ddr4;
                String etime = rs.getString(10);
                rows[i][9] = etime;
            }
            jTable1 = new JTable(rows, record13);
            if (regno1.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record13.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 2 || i == 3|| i == 5|| i == 8|| i == 9) {
                    column.setPreferredWidth(150);
                }
                else if(i == 6 || i == 7){
                    column.setPreferredWidth(100);
                }
                else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            regno1 = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void nocRecord(String query) {
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record14.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                admno = rs.getString(1);
                rows[i][0] = admno;
                String purchdate = String.valueOf(rs.getDate(2));
                String dd1 = purchdate.substring(0, 4);
                String dd2 = purchdate.substring(5, 7);
                String dd3 = purchdate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][1] = dd4;
                String name = rs.getString(3);
                rows[i][2] = name;
                String fname = rs.getString(4);
                rows[i][3] = fname;
                String regdate = String.valueOf(rs.getDate(5));
                String autdd1 = regdate.substring(0, 4);
                String autdd2 = regdate.substring(5, 7);
                String autdd3 = regdate.substring(8, 10);
                String autdd4 = autdd3.concat("-").concat(autdd2).concat("-").concat(autdd1);
                rows[i][4] = autdd4;
                String add = rs.getString(6);
                rows[i][5] = add;               
                String entrydate = String.valueOf(rs.getDate(7));
                String ddr1 = entrydate.substring(0, 4);
                String ddr2 = entrydate.substring(5, 7);
                String ddr3 = entrydate.substring(8, 10);
                String ddr4 = ddr3.concat("-").concat(ddr2).concat("-").concat(ddr1);
                rows[i][6] = ddr4;
                String etime = rs.getString(8);
                rows[i][7] = etime;
            }
            jTable1 = new JTable(rows, record14);
            if (admno.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record14.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 1 || i == 4|| i == 6||i == 7) {
                    column.setPreferredWidth(150);
                }
                else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            admno = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
//    private static String[] record15 = {"ADMISSION_NO.", "RECEIPT_NO", "STUDENT_NAME","CLASS", "TOTAL_AMOUNT", "PAID_AMOUNT", "DUE_AMOUNT", "PAYMENT_TYPE", "PAY_MONTH","PAY_DATE","PAY_TIME"};
//    private static String[] record16 = {"ADMISSION_NO.", "RECEIPT_NO", "STUDENT_NAME","CLASS", "TOTAL_AMOUNT", "PAYMENT_STATUS","ADMISSION_DATE","ADMISSION_TIME"};
    //"SELECT ADMISSION_NO,SL_NO,STD_NAME,CLASS,TPA,CASH_AMOUNT,CHEK_AMT,DA,PAY_TYPE,PAY_MONTH,PAY_DATE,PAY_TIME
    public static void studentFeeCollection(String query){
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record15.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                admno1 = rs.getString(1);
                rows[i][0] = admno1;
                String slno = rs.getString(2);
                rows[i][1] = slno;
                String name = rs.getString(3);
                rows[i][2] = name;
                String class1 = rs.getString(4);
                rows[i][3] = class1;
                String tpa = rs.getString(5);
                rows[i][4] = tpa;
                String cash = rs.getString(6);
                String chamt = rs.getString(7);
                if (chamt.equals("0")) {
                    rows[i][5] = cash;
                } else {
                    rows[i][5] = chamt;
                }
                String da = rs.getString(8);
                rows[i][6] = da;
                String paytype=rs.getString(9);
                rows[i][7] = paytype;
                String pmonth = rs.getString(10);
                rows[i][8] = pmonth;
                String pdate = String.valueOf(rs.getDate(11));//"1992-04-03"
                String st1 = pdate.substring(0, 4);
                String st2 = pdate.substring(5, 7);
                String st3 = pdate.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                rows[i][9] = st4;
                String ptime = rs.getString(12);
                rows[i][10] = ptime;
            }
            jTable1 = new JTable(rows, record15);
            if (admno1.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record15.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 3||i==4||i == 10 || i == 7 || i == 5 || i == 8|| i == 9|| i == 6) {
                    column.setPreferredWidth(150);
                }
                 else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            admno1 = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void admissionFee(String query){
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record16.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                admno2 = rs.getString(1);
                rows[i][0] = admno2;
                String slno = rs.getString(2);
                rows[i][1] = slno;
                String name = rs.getString(3);
                rows[i][2] = name;
                String class1 = rs.getString(4);
                rows[i][3] = class1;
                String tpa = rs.getString(5);
                rows[i][4] = tpa;
                String status = rs.getString(6);
                rows[i][5] = status;
                String pdate = String.valueOf(rs.getDate(7));//"1992-04-03"
                String st1 = pdate.substring(0, 4);
                String st2 = pdate.substring(5, 7);
                String st3 = pdate.substring(8, 10);
                String st4 = st3.concat("-").concat(st2).concat("-").concat(st1);
                rows[i][6] = st4;
                String ptime = rs.getString(8);
                rows[i][7] = ptime;
            }
            jTable1 = new JTable(rows, record16);
            if (admno2.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record16.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i == 3||i==4 || i == 7 || i == 5 || i == 6) {
                    column.setPreferredWidth(150);
                }
                 else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            admno2 = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void miscCollection(String query){
        try {
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record17.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                slipno = rs.getString(1);
                rows[i][0] = slipno;
                String name = rs.getString(2);
                rows[i][1] = name;
                String padamt = rs.getString(3);            
                String chamt = rs.getString(4);
                if(chamt.equals("0")){
                    rows[i][2] = padamt;
                }
                else{
                rows[i][2] = chamt;
            }
                String paytype = rs.getString(5);
                rows[i][3] = paytype;
                String payres = rs.getString(6);
                rows[i][4] = payres;
                String paydate = String.valueOf(rs.getDate(7));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][5] = dd4;
                String etime = rs.getString(8);
                rows[i][6] = etime;
            }
            jTable1 = new JTable(rows, record17);
            if (slipno.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record17.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i==5||i==6||i == 10 || i == 13 || i == 12) {
                    column.setPreferredWidth(150);
                } else if ( i == 7 ||i==2) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            slipno = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void staffPaymentCollection(String query){
        try {
//"STAFF_ID0","RECIEPT_NO1", "STAFF_NAME1", "STAFF_DESIGNATION2", "AUTHORITY3", "SALARY4","BASIC_PAY5","DA6","HR7","CONVENIENCE_ALLOWANCE8"
//,"ARREAR9","MISC10", "PAYABLE_AMOUNT11","PF12","G/S13","ADVANCE14","LOAN15", "DEDUCTION_AMOUNT16", "TOTAL_PAID_AMOUNT17", "PAYMENT_TYPE18", 
//"ACCOUNT_NO19", "CHEQUE_NO.20", "CHEQUE_DATE21", "BANK_NAME22","PAY_MONTH23", "PAYMENT_DATE24", "PAYMENT_TIME25"
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
            }
            rows = new Object[totalRows][record18.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(1);
                rows[i][0] = slno;
                staffid1 = rs.getString(2);
                rows[i][1] = staffid1;               
                String name = rs.getString(3);
                rows[i][2] = name;
                String sal = rs.getString(4);
                rows[i][3] = sal;
                String padamt = rs.getString(5);
                rows[i][4] = padamt;
                String deductamt = rs.getString(6);
                rows[i][5] = deductamt;
                String totpamt = rs.getString(7);
                String chamt = rs.getString(8);
                if(chamt.equals("0")){
                    rows[i][6] = totpamt;
                }
                else{
                    rows[i][6] = chamt;
                }
                String paytype = rs.getString(9);
                rows[i][7] = paytype;
                String salmonth = rs.getString(10);
                rows[i][8] = salmonth;
                String basic = rs.getString(11);
                rows[i][9] = basic;
                String da = rs.getString(12);
                rows[i][10] = da;
                String hr = rs.getString(13);
                rows[i][11] = hr;
                String conv = rs.getString(14);
                rows[i][12] = conv;
                String arr = rs.getString(15);
                rows[i][13] = arr;
                String misc = rs.getString(16);
                rows[i][14] = misc;
                String pf = rs.getString(17);
                rows[i][15] = pf;
                String gs = rs.getString(18);
                rows[i][16] = gs;
                String adv = rs.getString(19);
                rows[i][17] = adv;
                String loan = rs.getString(20);
                rows[i][18] = loan;
                String paydate = String.valueOf(rs.getDate(21));
                String dd1 = paydate.substring(0, 4);
                String dd2 = paydate.substring(5, 7);
                String dd3 = paydate.substring(8, 10);
                String dd4 = dd3.concat("-").concat(dd2).concat("-").concat(dd1);
                rows[i][19] = dd4;                
                String etime = rs.getString(22);
                rows[i][20] = etime;
            }
            jTable1 = new JTable(rows, record18);
            if (staffid1.equals("")) {
                flag = false;
            } else {
                flag = true;
            }
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record18.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i==4||i == 1 || i == 17  || i == 19|| i == 20|| i == 9|| i == 12|| i == 18|| i == 7) {
                    column.setPreferredWidth(150);
                } else if (i==3|| i == 6|| i == 10|| i == 13|| i == 14|| i == 15|| i == 8|| i == 11|| i == 16) {
                    column.setPreferredWidth(100);
                } else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            staffid1 = "";
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void totalCollectionReport(String curdate){
        try {
            String query="";
            String query1="";
            String query2="";
            boolean chek=false;
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);            
            query="SELECT SL_NO,STD_NAME,CLASS,CASH_AMOUNT,CHEK_AMT,PAY_TYPE FROM STUDENT_FEE WHERE PAY_DATE='"+curdate+"'";  
            query1="SELECT ADM_RECEIPT_NO,STUDENT_NAME,CLASS,TOTAL_ADM_FEE,FEE_DETAILS FROM NEWADMISSION WHERE ADMISSION_DATE='"+curdate+"' AND FEE_DETAILS='"+"Paid"+"'";
            query2="SELECT SL_NO,STD_NAME,CLASS,TOTAL_AMT FROM STATIONERY WHERE ENTRY_DATE='"+curdate+"'";              
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
                chek=true;
            }
            rs = stmt.executeQuery(query1);
            for (int a = 0; rs.next(); a++) {
                totalRows++;
                chek=true;
            }
            rs = stmt.executeQuery(query2);
            for (int a = 0; rs.next(); a++) {
                totalRows++;
                chek=true;
            }
            if(chek==true){
            totalRows++;
            }
            rows = new Object[totalRows][record19.length];
            rs = stmt.executeQuery(query);
            rs.beforeFirst();
            int i;
            for (i = 0; rs.next(); i++) {
                String slno = rs.getString(1);
                rows[i][0] = slno;
                String name = rs.getString(2);
                rows[i][1] = name;               
                String class1 = rs.getString(3);
                rows[i][2] = class1;
                String totamt = rs.getString(4);
                String chamt = rs.getString(5);
                if(chamt.equals("0")){
                    rows[i][3] = totamt;
                }
                else{
                    rows[i][3] = chamt;
                }
                String paytype = rs.getString(6);
                rows[i][4] = paytype;
                chek=true;
            }
            int j;
            rs = stmt.executeQuery(query1);
            rs.beforeFirst();
            for (j=i; rs.next(); j++) {
                String slno = rs.getString(1);
                rows[j][0] = slno;
                String name = rs.getString(2);
                rows[j][1] = name;               
                String class1 = rs.getString(3);
                rows[j][2] = class1;
                String totamt = rs.getString(4);
                rows[j][3] = totamt;
                String feedt = rs.getString(5);
                rows[j][4] = feedt;
                chek=true;
            }
            int k;            
            rs = stmt.executeQuery(query2);
            rs.beforeFirst();           
            for (k=j; rs.next(); k++) {
                String slno = rs.getString(1);
                rows[k][0] = slno;
                String name = rs.getString(2);
                rows[k][1] = name;               
                String class1 = rs.getString(3);
                rows[k][2] = class1;
                String totamt = rs.getString(4);
                rows[k][3] = totamt;
                chek=true;
            }
            if(chek==true){
            rows[totalRows-1][2]="TOTAL";
            rows[totalRows-1][3]=CollectionPanel.totalcollection;
            }
            jTable5 = new JTable(rows, record19);
            if (chek==false) {
                flag = false;
            } else {
                flag = true;
            }
            jTable5.setRowHeight(30);
            jTable5.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable5.setShowVerticalLines(true);
            jTable5.setShowHorizontalLines(true);
            jTable5.setShowGrid(true);
            jTable5.setGridColor(Color.BLACK);
            jTable5.setForeground(Color.BLACK.brighter());
            jTable5.setEnabled(false);
            jTable5.setSelectionBackground(Color.black);
            jTable5.setBackground(Color.WHITE);
            jTable5.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable5.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            //"RECEIPT_NO", "STUDENT_NAME","CLASS", "PAID_AMOUNT", "PAYMENT_TYPE"
            for (i = 0; i < record19.length; i++) {
                column = jTable5.getColumnModel().getColumn(i);
                if (i==0||i == 1|| i == 4) {
                    column.setPreferredWidth(150);
                } else if ( i == 2|| i == 3) {
                    column.setPreferredWidth(109);
                }
            }
            totalRows = 0;
            chek=false;
            i=0;
            j=0;
            k=0;
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void stfExpenseReport(String curdate){
        //private static String[] record20 ={"RECEIPT_NO", "STAFF_NAME", "PAYABLE_AMOUNT","DEDUCTION_AMOUNT", "AMOUNT_PAID"};
    //private static String[] record21 ={"RECEIPT_NO", "NAME", "AMOUNT_PAID","PURPOSE_OF_PAYMENT", "PAYMENT_TYPE"};
        try {
            boolean chek=false;
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String query="SELECT SL_NO,STF_NAME,PAY_AMT,DECT_AMT,TPAY_AMT,CHEK_AMT FROM STAFF_PAYMENT WHERE PAY_DATE='"+curdate+"'";  
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
                chek=true;
            }
            if(chek==true){
              totalRows++;
            }
            rows = new Object[totalRows][record20.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(1);
                rows[i][0] = slno;
                String name = rs.getString(2);
                rows[i][1] = name;
                String padamt = rs.getString(3);
                rows[i][2] = padamt;
                String dectamt=rs.getString(4);
                rows[i][3] = dectamt;
                String totamt=rs.getString(5);
                String chamt = rs.getString(6);
                if(chamt.equals("0")){
                    rows[i][4] = totamt;
                }
                else{
                rows[i][4] = chamt;
            }
                chek=true;
            }
            if(chek==true){
            rows[totalRows-1][3]="TOTAL";
            rows[totalRows-1][4]=ExpensesPanel.totalstfexpenses;
            }
            jTable6 = new JTable(rows, record20);
            if (chek==false) {
                flag = false;
            } else {
                flag = true;
            }
            jTable6.setRowHeight(30);
            jTable6.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable6.setShowVerticalLines(true);
            jTable6.setShowHorizontalLines(true);
            jTable6.setShowGrid(true);
            jTable6.setGridColor(Color.BLACK);
            jTable6.setForeground(Color.BLACK.brighter());
            jTable6.setEnabled(false);
            jTable6.setSelectionBackground(Color.black);
            jTable6.setBackground(Color.WHITE);
            jTable6.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable6.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record20.length; i++) {
                column = jTable6.getColumnModel().getColumn(i);
                if (i==0||i == 1|| i == 4) {
                    column.setPreferredWidth(150);
                } else if ( i == 2|| i == 3) {
                    column.setPreferredWidth(109);
                }
            }
            totalRows = 0;
            chek=false;
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
    public static void miscExpenseReport(String curdate){
        //private static String[] record20 ={"RECEIPT_NO", "STAFF_NAME", "PAYABLE_AMOUNT","DEDUCTION_AMOUNT", "AMOUNT_PAID"};
    //private static String[] record21 ={"RECEIPT_NO", "NAME", "AMOUNT_PAID","PURPOSE_OF_PAYMENT", "PAYMENT_TYPE"};
        try {
            boolean chek=false;
            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String query="SELECT SL_NO,NAME,PAY_AMT,CHEK_AMT,PAY_RESON,PAY_TYPE FROM MISC_PAYMENT WHERE PAY_DATE='"+curdate+"'";  
            rs = stmt.executeQuery(query);
            for (int i = 0; rs.next(); i++) {
                totalRows++;
                chek=true;
            }
            if(chek==true){
              totalRows++;
            }
            rows = new Object[totalRows][record21.length];
            rs.beforeFirst();
            for (int i = 0; rs.next(); i++) {
                String slno = rs.getString(1);
                rows[i][0] = slno;
                String name = rs.getString(2);
                rows[i][1] = name;
                String padamt = rs.getString(3);
                String chamt = rs.getString(4);
                if(chamt.equals("0")){
                    rows[i][2] = padamt;
                }
                else{
                rows[i][2] = chamt;
            }                              
                String payres=rs.getString(5);
                rows[i][3] = payres;
                String paytype=rs.getString(6);
                rows[i][4] = paytype;
                chek=true;
            }
            if(chek==true){
            rows[totalRows-1][1]="TOTAL";
            rows[totalRows-1][2]=ExpensesPanel.totalmiscexpenses;
            }
            jTable6 = new JTable(rows, record21);
            if (chek==false) {
                flag = false;
            } else {
                flag = true;
            }
            jTable6.setRowHeight(30);
            jTable6.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable6.setShowVerticalLines(true);
            jTable6.setShowHorizontalLines(true);
            jTable6.setShowGrid(true);
            jTable6.setGridColor(Color.BLACK);
            jTable6.setForeground(Color.BLACK.brighter());
            jTable6.setEnabled(false);
            jTable6.setSelectionBackground(Color.black);
            jTable6.setBackground(Color.WHITE);
            jTable6.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable6.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record21.length; i++) {
                column = jTable6.getColumnModel().getColumn(i);
                if (i==0||i == 1|| i == 4) {
                    column.setPreferredWidth(150);
                } else if ( i == 2|| i == 3) {
                    column.setPreferredWidth(109);
                }
            }
            totalRows = 0;
            chek=false;
            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            flag = false;
        }
    }
public static void allDuesReport(String admclass){
//    java.sql.Connection con=null;
//    int j=0,i=0,a=0,c=0;
//    int length=0,feedues;
//    boolean flagy=false;
//    String name="",rollall="",class1="",transfee="";
//    String da,paydate,paymonth,pm1;
//    String yearno=NewJPanel.year;
//    String curdate=NewAdmPanel.date(NewJPanel.lbldate.getText().substring(5,NewJPanel.lbldate.getText().length()));//21-Aug-2015
//    String month1=curdate.substring(3,6);
//    try{
//    con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
//    }
//    catch(SQLException ex){
//        ex.printStackTrace();
//    }       
//            try{
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
//            String strt="SELECT ADMISSION_NO FROM NEWADMISSION ORDER BY ADMISSION_NO ASC";
//            rs=stmt.executeQuery(strt);
//            while(rs.next()){
//                j++;
//            }
//            alladmno=new String[j];
//            rs=stmt.executeQuery(strt);
//            while(rs.next()){
//            alladmno[i]=rs.getString(1);
//                i++;
//            }
//            stmt.close();
//            rs.close();
//        }
//        catch(SQLException ex){
//             ex.printStackTrace();   
//            }
//            try{
//                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);                
//                length=alladmno.length;
//            for(int k=0;k<alladmno.length;k++){                
//                String str3 = "SELECT PAY_MONTH,PAY_DATE FROM STUDENT_FEE WHERE ADMISSION_NO='" + alladmno[k] + "' ORDER BY SL_NO ASC";                
//                rs = stmt.executeQuery(str3);
//                rs.last();               
//                paymonth=rs.getString(1);
//                String date = String.valueOf(rs.getDate(2));
//                String d1 = date.substring(0, 4);
//                paydate=d1;
//                if(paymonth.length()==3){
//                        pm1=paymonth;
//                    }
//                    else{
//                pm1=paymonth.substring(4, 7);
//                    }
//                if(paydate.equals(yearno)){
//                    if(pm1.equals(month1)){
//                        flagy=false;
//                        length=length-1;
//                    }
//                    else{
//                        for(int l=0;l<month.length;l++){
//                            a++;
//                         if(pm1.equals(month[l])){
//                             a=0;
//                         }
//                            if(month[l].equals(month1)){
//                                flagy=true;
//                               break; 
//                            }                                                                          
//                        }
//                    }
//                }
//                else if(Integer.parseInt(yearno)>Integer.parseInt(paydate)){
//                    for(int l=0;l<month.length;l++){
//                            a++;
//                         if(pm1.equals(month[l])){
//                             a=0;
//                         }                             
//                         if(month[l].equals(month1)){
//                               flagy=true;
//                               break; 
//                            } 
//                                                  
//                         if(month[l].equals("Dec")){
//                             l=0;
//                         }
//                        }
//                }                
//            }
//            
//        }
//            catch(SQLException ex){
//             ex.printStackTrace();  
//            }
//            try{
//                rows = new Object[length][record22.length];
//                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);                
//            for(int k=0;k<alladmno.length;k++){
//                String str1 = "SELECT STUDENT_NAME,ROLL_NO,CLASS,TRANS_FEE FROM NEWADMISSION WHERE ADMISSION_NO='" + alladmno[k] + "'";
//                rs=stmt.executeQuery(str1);
//                while(rs.next()){
//                    name=rs.getString(1);
//                    rollall=rs.getString(2);
//                    class1=rs.getString(3);
//                    transfee=rs.getString(4);
//                }
//                String str2 = "SELECT TUT_FEE FROM FEE_DETAILS WHERE CLASS='" + class1 + "'";
//                rs=stmt.executeQuery(str2);
//                rs.first();
//                String tutfee=rs.getString(1);
//                String str3 = "SELECT DA,PAY_MONTH,PAY_DATE FROM STUDENT_FEE WHERE ADMISSION_NO='" + alladmno[k] + "' ORDER BY SL_NO ASC";
//                rs = stmt.executeQuery(str3);
//                rs.last();
//                da=rs.getString(1);
//                paymonth=rs.getString(2);
//                String date = String.valueOf(rs.getDate(3));
//                String d1 = date.substring(0, 4);
//                paydate=d1;
//                if(paymonth.length()==3){
//                        pm1=paymonth;
//                    }
//                    else{
//                pm1=paymonth.substring(4, 7);
//                    }
//                if(paydate.equals(yearno)){
//                    if(pm1.equals(month1)){
//                        flagy=false;                        
//                    }
//                    else{
//                        for(int l=0;l<month.length;l++){
//                            a++;
//                         if(pm1.equals(month[l])){
//                             a=0;
//                         }
//                            if(month[l].equals(month1)){
//                                flagy=true;
//                               break; 
//                            }                                                                          
//                        }
//                    }
//                }
//                else if(Integer.parseInt(yearno)>Integer.parseInt(paydate)){
//                    for(int l=0;l<month.length;l++){
//                            a++;
//                         if(pm1.equals(month[l])){
//                             a=0;
//                         }                             
//                         if(month[l].equals(month1)){
//                               flagy=true;
//                               break; 
//                            } 
//                                                  
//                         if(month[l].equals("Dec")){
//                             l=0;
//                         }
//                        }
//                }
//                if(flagy==true){
//                feedues=a*(Integer.parseInt(transfee)+Integer.parseInt(tutfee))+Integer.parseInt(da);                
//                    rows[c][0]=name;
//                    rows[c][1]=class1;
//                    rows[c][2]=rollall;
//                    rows[c][3]=pm1;
//                    rows[c][4]=feedues;
//                    rows[c+3][3]="Total Amount";
//                    rows[c+3][4]=feedues;
//                    c=c+4;
//                }
//            }
//            jTable1 = new JTable(rows, record22);
//            jTable1.setRowHeight(30);
//            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
//            jTable1.setShowVerticalLines(true);
//            jTable1.setShowHorizontalLines(true);
//            jTable1.setShowGrid(true);
//            jTable1.setGridColor(Color.BLACK);
//            jTable1.setForeground(Color.BLACK.brighter());
//            jTable1.setEnabled(false);
//            jTable1.setSelectionBackground(Color.black);
//            jTable1.setBackground(Color.WHITE);
//            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
//            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
//            TableColumn column = null;
//            for (int d = 0; d < record22.length; d++) {
//                column = jTable1.getColumnModel().getColumn(d);
//                if (d==0||d == 1|| d == 4) {
//                    column.setPreferredWidth(150);
//                } else if ( d == 2|| d == 3) {
//                    column.setPreferredWidth(109);
//                }
//            }
//        }
//            catch(SQLException ex){
//               ex.printStackTrace();
//            }
    try{
        java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String strt = "SELECT COUNT(*) FROM NEWADMISSION WHERE CLASS='" + admclass + "'";
                rs=stmt.executeQuery(strt);
                rs.next();
                int count=rs.getInt(1);                
                admn=new String[count];
                count=0;
                strt = "SELECT ADMISSION_NO FROM NEWADMISSION WHERE CLASS='" + admclass + "'";
                rs=stmt.executeQuery(strt);
                while(rs.next()){
                   admn[count]=rs.getString(1);
                   count++;
                }
                con.close();
                stmt.close();
                rs.close();
    }
    catch(SQLException ex){
        ex.printStackTrace();
    }
    for(int t=0;t<admn.length;t++){
        try{   java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");                         
        stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String str2 = "SELECT PAY_MONTH,DA FROM STUDENT_FEE WHERE ADMISSION_NO='" + admn[t] + "' ORDER BY SL_NO ASC";
                rs = stmt.executeQuery(str2);
                rs.last();            
                String month1=rs.getString(1);
                String da=rs.getString(2);
                Calendar cal = Calendar.getInstance();        
                String curdate = String.format("%1$tm", cal);                
                String dateFormat;
                flag=true;
                if(month1.length()==7){
                 month1=month1.substring(4,7);
                 dateFormat = NewAdmPanel.dateFormat(month1);
                }
                else{
                    dateFormat = NewAdmPanel.dateFormat(month1);
                }
                String olddate=dateFormat;
                int totmonth=Integer.parseInt(DuesReport.monthSub(curdate,olddate));
                if(totmonth==0&&da.equals("0")){                    
                }
                else{
                    totalRows++;
                }                
        }
        catch(SQLException xe){
            flag=false;
            //xe.printStackTrace();
            //JOptionPane.showMessageDialog(rootPane, xe);
        }
        if(flag==false){           
        try{                            
                String str2 = "SELECT FEE_DETAILS,ADMISSION_DATE FROM NEWADMISSION WHERE ADMISSION_NO='" + admn[t] + "'";
                rs = stmt.executeQuery(str2);
                rs.first();                
                String feedet=rs.getString(1);
                String date=String.valueOf(rs.getDate(2));//"2016-07-30"
                String olddate=date.substring(5, 7);
                Calendar cal = Calendar.getInstance();        
                String curdate = String.format("%1$tm", cal);                                
                int totmonth=Integer.parseInt(DuesReport.monthSub(curdate,olddate));                
                if(totmonth==0&&feedet.equals("Paid")){
                }
                else{
                    totalRows++;                    
                }
        }
        catch(SQLException xe){            
            //JOptionPane.showMessageDialog(rootPane, xe);
        }
        }
        }
    rows = new Object[totalRows][record23.length];    
    int k=0;
    for(int t=0;t<admn.length;t++){
        int grandtotal;        
        try{
            //"ADMISSION_NO","STUDENT_NAME", "CLASS", "ROLL","LAST_PAYMENT_MONTH", "LAST_PAID_AMOUNT","TUTION_FEE","TRANSPORT_FEE","EXAMINATION_FEE","SCHOOL_DEVELOPMENT_FEE","PREVIOUS_DUES","TOTAL_PAYABLE_AMOUNT"
                //stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String str2 = "SELECT ADMISSION_NO,STD_NAME,CLASS,ROLL_NO,PAY_DATE,PAY_MONTH,DA,CASH_AMOUNT,CHEK_AMT FROM STUDENT_FEE WHERE ADMISSION_NO='" + admn[t] + "' ORDER BY SL_NO ASC";
                rs = stmt.executeQuery(str2);
                rs.last();                
                String month1=rs.getString(6);
                Calendar cal = Calendar.getInstance();
                String curdate = String.format("%1$tm", cal);
                String dateFormat;
                flag=true;
                if(month1.length()==7){
                 month1=month1.substring(4,7);
                 dateFormat = NewAdmPanel.dateFormat(month1);
                }
                else{
                    dateFormat = NewAdmPanel.dateFormat(month1);
                }
                String olddate=dateFormat;
                int totmonth=Integer.parseInt(DuesReport.monthSub(curdate,olddate));
                String da=rs.getString(7);
                int j=k;
                if(totmonth==0&&da.equals("0")){}
                else{
                    if(j<totalRows){
                admno=rs.getString(1);
                rows[j][0]=admno;
                String stdname=rs.getString(2);
                rows[j][1]=stdname;
                String class1=rs.getString(3);
                rows[j][2]=class1;
                String rollno=rs.getString(4);
                rows[j][3]=rollno;
                String date=String.valueOf(rs.getDate(5));//2016
                String d1=date.substring(2, 4);
                rows[j][4]=month1+"-"+d1;
                int cashamt=Integer.parseInt(rs.getString(8));
                int chkamt=Integer.parseInt(rs.getString(9));
                int prevtotal=cashamt+chkamt;
                rows[j][5]=prevtotal;
                String str = "SELECT TUT_FEE,EXAM_FEE,SCHOOLDEV_FEE,SPORTS_FEE FROM FEE_DETAILS WHERE CLASS='" + class1 + "'";
                rs = stmt.executeQuery(str);
                rs.first();
                String tutfee=rs.getString(1);
                int tutamt=Integer.parseInt(tutfee.substring(0, tutfee.lastIndexOf("/")))*totmonth;
                rows[j][6]=tutamt;
                String examfee=rs.getString(2);//500/Jun
                String examamt=examfee.substring(0, examfee.lastIndexOf("/"));
                int exam;
                int schdev;
                String schdevfee=rs.getString(3);
                String schdevamt=schdevfee.substring(0, schdevfee.lastIndexOf("/"));
                
                if(examfee.substring(examfee.lastIndexOf("/")+1, examfee.length()).equals("Select")){
                    exam=0;
                }
                else{
                    exam=Integer.parseInt(NewAdmPanel.dateFormat(examfee.substring(examfee.lastIndexOf("/")+1, examfee.length())));
                }
                if(schdevfee.substring(schdevfee.lastIndexOf("/")+1, schdevfee.length()).equals("Select")){
                    schdev=0;
                }
                else{
                    schdev=Integer.parseInt(NewAdmPanel.dateFormat(schdevfee.substring(schdevfee.lastIndexOf("/")+1, schdevfee.length())));
                }
//                String sportfee=rs.getString(4);
//                String sportamt=sportfee.substring(0, sportfee.lastIndexOf("/"));
//                int sport=Integer.parseInt(NewAdmPanel.dateFormat(sportfee.substring(sportfee.lastIndexOf("/")+1, sportfee.length())));
                int oldmonth=Integer.parseInt(olddate);
                int curmonth=Integer.parseInt(curdate);
                String str1 = "SELECT TRANS_FEE FROM NEWADMISSION WHERE ADMISSION_NO='" + admn[t] + "'";
                rs = stmt.executeQuery(str1);
                rs.first();
                int transfee=Integer.parseInt(rs.getString(1))*totmonth;
                rows[j][7]=transfee;   
                rows[j][10]=da;               
                grandtotal=tutamt+transfee+Integer.parseInt(da);
                if(curmonth<oldmonth){
                    curmonth+=12;
                }
                for(int i=oldmonth+1;i<=curmonth;i++){
                    if(i==exam){
                       rows[j][8]=examamt;
                       grandtotal+=Integer.parseInt(examamt);
                    }                    
                    if(i==schdev){
                        rows[j][9]=schdevamt;
                        grandtotal+=Integer.parseInt(schdevamt);
                    }                                       
//                    if(i==sport){
//                        lblsportfee.setText(sportamt);
//                        grandtotal+=Integer.parseInt(sportamt);
//                    }
                }
                rows[j][11]=grandtotal;
                k++;
                }
                }
        }
        catch(SQLException xe){
            flag=false;
            //JOptionPane.showMessageDialog(rootPane, xe);
        }
        if(flag==false){
            int grandtotal1;
            boolean dues;
        try{
            
                //stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
                String str2 = "SELECT ADMISSION_NO,STUDENT_NAME,CLASS,ROLL_NO,FEE_DETAILS,ADMISSION_DATE,TOTAL_ADM_FEE,TRANS_FEE FROM NEWADMISSION WHERE ADMISSION_NO='" + admn[t] + "'";
                rs = stmt.executeQuery(str2);
                rs.first();                
                String feedet=rs.getString(5);
                String date=String.valueOf(rs.getDate(6));//"2016-07-30"
                String olddate=date.substring(5, 7);
                Calendar cal = Calendar.getInstance();        
                String curdate = String.format("%1$tm", cal);                                             
                int totmonth=Integer.parseInt(DuesReport.monthSub(curdate,olddate));
                int j=k;                
                if(totmonth==0&&feedet.equals("Paid")){                                                          
                }
                else{   
                    if(j<totalRows){
                admno=rs.getString(1);
                rows[j][0]=admno;
                String stdname=rs.getString(2);
                rows[j][1]=stdname;
                String class1=rs.getString(3);
                rows[j][2]=class1;
                String rollno=rs.getString(4);
                rows[j][3]=rollno;                
                String d1=date.substring(2, 4);
                String month1=NewAdmPanel.date(date.substring(5, 7));
                rows[j][4]=month1+"-"+d1;
                String totadmfee=rs.getString(7);
                if(feedet.equals("Paid")){
                    rows[j][5]=totadmfee;
                    dues=false;
                }
                else{
                    rows[j][5]=0;
                    dues=true;
                }
                //"ADMISSION_NO","STUDENT_NAME", "CLASS", "ROLL","LAST_PAYMENT_MONTH", "LAST_PAID_AMOUNT","TUTION_FEE","TRANSPORT_FEE","EXAMINATION_FEE","SCHOOL_DEVELOPMENT_FEE","PREVIOUS_DUES","TOTAL_PAYABLE_AMOUNT"
                String transf=rs.getString(8);                                
                String str = "SELECT TUT_FEE,EXAM_FEE,SCHOOLDEV_FEE,SPORTS_FEE FROM FEE_DETAILS WHERE CLASS='" + class1 + "'";
                rs = stmt.executeQuery(str);
                rs.first();
                String tutfee=rs.getString(1);
                int tutamt=Integer.parseInt(tutfee.substring(0, tutfee.lastIndexOf("/")))*totmonth;
                rows[j][6]=tutfee;
                String examfee=rs.getString(2);//500/Jun
                String examamt=examfee.substring(0, examfee.lastIndexOf("/"));                
                int exam;
                int schdev;
                String schdevfee=rs.getString(3);
                String schdevamt=schdevfee.substring(0, schdevfee.lastIndexOf("/"));
                
                if(examfee.substring(examfee.lastIndexOf("/")+1, examfee.length()).equals("Select")){
                    exam=0;
                }
                else{
                    exam=Integer.parseInt(NewAdmPanel.dateFormat(examfee.substring(examfee.lastIndexOf("/")+1, examfee.length())));
                }
                if(schdevfee.substring(schdevfee.lastIndexOf("/")+1, schdevfee.length()).equals("Select")){
                    schdev=0;
                }
                else{
                    schdev=Integer.parseInt(NewAdmPanel.dateFormat(schdevfee.substring(schdevfee.lastIndexOf("/")+1, schdevfee.length())));
                }
                //String sportfee=rs.getString(4);
                //String sportamt=sportfee.substring(0, sportfee.lastIndexOf("/"));
                //int sport=Integer.parseInt(dateFormat(sportfee.substring(sportfee.lastIndexOf("/")+1, sportfee.length())));
                int oldmonth=Integer.parseInt(olddate);
                int curmonth=Integer.parseInt(curdate);                
                int transfee=Integer.parseInt(transf)*totmonth;
                rows[j][7]=transfee;
                if(dues==false){
                    grandtotal1=tutamt+transfee;
                }
                else{
                grandtotal1=tutamt+transfee+Integer.parseInt(totadmfee);
                }
                if(curmonth<oldmonth){
                    curmonth+=12;
                }
                for(int i=oldmonth+1;i<=curmonth;i++){
                    if(i==exam){
                       rows[j][8]=examamt;
                       grandtotal1+=Integer.parseInt(examamt);
                    }                    
                    if(i==schdev){
                        rows[j][9]=schdevamt;
                        grandtotal1+=Integer.parseInt(schdevamt);
                    }                    
//                    if(i==sport){
//                        lblsportfee.setText(sportamt);
//                        grandtotal1+=Integer.parseInt(sportamt);
//                    }
                }
                if(dues==true){
                    rows[j][10]=totadmfee;
                }                
                rows[j][11]=grandtotal1;
                k++;
                }
                }
        }
        catch(SQLException xe){ 
            flag = false;
            //JOptionPane.showMessageDialog(rootPane, xe);
        }
        }
        }
    jTable1 = new JTable(rows, record23);
            if (admno.equals("")) {
                flag = false;
            } else {
                flag = true;
            }         
            jTable1.setRowHeight(30);
            jTable1.setFont(new Font("Times New Roman", Font.BOLD, 20));
            jTable1.setShowVerticalLines(true);
            jTable1.setShowHorizontalLines(true);
            jTable1.setShowGrid(true);
            jTable1.setGridColor(Color.BLACK);
            jTable1.setForeground(Color.BLACK.brighter());
            jTable1.setEnabled(false);
            jTable1.setSelectionBackground(Color.black);
            jTable1.setBackground(Color.WHITE);
            jTable1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            TableColumn column = null;
            for (int i = 0; i < record23.length; i++) {
                column = jTable1.getColumnModel().getColumn(i);
                if (i==4||i == 10 || i == 7 || i == 5 || i == 8|| i == 6||i==11) {
                    column.setPreferredWidth(150);
                }
                else if(i==2||i==3){
                    column.setPreferredWidth(100);
                }
                else if(i==9){
                    column.setPreferredWidth(175);
                }
                 else {
                    column.setPreferredWidth(250);
                }
            }
            totalRows = 0;
            admno="";
        }
    }
