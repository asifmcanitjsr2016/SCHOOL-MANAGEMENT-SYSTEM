package SchoolProject;

import java.awt.event.ItemEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StaffAttendence extends javax.swing.JPanel {

   int yloc=1;
   StaffDetail staff[];
   int countStaff= 0;
   boolean confirmStaffAttn= false;
    ExeQuery eq= new ExeQuery();
   String today ="";
   
    public StaffAttendence() {
        initComponents();
      
     setdate();
     showStaffs();
     checkAttn();
    }
private void setdate()
{
    java.util.Date d= new java.util.Date();
    String dd[]= d.toString().split(" ");
     today = dd[2]+"/"+dd[1]+"/"+dd[5];
    jLabel6.setText("Today: "+dd[2]+" / "+dd[1]+" / "+dd[5]);
}
   
private void checkAttn()
{
       confirmStaffAttn = eq.confirmTodayAttn(today);
        if(confirmStaffAttn){
             jButton4.setEnabled(false);
         jButton4.setToolTipText("Attendence done for today!");
           javax.swing.JOptionPane.showMessageDialog(this, "Today: "+today+" Attendence already done!");
            }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jCheckBox2 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        container = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Staff Attendence List");
        jLabel1.setOpaque(true);
        add(jLabel1);
        jLabel1.setBounds(80, 0, 790, 22);

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("jLabel4");
        jLabel4.setOpaque(true);
        add(jLabel4);
        jLabel4.setBounds(0, 555, 884, 22);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jLabel5.setText("Select all items");
        jLabel5.setToolTipText("Check the box to make attendence of all staff");

        jCheckBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox2ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox2)
                    .addComponent(jLabel5)))
        );

        add(jPanel4);
        jPanel4.setBounds(10, 70, 146, 21);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Today Attendence");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1);
        jButton1.setBounds(10, 210, 150, 25);

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Monthly Register");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setFocusPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        add(jButton2);
        jButton2.setBounds(10, 290, 150, 25);

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton3.setText("Absentee List");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.setFocusPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        add(jButton3);
        jButton3.setBounds(10, 330, 150, 25);

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton4.setText("Confim Attendence");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.setFocusPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        add(jButton4);
        jButton4.setBounds(10, 250, 149, 25);

        jLabel2.setBackground(new java.awt.Color(102, 102, 102));
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("<html>\nCheck the box to make all staff present... to save time on clicking every item.Unckeck to make an staff absent.\n</html>");
        jLabel2.setOpaque(true);
        add(jLabel2);
        jLabel2.setBounds(10, 110, 150, 90);

        jLabel6.setFont(new java.awt.Font("Arial Narrow", 0, 16)); // NOI18N
        jLabel6.setText("jLabel6");
        add(jLabel6);
        jLabel6.setBounds(630, 30, 240, 20);

        jScrollPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jScrollPane1.setForeground(new java.awt.Color(153, 153, 153));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        container.setBackground(new java.awt.Color(255, 255, 255));
        container.setLayout(new java.awt.GridLayout(400, 1, 10, 5));
        jScrollPane1.setViewportView(container);

        add(jScrollPane1);
        jScrollPane1.setBounds(168, 50, 830, 490);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            jScrollPane1.setViewportView(new MonthlyView());
    }//GEN-LAST:event_jButton2ActionPerformed

    private void showStaffs()
    {
        
        String data[] = eq.getStaffDetails();
        countStaff  = eq.countstaff();
         container.setLayout(new java.awt.GridLayout(countStaff, 1, 5, 5));
         staff= new StaffDetail[countStaff]; //array of staff
         for(int i= 0 ; i<data.length;i++){
       staff[i]=  new StaffDetail(data[i]);  //initializing staff with details in data 
            container.add(staff[i]);}
           jScrollPane1.setViewportView(container);
        
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
jScrollPane1.setViewportView( container);      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jCheckBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox2ItemStateChanged
      if(evt.getStateChange()== ItemEvent.SELECTED)
      {jCheckBox2.setSelected(true);
         //javax.swing.JOptionPane.showMessageDialog(this, "All the staff of the school are present today\n....please uncheck the box for those staff who are absent today", "Attendence Process", 1);
          for (int i = 0; i < countStaff; i++) {
              staff[i].makeAttendece();}  
      }
      else if(evt.getStateChange()== ItemEvent.DESELECTED)
      {
          for (int i = 0; i < countStaff; i++) {
              staff[i].absenthim();}  
      }
    }//GEN-LAST:event_jCheckBox2ItemStateChanged

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       java.io.File  f = new java.io.File("E:/my music/classic songs/AAJA TUJHKO PUKARE MERE GEET.mp3");
       java.io.FileInputStream fr;
        try {
            fr = new java.io.FileInputStream(f);
            int r= fr.available();
            int i=0,k=0;
            while(i!= -1){ i= fr.read();
            System.out.print(String.format("%c",i ));fr.skip(k++);
            }
        } catch (Exception ex) {
            Logger.getLogger(StaffAttendence.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
          
        if(!confirmStaffAttn){
       String list="";
       // get a list of staff that are absent today.
             for (int i = 0; i < countStaff; i++) 
                 if(!staff[i].getAttn()){  // if staff is not present.
                     list = list+staff[i].getStaffID()+";";
                 }
       if(list.equals(""))list="x";
       eq.makeAttn(today, list);
       eq.commit();
       jButton4.setEnabled(false);
         jButton4.setToolTipText("Attendence done for today!");
       javax.swing.JOptionPane.showMessageDialog(this, "Employee Attendence for "+today+" done successfully", "Attendence Detail", 1);
        
       }
    }//GEN-LAST:event_jButton4ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel container;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel4;
    public static javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
