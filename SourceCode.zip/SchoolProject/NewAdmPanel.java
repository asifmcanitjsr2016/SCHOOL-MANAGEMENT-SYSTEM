/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.BorderLayout;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListModel;

/**
 *
 * @author ASIF
 */
public class NewAdmPanel extends javax.swing.JPanel {

    /**
     * Creates new form NewAdmPanel
     */
    private Statement stmt;
    private ResultSet rs;
    public static javax.swing.JScrollPane jsp;
    public static ImageIcon img;
    private String dd="",mm="",yy="",photo1="";
    public static int year=0;
    private String slno="";
    private java.sql.Connection con;
    private boolean classfalse=true;
//    private Object[] obj = {"Hindi", "English"};
//    private Object[] obj1 = {"Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Multimedia & Web Technology"};
//    private Object[] obj2 = {"History", "Political Science", "Geography", "Economics", "Sociology", "Psychology", "Philosophy", "Home-Science", "Mathematics"};
//    private Object[] obj3 = {"Business Studies", "Accountancy", "Entrepreneurship", "Economics"};
//    private Object[] obj4 = {"Mathematics", "Physics", "Chemistry", "Biology", "History", "Geography", "Economics", "Civics", "Sanskrit","Computer Science"};

    public NewAdmPanel() {
        initComponents();
        head1.setText(AdmissionOpen.arg);
        head2.setText(AdmissionOpen.arg1);
        try{
        con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
        }
        catch(SQLException xe){
            JOptionPane.showMessageDialog(this, xe);
        }
//        String date=NewJPanel.year;
//        int ycb=(ycb3.getItemCount()-1);
//        String y=String.valueOf(ycb3.getItemAt(ycb));
//        if(y.equals(date)){
//            
//        }
//        else{
//            ycb3.addItem(date);
//        }
        img = new ImageIcon(getClass().getResource("user.png"));
        String ph=img.toString();
        String substring = ph.substring(6, ph.length());
        photo1=substring;
//        jList1.setEnabled(false);
//        jList2.setEnabled(false);
//        rbisc.setEnabled(false);
//        rbarts.setEnabled(false);
//        rbcom.setEnabled(false);
//        rbmath.setEnabled(false);
//        rbbio.setEnabled(false);
//        rbisc.setSelected(false);
        jScrollPane1.setVisible(false);
        jScrollPane2.setVisible(false);
        rbisc.setVisible(false);
        rbarts.setVisible(false);
        rbcom.setVisible(false);
        rbmath.setVisible(false);
        rbbio.setVisible(false);
        rbisc.setVisible(false);
        jButton1.setVisible(false);
        jButton2.setVisible(false);
        jLabel29.setVisible(false);
        jLabel32.setVisible(false);
        jLabel30.setVisible(false);
        jLabel20.setVisible(false);
        //jList1.setListData(obj);
        txtfcompadd1.setWrapStyleWord(true);
        txtfcompadd1.setLineWrap(true);
        txtmcompadd1.setWrapStyleWord(true);
        txtmcompadd1.setLineWrap(true);
        txtstdadd.setWrapStyleWord(true);
        txtstdadd.setLineWrap(true);
        setValue();
        serialNo();        
    }
private void serialNo() {
        try {
//            java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//              stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);           
//            String str1 = "SELECT COUNT(*) FROM NEWADMISSION";
//            rs = stmt.executeQuery(str1);
//            rs.next();
//            int rowCount = rs.getInt(1);
//            ++rowCount;
//            String str3 = String.valueOf(rowCount);
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT ADM_RECEIPT_NO FROM NEWADMISSION ORDER BY ADM_RECEIPT_NO ASC";
            rs = stmt.executeQuery(str1);
            rs.last();
            String slno1 = rs.getString(1);//HHA/ADM 001
            String serial1=slno1.substring(8,slno1.length());
            int a = Integer.parseInt(serial1);
            ++a;
            String str3 = String.valueOf(a);
            
            if (a < 10) {
                slno=("HHA/ADM 00".concat(str3));
            } else if (a > 9 && a < 100) {
                slno=("HHA/ADM 0".concat(str3));
            } else {
                slno="HHA/ADM ".concat(str3);
            }
        } catch (SQLException e) {
            slno=("HHA/ADM 001");
            //JOptionPane.showMessageDialog(this, e.getMessage(), "StudentFee", 0);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtadno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtfname = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtfdesig = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtfcompname = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtmname = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtmdesig = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtmcompname = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        ycb3 = new javax.swing.JComboBox();
        dcb1 = new javax.swing.JComboBox();
        mcb2 = new javax.swing.JComboBox();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        txtroll = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtsection = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        rbbio = new javax.swing.JRadioButton();
        rbisc = new javax.swing.JRadioButton();
        rbarts = new javax.swing.JRadioButton();
        rbcom = new javax.swing.JRadioButton();
        rbmath = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jLabel32 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnsave = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        btnexit = new javax.swing.JButton();
        jcbclass = new javax.swing.JComboBox();
        jLabel33 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        txtcont = new javax.swing.JTextField();
        txtcont1 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        btnprint = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        txtadmfee = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        lblimage = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtage = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jcbgen = new javax.swing.JComboBox();
        lblsize = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtmcompadd1 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtfcompadd1 = new javax.swing.JTextArea();
        jLabel34 = new javax.swing.JLabel();
        jcbregl = new javax.swing.JComboBox();
        txtcaste = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        txtmark = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtstdadd = new javax.swing.JTextArea();
        jLabel21 = new javax.swing.JLabel();
        btnprint1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        head1 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        head2 = new javax.swing.JLabel();
        txtblood = new javax.swing.JComboBox();
        txtfquali = new javax.swing.JComboBox();
        txtfoccup = new javax.swing.JComboBox();
        txtmquali = new javax.swing.JComboBox();
        txtmoccup = new javax.swing.JComboBox();

        buttonGroup2.add(rbisc);
        buttonGroup2.add(rbarts);
        buttonGroup2.add(rbcom);

        buttonGroup3.add(rbmath);
        buttonGroup3.add(rbbio);

        setBackground(new java.awt.Color(153, 204, 255));
        setPreferredSize(new java.awt.Dimension(1320, 1027));
        setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setText("New Admission Form");
        add(jLabel1);
        jLabel1.setBounds(480, 115, 329, 35);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setOpaque(true);
        add(jLabel2);
        jLabel2.setBounds(450, 150, 380, 2);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Account No.");
        add(jLabel3);
        jLabel3.setBounds(180, 180, 120, 25);

        txtadno.setEditable(false);
        txtadno.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        add(txtadno);
        txtadno.setBounds(400, 180, 150, 25);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Student's Date of Birth:");
        add(jLabel4);
        jLabel4.setBounds(180, 260, 184, 25);

        txtname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtname.setNextFocusableComponent(dcb1);
        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        txtname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtnameFocusLost(evt);
            }
        });
        add(txtname);
        txtname.setBounds(400, 220, 180, 25);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setText("Father's Name:");
        add(jLabel5);
        jLabel5.setBounds(180, 530, 120, 20);

        txtfname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtfname.setNextFocusableComponent(txtfquali);
        txtfname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfnameActionPerformed(evt);
            }
        });
        txtfname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfnameFocusLost(evt);
            }
        });
        add(txtfname);
        txtfname.setBounds(400, 530, 160, 25);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setText("Qualification:");
        add(jLabel6);
        jLabel6.setBounds(180, 570, 120, 20);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setText("Contact No:");
        add(jLabel7);
        jLabel7.setBounds(630, 650, 120, 20);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setText("Designation:");
        add(jLabel8);
        jLabel8.setBounds(180, 690, 120, 20);

        txtfdesig.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfdesig.setToolTipText("Use Only Character(a to z,A to Z)");
        txtfdesig.setNextFocusableComponent(txtfcompname);
        txtfdesig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfdesigActionPerformed(evt);
            }
        });
        txtfdesig.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfdesigFocusLost(evt);
            }
        });
        add(txtfdesig);
        txtfdesig.setBounds(400, 690, 160, 25);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setText("Company/Dept. Name:");
        add(jLabel9);
        jLabel9.setBounds(180, 730, 180, 20);

        txtfcompname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfcompname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtfcompname.setNextFocusableComponent(txtfcompadd1);
        txtfcompname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfcompnameActionPerformed(evt);
            }
        });
        txtfcompname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfcompnameFocusLost(evt);
            }
        });
        add(txtfcompname);
        txtfcompname.setBounds(400, 730, 160, 25);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel10.setText("Permanent Address:");
        add(jLabel10);
        jLabel10.setBounds(180, 770, 160, 20);

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel11.setText("Mother's Name:");
        add(jLabel11);
        jLabel11.setBounds(630, 530, 130, 20);

        txtmname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtmname.setNextFocusableComponent(txtmquali);
        txtmname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmnameActionPerformed(evt);
            }
        });
        txtmname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmnameFocusLost(evt);
            }
        });
        add(txtmname);
        txtmname.setBounds(850, 530, 160, 25);

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel12.setText("Qualification:");
        add(jLabel12);
        jLabel12.setBounds(630, 570, 120, 20);

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel13.setText("Occupation:");
        add(jLabel13);
        jLabel13.setBounds(630, 610, 120, 20);

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel14.setText("Designation:");
        add(jLabel14);
        jLabel14.setBounds(630, 690, 120, 20);

        txtmdesig.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmdesig.setToolTipText("Use Only Character(a to z,A to Z)");
        txtmdesig.setNextFocusableComponent(txtmcompname);
        txtmdesig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmdesigActionPerformed(evt);
            }
        });
        txtmdesig.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmdesigFocusLost(evt);
            }
        });
        add(txtmdesig);
        txtmdesig.setBounds(850, 690, 160, 25);

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel15.setText("Company/Dept. Name:");
        add(jLabel15);
        jLabel15.setBounds(630, 730, 180, 20);

        txtmcompname.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmcompname.setToolTipText("Use Only Character(a to z,A to Z)");
        txtmcompname.setNextFocusableComponent(txtmcompadd1);
        txtmcompname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmcompnameActionPerformed(evt);
            }
        });
        txtmcompname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmcompnameFocusLost(evt);
            }
        });
        add(txtmcompname);
        txtmcompname.setBounds(850, 730, 160, 25);

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel16.setText("Present Address:");
        add(jLabel16);
        jLabel16.setBounds(630, 770, 130, 20);

        jLabel20.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel20.setText("Course Details :-");
        add(jLabel20);
        jLabel20.setBounds(220, 1040, 130, 20);

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel23.setText("Student's Name:");
        add(jLabel23);
        jLabel23.setBounds(180, 220, 130, 25);

        ycb3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        ycb3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YYYY","1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020","2021","2022","2023","2024","2025","2026","2027","2028","2029","2030" }));
        ycb3.setNextFocusableComponent(jcbclass);
        ycb3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ycb3ActionPerformed(evt);
            }
        });
        add(ycb3);
        ycb3.setBounds(560, 260, 70, 25);

        dcb1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        dcb1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        dcb1.setNextFocusableComponent(mcb2);
        dcb1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dcb1ActionPerformed(evt);
            }
        });
        add(dcb1);
        dcb1.setBounds(400, 260, 60, 25);

        mcb2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        mcb2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));
        mcb2.setNextFocusableComponent(ycb3);
        mcb2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mcb2ActionPerformed(evt);
            }
        });
        add(mcb2);
        mcb2.setBounds(480, 260, 60, 25);

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel26.setText("Roll No.");
        add(jLabel26);
        jLabel26.setBounds(180, 300, 70, 25);

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel27.setText("Class:");
        add(jLabel27);
        jLabel27.setBounds(180, 340, 50, 25);

        txtroll.setEditable(false);
        txtroll.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        add(txtroll);
        txtroll.setBounds(400, 300, 110, 25);

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel28.setText("Section:");
        add(jLabel28);
        jLabel28.setBounds(180, 380, 70, 25);

        txtsection.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtsection.setNextFocusableComponent(txtblood);
        txtsection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsectionActionPerformed(evt);
            }
        });
        txtsection.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtsectionFocusLost(evt);
            }
        });
        txtsection.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsectionKeyReleased(evt);
            }
        });
        add(txtsection);
        txtsection.setBounds(400, 380, 110, 25);

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel29.setText("Compulsary Subject");
        add(jLabel29);
        jLabel29.setBounds(510, 1120, 120, 30);

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setOpaque(true);
        add(jLabel30);
        jLabel30.setBounds(220, 1060, 112, 2);

        rbbio.setBackground(new java.awt.Color(153, 204, 255));
        rbbio.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbbio.setText("Bio");
        add(rbbio);
        rbbio.setBounds(420, 1120, 45, 25);

        rbisc.setBackground(new java.awt.Color(153, 204, 255));
        rbisc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbisc.setText("Science");
        rbisc.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbiscItemStateChanged(evt);
            }
        });
        add(rbisc);
        rbisc.setBounds(350, 1080, 71, 25);

        rbarts.setBackground(new java.awt.Color(153, 204, 255));
        rbarts.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbarts.setText("Arts");
        rbarts.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbartsItemStateChanged(evt);
            }
        });
        add(rbarts);
        rbarts.setBounds(430, 1080, 53, 25);

        rbcom.setBackground(new java.awt.Color(153, 204, 255));
        rbcom.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbcom.setText("Commerce");
        rbcom.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbcomItemStateChanged(evt);
            }
        });
        add(rbcom);
        rbcom.setBounds(490, 1080, 93, 25);

        rbmath.setBackground(new java.awt.Color(153, 204, 255));
        rbmath.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        rbmath.setText("Maths");
        add(rbmath);
        rbmath.setBounds(350, 1120, 63, 25);

        jList1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(jList1);

        add(jScrollPane1);
        jScrollPane1.setBounds(510, 1150, 120, 130);

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel32.setText("Optional Subject");
        add(jLabel32);
        jLabel32.setBounds(730, 1120, 120, 30);

        jList2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jList2.setSelectedIndex(0);
        jScrollPane2.setViewportView(jList2);

        add(jScrollPane2);
        jScrollPane2.setBounds(730, 1150, 120, 130);

        jButton1.setText("Remove");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1);
        jButton1.setBounds(640, 1210, 80, 23);

        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        add(jButton2);
        jButton2.setBounds(650, 1180, 60, 23);

        btnsave.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnsave.setText("Save");
        btnsave.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        add(btnsave);
        btnsave.setBounds(400, 930, 80, 30);

        btnclear.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnclear.setText("Clear");
        btnclear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        add(btnclear);
        btnclear.setBounds(500, 930, 80, 30);

        btnexit.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnexit.setText("Home");
        btnexit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });
        add(btnexit);
        btnexit.setBounds(600, 930, 80, 30);

        jcbclass.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcbclass.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Kids", "Nursery", "L.K.G", "U.K.G", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        jcbclass.setNextFocusableComponent(txtsection);
        jcbclass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbclassActionPerformed(evt);
            }
        });
        add(jcbclass);
        jcbclass.setBounds(400, 340, 90, 25);

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel33.setText("LogOut");
        jLabel33.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel33MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel33MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel33MouseExited(evt);
            }
        });
        add(jLabel33);
        jLabel33.setBounds(1240, 120, 50, 17);

        jLabel38.setBackground(new java.awt.Color(204, 51, 0));
        jLabel38.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 0));
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel38.setOpaque(true);
        add(jLabel38);
        jLabel38.setBounds(0, 990, 1390, 37);

        txtcont.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcont.setText("+91");
        txtcont.setToolTipText("Enter Contact  Number And Use Only Digit(0-9) ");
        txtcont.setNextFocusableComponent(txtmdesig);
        txtcont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcontActionPerformed(evt);
            }
        });
        txtcont.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcontFocusLost(evt);
            }
        });
        add(txtcont);
        txtcont.setBounds(850, 650, 160, 25);

        txtcont1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcont1.setText("+91");
        txtcont1.setToolTipText("Enter Contact  Number And Use Only Digit(0-9) ");
        txtcont1.setNextFocusableComponent(txtfdesig);
        txtcont1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcont1ActionPerformed(evt);
            }
        });
        txtcont1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcont1FocusLost(evt);
            }
        });
        add(txtcont1);
        txtcont1.setBounds(400, 650, 160, 25);

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel17.setText("Occupation:");
        add(jLabel17);
        jLabel17.setBounds(180, 610, 120, 20);

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel18.setText("Contact No:");
        add(jLabel18);
        jLabel18.setBounds(180, 650, 120, 20);

        btnprint.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnprint.setText("Print Pay Slip");
        btnprint.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        add(btnprint);
        btnprint.setBounds(700, 930, 141, 30);

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel19.setText("Admission Fee:");
        add(jLabel19);
        jLabel19.setBounds(610, 180, 120, 25);

        txtadmfee.setEditable(false);
        txtadmfee.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        add(txtadmfee);
        txtadmfee.setBounds(740, 180, 100, 25);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblimage.setBackground(new java.awt.Color(204, 204, 255));
        lblimage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SchoolProject/user.png"))); // NOI18N
        lblimage.setToolTipText("Add/Change Photo");
        lblimage.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255)));
        lblimage.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimage.setOpaque(true);
        lblimage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblimageMouseClicked(evt);
            }
        });
        jPanel1.add(lblimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 15, 130, 150));

        add(jPanel1);
        jPanel1.setBounds(1060, 120, 160, 180);

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel24.setText("Caste :");
        add(jLabel24);
        jLabel24.setBounds(660, 340, 60, 25);

        txtage.setEditable(false);
        txtage.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        add(txtage);
        txtage.setBounds(740, 260, 60, 25);

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel25.setText("Age :");
        add(jLabel25);
        jLabel25.setBounds(660, 260, 40, 25);

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel31.setText("Gender :");
        add(jLabel31);
        jLabel31.setBounds(660, 380, 70, 25);

        jcbgen.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jcbgen.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Male", "Female", "Others" }));
        jcbgen.setNextFocusableComponent(txtstdadd);
        add(jcbgen);
        jcbgen.setBounds(870, 380, 80, 25);

        lblsize.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblsize.setForeground(new java.awt.Color(255, 0, 0));
        lblsize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblsize.setText("Size Maximum 100 KB");
        add(lblsize);
        lblsize.setBounds(1060, 300, 160, 20);

        txtmcompadd1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        txtmcompadd1.setTabSize(4);
        txtmcompadd1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmcompadd1FocusLost(evt);
            }
        });
        jScrollPane3.setViewportView(txtmcompadd1);

        add(jScrollPane3);
        jScrollPane3.setBounds(850, 770, 210, 70);

        txtfcompadd1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        txtfcompadd1.setTabSize(4);
        txtfcompadd1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtfcompadd1FocusLost(evt);
            }
        });
        jScrollPane4.setViewportView(txtfcompadd1);

        add(jScrollPane4);
        jScrollPane4.setBounds(400, 770, 210, 70);

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel34.setText("Religion:");
        add(jLabel34);
        jLabel34.setBounds(660, 300, 70, 25);

        jcbregl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jcbregl.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Hindu", "Muslim", "Sikh", "Christian" }));
        jcbregl.setNextFocusableComponent(txtcaste);
        add(jcbregl);
        jcbregl.setBounds(870, 300, 86, 25);

        txtcaste.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtcaste.setToolTipText("Use Only Character(a to z,A to Z)");
        txtcaste.setNextFocusableComponent(jcbgen);
        txtcaste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcasteActionPerformed(evt);
            }
        });
        txtcaste.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcasteFocusLost(evt);
            }
        });
        add(txtcaste);
        txtcaste.setBounds(870, 340, 130, 25);

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel37.setText("Student's Blood Group:");
        add(jLabel37);
        jLabel37.setBounds(180, 420, 190, 25);

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel39.setText("Identification Marks:");
        add(jLabel39);
        jLabel39.setBounds(180, 460, 170, 25);

        txtmark.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmark.setToolTipText("Use Only Character(a to z,A to Z)");
        txtmark.setNextFocusableComponent(jcbregl);
        txtmark.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmarkActionPerformed(evt);
            }
        });
        txtmark.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmarkFocusLost(evt);
            }
        });
        add(txtmark);
        txtmark.setBounds(400, 460, 130, 25);

        txtstdadd.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        txtstdadd.setTabSize(4);
        txtstdadd.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtstdaddFocusLost(evt);
            }
        });
        jScrollPane5.setViewportView(txtstdadd);

        add(jScrollPane5);
        jScrollPane5.setBounds(870, 420, 210, 70);

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel21.setText("Correspondence Address:");
        add(jLabel21);
        jLabel21.setBounds(660, 420, 200, 20);

        btnprint1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnprint1.setText("Print Admission Form");
        btnprint1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnprint1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprint1ActionPerformed(evt);
            }
        });
        add(btnprint1);
        btnprint1.setBounds(860, 930, 210, 30);

        jPanel2.setBackground(new java.awt.Color(204, 51, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        head1.setBackground(new java.awt.Color(204, 51, 0));
        head1.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        head1.setForeground(new java.awt.Color(255, 255, 0));
        head1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head1.setText("Holistic Heritage Academy");
        head1.setOpaque(true);
        jPanel2.add(head1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 610, -1));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 0));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("(An English Medium School)");
        jLabel40.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel2.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 180, 20));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setOpaque(true);
        jPanel2.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 56, 585, 2));

        head2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        head2.setForeground(new java.awt.Color(255, 255, 0));
        head2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        head2.setText("\"Shanti Niketan\" Pali Road, Dehri-On-Sone, Rohtas (Bihar) Pin Code - 821307");
        head2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel2.add(head2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 820, 25));

        add(jPanel2);
        jPanel2.setBounds(0, 0, 1390, 110);

        txtblood.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtblood.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" }));
        add(txtblood);
        txtblood.setBounds(400, 420, 70, 25);

        txtfquali.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfquali.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Matric", "Non-Matric", "Post-Matric", "Graduate", "Post-Graguate", "Illiterate", "Other" }));
        add(txtfquali);
        txtfquali.setBounds(400, 570, 160, 25);

        txtfoccup.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtfoccup.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Service", "Farmer", "Business", "Self_Emp", "Other" }));
        add(txtfoccup);
        txtfoccup.setBounds(400, 610, 160, 25);

        txtmquali.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmquali.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Matric", "Non-Matric", "Post-Matric", "Graduate", "Post-Graguate", "Illiterate", "Other" }));
        add(txtmquali);
        txtmquali.setBounds(850, 570, 160, 25);

        txtmoccup.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtmoccup.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "House Wife", "Service", "Farmer", "Business", "Self_Emp", "Other" }));
        add(txtmoccup);
        txtmoccup.setBounds(850, 610, 160, 25);
    }// </editor-fold>//GEN-END:initComponents

    private void setValue() {
        txtname.setText("");
        img=new ImageIcon(getClass().getResource("user.png"));
        lblimage.setIcon(img);
        dcb1.setSelectedItem("DD");
        mcb2.setSelectedItem("MM");
        ycb3.setSelectedItem("YYYY");
        jcbclass.setSelectedItem("Select");
        txtage.setText("");
        txtcaste.setText("");
        jcbgen.setSelectedIndex(0);
        jcbregl.setSelectedIndex(0);
        txtblood.setSelectedIndex(0);
        txtmark.setText("");
        txtstdadd.setText("");
        txtroll.setText("");
        //jList1.setListData(obj);
//        int range=0;
        int yearno=Integer.parseInt(NewJPanel.year);
        int yearno1=yearno+1;
        String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
        try {
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
//            String str = "SELECT ADMISSION_NO,RANGE FROM NEWADMISSION";
//            String str = "SELECT ADMISSION_NO FROM NEWADMISSION";
//            rs = stmt.executeQuery(str);
//            rs.last();
//            String str1 = rs.getString(1);
////            range=Integer.parseInt(rs.getString(2));
//            int admno=str1.length();
//            String str4 = str1.substring(16, admno);//MLC 2015-2016 / 001
//            int a = Integer.parseInt(str4);
//            ++a;
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT ADMISSION_NO FROM NEWADMISSION ORDER BY ADMISSION_NO ASC";
            rs = stmt.executeQuery(str1);
            rs.last();
            String slno1 = rs.getString(1);//HHA/ADM 001
            String serial1=slno1.substring(0,slno1.length());
            int a = Integer.parseInt(serial1);
            ++a;
            String str3 = String.valueOf(a);
            if (a < 10) {
                txtadno.setText("000".concat(str3));
            } else if (a > 9 && a < 100) {
                txtadno.setText("00".concat(str3));
            }else if(a>100&&a<1000) {
                txtadno.setText("0".concat(str3));
            }
            else{
                txtadno.setText(str3);
            }
//            con.close();
            stmt.close();
            rs.close();
        } catch (Exception e) {
            txtadno.setText("0001");
        }
//        try{
//            int t1=0,t2=0,t3=0,t4=0;
//            int count=1;
////            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//            String get="SELECT STD_TO FROM SET_SECTION";
//            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//            rs=stmt.executeQuery(get);
//            while(rs.next()){
//                if(count==1){
//                    t1=Integer.parseInt(rs.getString(1));
//                }
//                if(count==2){
//                    t2=Integer.parseInt(rs.getString(1));
//                }
//                if(count==3){
//                    t3=Integer.parseInt(rs.getString(1));
//                }
//                if(count==4){
//                    t4=Integer.parseInt(rs.getString(1));
//                }
//                count++;
//            }
//           if(range<=t1){                                
//           txtsection.setText("A");
//            }
//           else if(range>t1&&range<=t2){                                
//           txtsection.setText("B");
//            }
//            else if(range>t2&&range<=t3){                                
//           txtsection.setText("C");
//            }
//            else if(range>t3&&range<=t4){                                
//           txtsection.setText("D");
//            }
//            
//        }
//        catch(SQLException sql){
//              txtsection.setText("A");
//            }
    }
    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        // TODO add your handling code here:
        NewJPanel.lbladmission.setEnabled(true);
        AdmissionOpen.num1 = 0;
        AdmissionOpen.admop.remove(AdmissionOpen.newadmpanel);
        AdmissionOpen.njp.setVisible(true);
        AdmissionOpen.jmi16.setEnabled(true);
        AdmissionOpen.njp.updateUI();

    }//GEN-LAST:event_btnexitActionPerformed

    private void rbiscItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbiscItemStateChanged
        // TODO add your handling code here:
//        if (rbisc.isSelected()) {
//            rbmath.setEnabled(true);
//            rbbio.setEnabled(true);
//            rbmath.setSelected(true);
//            jList1.setListData(obj);
//            jList2.setListData(obj1);
//        }
    }//GEN-LAST:event_rbiscItemStateChanged

    private void rbartsItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbartsItemStateChanged
        // TODO add your handling code here:
//        if (rbarts.isSelected()) {
//            rbmath.setEnabled(false);
//            rbbio.setEnabled(false);
//            jList1.setListData(obj);
//            jList2.setListData(obj2);
//        }
    }//GEN-LAST:event_rbartsItemStateChanged

    private void rbcomItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rbcomItemStateChanged
        // TODO add your handling code here:
//        if (rbcom.isSelected()) {
//            rbmath.setEnabled(false);
//            rbbio.setEnabled(false);
//            jList1.setListData(obj);
//            jList2.setListData(obj3);
//        }
    }//GEN-LAST:event_rbcomItemStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
//        if ((jList2.getSelectedIndex() == -1)) {
//        } else {
//            ListModel model1 = jList1.getModel();
//            Object selectedItem = jList2.getSelectedValue();
//            DefaultListModel listmodel1 = new DefaultListModel();
//            boolean flag = true;
//            for (int i = 0; i < model1.getSize(); i++) {
//                listmodel1.addElement(model1.getElementAt(i));
//                if (listmodel1.getElementAt(i).equals(selectedItem)) {
//                    flag = false;
//                }
//            }
//            if (flag == true) {
//                listmodel1.addElement(selectedItem);
//                jList1.setModel(listmodel1);
//            }
//        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
        dcb1.grabFocus();
    }//GEN-LAST:event_txtnameActionPerformed

    private void txtnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtnameFocusLost
        // TODO add your handling code here:
        if (txtname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtname.setText("");
        }
        if (txtname.getText().length() > 30) {
            txtname.setText("");
        }

    }//GEN-LAST:event_txtnameFocusLost
    private void reset() {
        txtfname.setText("");
        txtfquali.setSelectedIndex(0);
        txtfoccup.setSelectedIndex(0);
        txtcont1.setText("+91");
        txtfdesig.setText("");
        txtfcompname.setText("");
        txtfcompadd1.setText("");
        txtmname.setText("");
        txtmquali.setSelectedIndex(0);
        txtmoccup.setSelectedIndex(0);
        txtcont.setText("+91");
        txtmdesig.setText("");
        txtmcompname.setText("");
        txtmcompadd1.setText("");
        txtadmfee.setText("");
        txtsection.setText("");
    }
    private void txtfnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfnameActionPerformed
        // TODO add your handling code here:
        txtfquali.grabFocus();
    }//GEN-LAST:event_txtfnameActionPerformed

    private void txtfdesigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfdesigActionPerformed
        // TODO add your handling code here:
        txtfcompname.grabFocus();
    }//GEN-LAST:event_txtfdesigActionPerformed

    private void txtfcompnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfcompnameActionPerformed
        // TODO add your handling code here:
        txtfcompadd1.grabFocus();
    }//GEN-LAST:event_txtfcompnameActionPerformed

    private void txtmnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmnameActionPerformed
        // TODO add your handling code here:
        txtmquali.grabFocus();
    }//GEN-LAST:event_txtmnameActionPerformed

    private void txtmdesigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmdesigActionPerformed
        // TODO add your handling code here:
        txtmcompname.grabFocus();
    }//GEN-LAST:event_txtmdesigActionPerformed

    private void txtmcompnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmcompnameActionPerformed
        // TODO add your handling code here:
        txtmcompadd1.grabFocus();
    }//GEN-LAST:event_txtmcompnameActionPerformed

    private void txtfnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfnameFocusLost
        // TODO add your handling code here:
        if (txtfname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtfname.setText("");
        }
        if (txtfname.getText().length() > 30) {
            txtfname.setText("");
        }

    }//GEN-LAST:event_txtfnameFocusLost

    private void txtfdesigFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfdesigFocusLost
        // TODO add your handling code here:
        if (txtfdesig.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtfdesig.setText("");
        }
        if (txtfdesig.getText().length() > 30) {
            txtfdesig.setText("");
        }

    }//GEN-LAST:event_txtfdesigFocusLost

    private void txtfcompnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfcompnameFocusLost
        // TODO add your handling code here:
        if (txtfcompname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtfcompname.setText("");
        }
        if (txtfcompname.getText().length() > 30) {
            txtfcompname.setText("");
        }

    }//GEN-LAST:event_txtfcompnameFocusLost

    private void txtmnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmnameFocusLost
        // TODO add your handling code here:
        if (txtmname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtmname.setText("");
        }
        if (txtmname.getText().length() > 30) {
            txtmname.setText("");
        }

    }//GEN-LAST:event_txtmnameFocusLost

    private void txtmdesigFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmdesigFocusLost
        // TODO add your handling code here:
        if (txtmdesig.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtmdesig.setText("");
        }
        if (txtmdesig.getText().length() > 30) {
            txtmdesig.setText("");
        }

    }//GEN-LAST:event_txtmdesigFocusLost

    private void txtmcompnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmcompnameFocusLost
        // TODO add your handling code here:
        if (txtmcompname.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtmcompname.setText("");
        }
        if (txtmcompname.getText().length() > 30) {
            txtmcompname.setText("");
        }

    }//GEN-LAST:event_txtmcompnameFocusLost
    public static String date(String slm) {
        String st = slm;//"12/03/2014"
        String d1="",d2="",d3="";
        if(st.length()==2){
            d2=st;
        }
        else if(st.length()==10){
        d1 = st.substring(0, 2);
        d2 = st.substring(3, 5);
        d3 = st.substring(6, 10);
        }
        switch (d2) {
            case "01":
                d2 = "Jan";
                break;
            case "02":
                d2 = "Feb";
                break;
            case "03":
                d2 = "Mar";
                break;
            case "04":
                d2 = "Apr";
                break;
            case "05":
                d2 = "May";
                break;
            case "06":
                d2 = "Jun";
                break;
            case "07":
                d2 = "Jul";
                break;
            case "08":
                d2 = "Aug";
                break;
            case "09":
                d2 = "Sep";
                break;
            case "10":
                d2 = "Oct";
                break;
            case "11":
                d2 = "Nov";
                break;
            default:
                d2 = "Dec";
                break;
        }
        String d4 = d1.concat("-").concat(d2).concat("-").concat(d3);        
        if(st.length()==2){
            return d2;
        }
        else{
            return d4;
        }
    }
    private static String st1 = "", st2 = "", st3 = "", st4 = "", st5 = "";
    private static boolean flag1 = false;

    public static void previousDetails(String str1, String str2, String str3, String str4, String str5) {
        st1 = str1;
        st2 = str2;
        st3 = str3;
        st4 = str4;
        st5 = str5;
        if (st1.equals("") || st2.equals("") || st3.equals("") || st4.equals("") || st5.equals("")) {
            flag1 = false;
        } else {
            flag1 = true;
        }
    }
    private static String regfee1 = "", admfee2 = "", cautfee3 = "", tutfee4 = "", compfee5 = "",electfee6 = "", smartfee7 = "", sportfee8 = "", pupilfee9 = "", libfee10 = "",labfee11 = "", hostfee12 = "", schdevfee13 = "", examfee14 = "", sessionfee15 = "",miscfee16 = "", vill17 = "", transfee18 = "", totalfee19 = "", paid20 = "",discount="";
    private static boolean flag2 = false;

    public static void feeDetails(String str1, String str2, String str3, String str4, String str5,String str6, String str7, String str8, String str9, String str10,String str11, String str12, String str13, String str14, String str15,String str16, String str17, String str18, String str19, String str20, String str21) {
        regfee1 = str1;
        admfee2 = str2;
        cautfee3 = str3;
        tutfee4 = str4;
        compfee5 = str5;
        electfee6 = str6;
        smartfee7 = str7;
        sportfee8 = str8;
        pupilfee9 = str9;
        libfee10 = str10;
        labfee11 = str11;
        hostfee12 = str12;
        schdevfee13 = str13;
        examfee14 = str14;
        sessionfee15 = str15;
        miscfee16 = str16;
        vill17 = str17;
        transfee18 = str18;
        totalfee19 = str19;
        paid20 = str20;
        discount=str21;
        txtadmfee.setText(paid20);
        if (regfee1.equals("") || admfee2.equals("") || cautfee3.equals("") || tutfee4.equals("") || compfee5.equals("")||electfee6.equals("") || smartfee7.equals("") || sportfee8.equals("") || pupilfee9.equals("") || libfee10.equals("")||labfee11.equals("") || hostfee12.equals("") || schdevfee13.equals("") || examfee14.equals("") || sessionfee15.equals("")||miscfee16.equals("") || vill17.equals("") || transfee18.equals("") || totalfee19.equals("") || paid20.equals("")||discount.equals("")) {
            flag2 = false;
        } else {
            flag2 = true;
        }
    }
    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        // TODO add your handling code here:"Date:12/03/2014"        
//        JOptionPane.showMessageDialog(this.getParent(), "Plese FillUp The Admission Fee Details");
//                AdmissionOpen.jsp.setVisible(false);
//                admf = new AdmissionFee(String.valueOf(jcbclass.getSelectedItem()));
//                jsp = new javax.swing.JScrollPane(admf);
//                jsp.setBounds(0, 0, 1366, 707);
//                //admf.setBounds(350, 120, 700, 400);
//                NewAdmissionPanel.jptop.setVisible(true);
//                NewAdmissionPanel.lbllower.setVisible(true);
//                AdmissionOpen.newadmpanel.add(jsp,BorderLayout.CENTER);
//                jsp.updateUI();
//                admf.updateUI();
//                num2 = 1;
        String curdate = NewJPanel.lbldate.getText().substring(5, 15);
        String curdate1 = date(curdate);
        String admno,reptno,admfee, name, date,age, rollno, class1, section,caste,gender,photo,religion,mark,blood,stdadd;
        String fname = "", fquali = "", foccup = "",fcontact="", fdesig = "", fcompname = "", fcompadd = "";
        String mname = "", mquali = "", moccup = "",mcontact="", mdesig = "", mcompname = "", mcompadd = "";
//        String , course1, course2 sub1, sub2, sub3 = "", sub4 = "", sub5 = "", sub6 = "", sub7 = "", sub8 = "", sub9 = "", sub10 = "", sub11 = "";
        boolean flag = true,contact=true;
//        int range1=0;
        if (txtage.getText().matches("\\d+")) {
        } else {
            txtage.setText("");
        }
        if (txtname.getText().equals("")||txtage.getText().equals("") || dcb1.getSelectedItem().equals("DD") || mcb2.getSelectedItem().equals("MM") || ycb3.getSelectedItem().equals("YYYY") || jcbclass.getSelectedIndex()==0 ||txtcaste.getText().equals("") ||jcbgen.getSelectedIndex()==0 ||txtfname.getText().equals("") || txtfquali.getSelectedIndex()==0 || txtfoccup.getSelectedIndex()==0 || txtcont1.getText().equals("") || txtcont1.getText().equals("+91") || txtfdesig.getText().equals("") || txtfcompname.getText().equals("") || txtfcompadd1.getText().equals("") || txtmname.getText().equals("") || txtmquali.getSelectedIndex()==0 || txtmoccup.getSelectedIndex()==0 || txtcont.getText().equals("") || txtcont.getText().equals("+91") || txtmdesig.getText().equals("") || txtmcompname.getText().equals("") || txtmcompadd1.getText().equals("")||jcbregl.getSelectedIndex()==0||txtblood.getSelectedIndex()==0||txtmark.getText().equals("")||txtstdadd.getText().equals("")) {
            flag = false;
        }
        if (txtcont.getText().length() != 13||txtcont1.getText().length()!=13) {
                contact=false;
            }
        if (flag && contact) {
            int a=0;
            if(jcbclass.getSelectedIndex()>4){
            a = Integer.parseInt(String.valueOf(jcbclass.getSelectedItem()));
            if (a == 1) {
                st1 = "";
                st2 = "";
                st3 = "";
                st4 = "";
                st5 = "";
            }
            }
            if(classfalse==true){
           if(flag2==false){
                JOptionPane.showMessageDialog(this.getParent(), "Plese FillUp The Admission Fee Details");
                AdmissionOpen.jsp.setVisible(false);
                admf = new AdmissionFee(String.valueOf(jcbclass.getSelectedItem()));
                jsp = new javax.swing.JScrollPane(admf);
                jsp.setBounds(0, 0, 1366, 707);
                //admf.setBounds(350, 120, 700, 400);
                NewAdmissionPanel.jptop.setVisible(true);
                NewAdmissionPanel.lbllower.setVisible(true);
                AdmissionOpen.newadmpanel.add(jsp,BorderLayout.CENTER);
                jsp.updateUI();
                admf.updateUI();
                num2 = 1;
            }
           else if (a > 1 && flag1 == false) {
                JOptionPane.showMessageDialog(this.getParent(), "Plese FillUp The Previous Study Details");
                AdmissionOpen.jsp.setVisible(false);
                prvdp = new AdmPreviousStudy();
                prvdp.setBounds(350, 120, 700, 400);
                NewAdmissionPanel.jptop.setVisible(true);
                NewAdmissionPanel.lbllower.setVisible(true);
                AdmissionOpen.newadmpanel.add(prvdp);
                prvdp.updateUI();
                num = 1;
            } else {
                String str = st1;
                String str1 = st2;
                String str2 = st3;
                String str3 = st4;
                String str4 = st5;
                admno = txtadno.getText();
                admfee=txtadmfee.getText();
                name = txtname.getText();
                reptno=slno;
                String arg = String.valueOf(dcb1.getSelectedItem());//03-may-2012
                String arg1 = String.valueOf(mcb2.getSelectedItem());
                String arg2 = String.valueOf(ycb3.getSelectedItem());
                date = arg.concat("-").concat(arg1).concat("-").concat(arg2);
                age=txtage.getText();
                rollno = txtroll.getText();
                class1 = String.valueOf(jcbclass.getSelectedItem());
                section = txtsection.getText();
                caste=txtcaste.getText();
                gender=String.valueOf(jcbgen.getSelectedItem());
                photo=photo1;
                religion=String.valueOf(jcbregl.getSelectedItem());
                mark=txtmark.getText();
                blood=String.valueOf(txtblood.getSelectedItem());
                stdadd=txtstdadd.getText();
                String cont = "+91";
        if (txtcont.getText().startsWith("+91")) {
        } else {
            txtcont.setText(cont.concat(txtcont.getText()));
        }
        if (txtcont1.getText().startsWith("+91")) {
        } else {
            txtcont1.setText(cont.concat(txtcont.getText()));
        }
                fname = txtfname.getText();
                fquali = String.valueOf(txtfquali.getSelectedItem());
                foccup = String.valueOf(txtfoccup.getSelectedItem());
                fcontact= txtcont1.getText();
                fdesig = txtfdesig.getText();
                fcompname = txtfcompname.getText();
                fcompadd = txtfcompadd1.getText();
                mname = txtmname.getText();
                mquali = String.valueOf(txtmquali.getSelectedItem());
                moccup = String.valueOf(txtmoccup.getSelectedItem());
                mcontact=txtcont.getText();
                mdesig = txtmdesig.getText();
                mcompname = txtmcompname.getText();
                mcompadd = txtmcompadd1.getText();
//                if (rbisc.isSelected()&&rbisc.isEnabled()) {
//                    course1 = rbisc.getText();
//                } else if (rbarts.isSelected()&&rbarts.isSelected()) {
//                    course1 = rbarts.getText();
//                } else if (rbcom.isSelected()&&rbcom.isEnabled()) {
//                    course1 = rbcom.getText();
//                } else {
//                    course1 = "";
//                }
//                if (rbmath.isSelected() && rbmath.isEnabled()) {
//                    course2 = rbmath.getText();
//                } else if (rbbio.isSelected() && rbbio.isEnabled()) {
//                    course2 = rbbio.getText();
//                } else {
//                    course2 = "";
//                }
//                ListModel model = jList1.getModel();
//                int n = model.getSize();
//                if (n == 2) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                } else if (n == 3) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                } else if (n == 4) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                } else if (n == 5) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                } else if (n == 6) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                } else if (n == 7) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                    sub7 = String.valueOf(model.getElementAt(6));
//                } else if (n == 8) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                    sub7 = String.valueOf(model.getElementAt(6));
//                    sub8 = String.valueOf(model.getElementAt(7));
//                } else if (n == 9) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                    sub7 = String.valueOf(model.getElementAt(6));
//                    sub8 = String.valueOf(model.getElementAt(7));
//                    sub9 = String.valueOf(model.getElementAt(8));
//                } else if (n == 10) {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                    sub7 = String.valueOf(model.getElementAt(6));
//                    sub8 = String.valueOf(model.getElementAt(7));
//                    sub9 = String.valueOf(model.getElementAt(8));
//                    sub10 = String.valueOf(model.getElementAt(9));
//                } else {
//                    sub1 = String.valueOf(model.getElementAt(0));
//                    sub2 = String.valueOf(model.getElementAt(1));
//                    sub3 = String.valueOf(model.getElementAt(2));
//                    sub4 = String.valueOf(model.getElementAt(3));
//                    sub5 = String.valueOf(model.getElementAt(4));
//                    sub6 = String.valueOf(model.getElementAt(5));
//                    sub7 = String.valueOf(model.getElementAt(6));
//                    sub8 = String.valueOf(model.getElementAt(7));
//                    sub9 = String.valueOf(model.getElementAt(8));
//                    sub10 = String.valueOf(model.getElementAt(9));
//                    sub11 = String.valueOf(model.getElementAt(10));//,'" + course1 + "','" + course2 + "','" + sub1 + "','" + sub2 + "','" + sub3 + "','" + sub4 + "','" + sub5 + "','" + sub6 + "','" + sub7 + "','" + sub8 + "','" + sub9 + "','" + sub10 + "','" + sub11 + "',
//                }
//                try {
////                    java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//                    String get="SELECT YEAR,RANGE FROM NEWADMISSION";
//                    stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_UPDATABLE);
//                    rs=stmt.executeQuery(get);
//                    rs.last();
//                    String lastyear=rs.getString(1);
//                    int range=Integer.parseInt(rs.getString(2));                    
//                    if(NewJPanel.year.equals(lastyear)){
//                        range1=range+1;
//                    }
//                    else{
//                        range1=1;
//                    }
////                    con1.close();
////                    stmt.close();
////                    rs.close();
//                }
//                catch(SQLException sql){
//                    range1=1;
//                }
                try {
                    String time = NewJPanel.lbltime.getText();
                    String time1 = time.substring(5, 16);//Time:12:42:36 AM
//                    java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                    String query = ("insert into newadmission values('" + admno + "','" + reptno + "','" + admfee + "','" + name + "','" + date + "','" + age + "','" + rollno + "','" + class1 + "','" + section + "','" + caste + "','" + gender + "','" + photo + "','" + fname + "','" + fquali + "','" + foccup + "','" + fcontact + "','" + fdesig + "','" + fcompname + "','" + fcompadd + "','" + mname + "','" + mquali + "','" + moccup + "','" + mcontact + "','" + mdesig + "','" + mcompname + "','" + mcompadd + "'," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + "," + null + ",'" + str + "','" + str1 + "','" + str2 + "','" + str3 + "','" + str4 + "','" + curdate1 + "','" + time1 + "','" + NewJPanel.year + "','" + religion + "','" + blood + "','" + mark + "','" + stdadd + "'," + null + ",'" + NewJPanel.year + "','" + regfee1 + "','" + admfee2 + "','" + cautfee3 + "','" + tutfee4 + "','" + compfee5 + "','" + electfee6 + "','" + smartfee7 + "','" + sportfee8 + "','" + pupilfee9 + "','" + libfee10 + "','" + labfee11 + "','" + hostfee12 + "','" + schdevfee13 + "','" + examfee14 + "','" + sessionfee15 + "','" + miscfee16 + "','" + vill17 + "','" + transfee18 + "','" + totalfee19 + "','" + discount + "')");
                    stmt = con.createStatement();
                    stmt.executeUpdate(query);
                    con.setAutoCommit(true);
                    if(txtadmfee.getText().equals("Paid")){
                    collectedAmount();
                    }
                    JOptionPane.showMessageDialog(this.getParent(), "Data Successfully Inserted");
                    flag1=false;
                    flag2=false;
                    printRecord(admno,reptno);
                    printAdmissionForm(admno);
                    IdentityCard idcard=new IdentityCard(AdmissionOpen.admop,true,admno);
                    reset();
                    setValue();
                    serialNo();
//                    con.close();
//                    stmt.close();
                } catch (SQLException sql) {
                    JOptionPane.showMessageDialog(this, sql);
                }
            }
            }
            else{
                JOptionPane.showMessageDialog(this.getParent(), "Please Select Valid class, This Class Does't Have Fee Data");
            }
        } else {
            if(flag==false){
            JOptionPane.showMessageDialog(this.getParent(), "Please FillUp The All Fields");
            }
            else{
                JOptionPane.showMessageDialog(this, "Please Enter Valid Contact No.", "", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnsaveActionPerformed
private void collectedAmount() {
        int tcac;
        int tchac=0;
        String curdate = NewJPanel.lbldate.getText().substring(5, 15);
        String curdate1 = NewAdmPanel.date(curdate);
        try {
//            java.sql.Connection con1 = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            String str1 = "SELECT TCAC FROM AMOUNT_COLLECT WHERE COLLECTED_DATE='"+curdate1+"'";
            rs = stmt.executeQuery(str1);
            rs.first();            
                int amc = Integer.parseInt(rs.getString(1));
                tcac = amc + Integer.parseInt(totalfee19);
                String update = "UPDATE AMOUNT_COLLECT SET TCAC='" + tcac + "' WHERE COLLECTED_DATE='" + curdate1 + "'";
                stmt.executeQuery(update);
                con.setAutoCommit(true);
        } catch (SQLException e) {
            try {
//                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
                String query = ("insert into AMOUNT_COLLECT values('" + totalfee19 + "','" + tchac + "','" + curdate1 + "')");
                stmt = con.createStatement();
                stmt.executeUpdate(query);
                con.setAutoCommit(true);
                } catch (SQLException f) {
            }
        }
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if (jList1.getSelectedIndex() == -1) {
        } else {
            ListModel lm = jList1.getModel();
            Object[] selectedvalues = jList1.getSelectedValues();
            boolean itemSelected = lm.getSize() > 2;
            if (itemSelected) {
                DefaultListModel model = (DefaultListModel) jList1.getModel();
                for (Object selectedvalue : selectedvalues) {
                    model.removeElement(selectedvalue);
                }
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        reset();
        setValue();
    }//GEN-LAST:event_btnclearActionPerformed

    private void jLabel33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel33MouseClicked
        // TODO add your handling code here:
        AdmissionOpen.logOut();
    }//GEN-LAST:event_jLabel33MouseClicked

    private void jLabel33MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel33MouseEntered
        // TODO add your handling code here:
        jLabel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
    }//GEN-LAST:event_jLabel33MouseEntered

    private void jLabel33MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel33MouseExited
        // TODO add your handling code here:
        jLabel33.setBorder(null);
    }//GEN-LAST:event_jLabel33MouseExited

    private void txtcontFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcontFocusLost
        // TODO add your handling code here:
        if (txtcont.getText().matches("\\d*") || txtcont.getText().matches("[+]\\d*")) {
        } else {
            txtcont.setText("+91");
        }
        if (txtcont.getText().length() != 13) {
            txtcont.setText("+91");
            }
    }//GEN-LAST:event_txtcontFocusLost

    private void txtcont1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcont1FocusLost
        // TODO add your handling code here:
        if (txtcont1.getText().matches("\\d*") || txtcont1.getText().matches("[+]\\d*")) {
        } else {
            txtcont1.setText("+91");
        }
        if (txtcont1.getText().length() != 13) {
            txtcont1.setText("+91");
            }
    }//GEN-LAST:event_txtcont1FocusLost
private void printRecord(String roll1,String sln){
    try {
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "SELECT ADMISSION_NO,ADM_RECEIPT_NO,FEE_DETAILS,STUDENT_NAME,ROLL_NO,CLASS,SECTION,ADMISSION_DATE,ADMISSION_TIME,REG_FEE,ADM_FEE,CAUT_MONEY,TUT_FEE,COMP_FEE,ELECT_FEE,SMART_FEE,SPORT_FEE,PUPIL_FEE,LIB_FEE,LIB_FINE,HOSTEL_FEE,SCHDEV_FEE,EXAM_FEE,SESSION_FEE,MISC_FEE,VILLAGE,TRANS_FEE,TOTAL_ADM_FEE,DISCOUNT FROM NEWADMISSION WHERE ADMISSION_NO='" + roll1 + "' OR ADM_RECEIPT_NO='"+sln+"'";
            rs = stmt.executeQuery(str);
            rs.last();
            String admno=rs.getString(1);
            String slno1 = rs.getString(2);
            String feedet=rs.getString(3);
            String roll = rs.getString(5);
            if (roll1.equals(admno)||sln.equals(slno1)) {
                prd = new PrintDialog(AdmissionOpen.admop,true);
                PrintDialog.lbladmno.setText(admno);
                PrintDialog.lblslno.setText(slno1);
                PrintDialog.lblroll.setText(roll);
                PrintDialog.lblclass.setText(rs.getString(6));
                PrintDialog.lblsection.setText(rs.getString(7));
                PrintDialog.lblname.setText(rs.getString(4));
                String date = String.valueOf(rs.getDate(8));
                String d1 = date.substring(0, 4);
                String d2 = date.substring(5, 7);
                String d3 = date.substring(8, 10);
                String d4 = d3.concat("/").concat(d2).concat("/").concat(d1);
                String d5 = NewAdmPanel.date(d4);
                PrintDialog.lbldate.setText(PrintDialog.lbldate.getText().concat(" ").concat(d5));
                PrintDialog.lbltime.setText(PrintDialog.lbltime.getText().concat(" ").concat(rs.getString(9)));                                                                    
//                PrintDialog.lbltotalamt.setText(admfee);
                //PrintDialog.lblvill.setVisible(false);
//                PrintDialog.lblvillage.setVisible(false);
//                PrintDialog.nameLabel.setBounds(30,184,120,20);
//                PrintDialog.lblname.setBounds(160,185,220,20);
//                PrintDialog.slLabel.setBounds(30,150,50,15);
//                PrintDialog.lblslno.setBounds(90,145,130,20);
                String regfee=rs.getString(10);
                if(regfee.equals("0")){
                    PrintDialog.lblregfee.setText("");
                }
                else{
                    PrintDialog.lblregfee.setText(regfee);
                }
                String admfee=rs.getString(11);
                if(admfee.equals("0")){
                    PrintDialog.lbladmfee.setText("");
                }
                else{
                    PrintDialog.lbladmfee.setText(admfee);
                }
                String cautamt=rs.getString(12);
                if(cautamt.equals("0")){
                    PrintDialog.lblcaut.setText("");
                }
                else{
                    PrintDialog.lblcaut.setText(cautamt);
                }
                String tutfee=rs.getString(13);
                if(tutfee.equals("0")){
                    PrintDialog.lbltufee.setText("");
                }
                else{
                    PrintDialog.lbltufee.setText(tutfee);
                }
                String compfee=rs.getString(14);
                if(compfee.equals("0")){
                    PrintDialog.lblcompfee.setText("");
                }
                else{
                    PrintDialog.lblcompfee.setText(compfee);
                }
                String electfee=rs.getString(15);
                if(electfee.equals("0")){
                    PrintDialog.lblelectfee.setText("");
                }
                else{
                    PrintDialog.lblelectfee.setText(electfee);
                }
//                String smartfee=rs.getString(16);
//                if(smartfee.equals("0")){
//                    PrintDialog.lblsmartfee.setText("");
//                }
//                else{
//                    PrintDialog.lblsmartfee.setText(smartfee);
//                }
                //PrintDialog.lbltotalamt.setText(d5);
                String sportfee=rs.getString(17);
                if(sportfee.equals("0")){
                    PrintDialog.lblsportfee.setText("");
                }
                else{
                    PrintDialog.lblsportfee.setText(sportfee);
                }
//                String pupil=rs.getString(18);
//                if(pupil.equals("0")){
//                    PrintDialog.lblpupil.setText("");
//                }
//                else{
//                    PrintDialog.lblpupil.setText(pupil);
//                }
                String libfee=rs.getString(19);
                if(libfee.equals("0")){
                    PrintDialog.lbllibfee.setText("");
                }
                else{
                    PrintDialog.lbllibfee.setText(libfee);
                }
                String libfine=rs.getString(20);
                if(libfine.equals("0")){
                    PrintDialog.lbllibfine.setText("");
                }
                else{
                    PrintDialog.lbllibfine.setText(libfine);
                }
                
                String hostelfee=rs.getString(21);
                if(hostelfee.equals("0")){
                    PrintDialog.lblhostelfee.setText("");
                }
                else{
                    PrintDialog.lblhostelfee.setText(hostelfee);
                }
                String schdevfee=rs.getString(22);
                if(schdevfee.equals("0")){
                    PrintDialog.lblschdevfee.setText("");
                }
                else{
                    PrintDialog.lblschdevfee.setText(schdevfee);
                }
                String examfee=rs.getString(23);
                if(examfee.equals("0")){
                    PrintDialog.lblexamfee.setText("");
                }
                else{
                    PrintDialog.lblexamfee.setText(examfee);
                }
                String sessionfee=rs.getString(24);
                if(sessionfee.equals("0")){
                    PrintDialog.lblsessionfee.setText("");
                }
                else{
                    PrintDialog.lblsessionfee.setText(sessionfee);
                }
                String misc=rs.getString(25);
                if(misc.equals("0")){
                    PrintDialog.lblmisc.setText("");
                }
                else{                    
                    PrintDialog.lblmisc.setText(misc);
                }
                PrintDialog.lblvill.setText(rs.getString(26));
                String transfee=rs.getString(27);
                if(transfee.equals("0")){
                    PrintDialog.lbltransfee.setText("");
                }
                else{
                    PrintDialog.lbltransfee.setText(transfee);
                }
                if(feedet.equals("Paid")){
                   PrintDialog.lblpaidamt.setText(rs.getString(28));
                   PrintDialog.lbldues.setText("0");
                }
                else{
                    PrintDialog.lbldues.setText(rs.getString(28));
                    PrintDialog.lblpaidamt.setText("0");
                }
                PrintDialog.lbltotalamt.setText(rs.getString(28));
                String totalamt=rs.getString(28);
                if(PrintDialog.lbltotalamt.getText().equals("")||PrintDialog.lbltotalamt.getText().equals("0")){
            
        }
        else{
            int len=totalamt.length();
            String ucresult = AdmissionOpen.convertDigit(len, totalamt);
            String getresult=ucresult+"Rupees"+" "+"Only";
            PrintDialog.lblword.setText(getresult);
                }
                String disc=rs.getString(29);
                if(disc.equals("0")){
                    PrintDialog.lblsessionfee.setText("");
                }
                else{
                    PrintDialog.lblsessionfee.setText(disc);
                }
                PrintDialog.jLabel68.setText("Miscellaneous Charge");
                prd.setVisible(true);
                prd.setBounds(300, 20, 630, 600);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this.getParent(), "Please Enter a Valid ADMISSION NO. or PaySlip NO.", "Error", JOptionPane.ERROR_MESSAGE);
        }
}
    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        // TODO add your handling code here:
            int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                String r = JOptionPane.showInputDialog(this.getParent(), "Please Enter ADMISSION NO or PaySlip NO.");
            if(r==null){
            }
            else{
            if (r.equals("")) {
            } else {
                printRecord(r.toUpperCase(),r.toUpperCase());
            }
        }
    }//GEN-LAST:event_btnprintActionPerformed
public void printAdmissionForm(String admno){
    try {
//            java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
            stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
            String str = "SELECT ADMISSION_NO,ADM_RECEIPT_NO,STUDENT_NAME,STUDENT_DOB,AGE,ROLL_NO,CLASS,SECTION,CASTE,GENDER,PHOTO,FATHER_NAME,F_QUALIFICATION,F_CONTACT,F_COMPADD,MOTHER_NAME,M_QUALIFICATION,M_CONTACT,M_COMPADD,ADMISSION_DATE,RELIGION,BL_GROUP,ID_MARKS FROM NEWADMISSION WHERE ADMISSION_NO='" + admno + "'";
            rs = stmt.executeQuery(str);
            rs.last();
            String admno1=rs.getString(1);
            if (admno.equals(admno1)) {
                pradmf = new PrintAdmissionForm(AdmissionOpen.admop,true);
                String slno1 = rs.getString(2);
                String slsub=slno.substring(8, slno1.length());//MLC/ADM 001
                String stdname=rs.getString(3);
                String dob = String.valueOf(rs.getDate(4));
                String ddob1 = dob.substring(0, 4);
                String ddob2 = dob.substring(5, 7);
                String ddob3 = dob.substring(8, 10);
                String ddob4 = ddob3.concat("/").concat(ddob2).concat("/").concat(ddob1);
                String ddob5 = NewAdmPanel.date(ddob4);
                
                String age = rs.getString(5);
                String rollno = rs.getString(6);
                String class1 = rs.getString(7);
                String section = rs.getString(8);
                String caste = rs.getString(9);
                String gender = rs.getString(10);
                String photo = rs.getString(11);
                if(photo.equals("H:/NewAdmission/Admission/build/classes/SchoolProject/user.png")){
                    PrintAdmissionForm.lblphoto.setText("PHOTO");
                }
                else{
                    PrintAdmissionForm.lblphoto.setText("");
                java.awt.Toolkit kit=java.awt.Toolkit.getDefaultToolkit();
                java.awt.Image image=kit.getImage(photo);
                image=image.getScaledInstance(100, 120, java.awt.Image.SCALE_AREA_AVERAGING);
                PrintAdmissionForm.lblphoto.setIcon(new javax.swing.ImageIcon(image));
                }
                
                String fname = rs.getString(12);
                String fquali = rs.getString(13);
                String fcont = rs.getString(14);
                String fadd = rs.getString(15);
                
                String mname = rs.getString(16);
                String mquali = rs.getString(17);
                String mcont = rs.getString(18);
                String madd = rs.getString(19);
                
                
                String date = String.valueOf(rs.getDate(20));
                String d1 = date.substring(0, 4);
                String d2 = date.substring(5, 7);
                String d3 = date.substring(8, 10);
                String d4 = d3.concat("/").concat(d2).concat("/").concat(d1);
                String d5 = NewAdmPanel.date(d4);
                String reg = rs.getString(21);
                String blood = rs.getString(22);
                String idmark = rs.getString(23);
                PrintAdmissionForm.lblslno.setText(slsub);
                PrintAdmissionForm.lbladmno.setText(admno1);
                PrintAdmissionForm.lblstdname.setText(stdname);
                PrintAdmissionForm.lbldob.setText(ddob5);
                PrintAdmissionForm.lblroll.setText(rollno);
                PrintAdmissionForm.lblclass.setText(class1);
                PrintAdmissionForm.lblsection.setText(section);
                PrintAdmissionForm.lblmark.setText(idmark);
                PrintAdmissionForm.lblreg.setText(reg);
                PrintAdmissionForm.lblcaste.setText(caste);
                PrintAdmissionForm.lblgen.setText(gender);
                PrintAdmissionForm.lblage.setText(age);
                PrintAdmissionForm.lblblood.setText(blood);
                PrintAdmissionForm.lbladmdate.setText(d5);
                PrintAdmissionForm.lblfname.setText(fname);
                PrintAdmissionForm.lblfquali.setText(fquali);
                PrintAdmissionForm.lblfcont.setText(fcont);
                PrintAdmissionForm.txtadd1.setText(fadd);
                PrintAdmissionForm.lblmname.setText(mname);
                PrintAdmissionForm.lblmquali.setText(mquali);
                PrintAdmissionForm.lblmcont.setText(mcont);
                PrintAdmissionForm.txtadd2.setText(madd);
                pradmf.setBounds(300, 20, 620, 600);
                pradmf.setVisible(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this.getParent(), "Please Enter a Valid ADMISSION NO.", "Error", JOptionPane.ERROR_MESSAGE);
        }
}
    private void jcbclassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbclassActionPerformed
        // TODO add your handling code here:
        classfalse=true;
        if(jcbclass.getSelectedIndex()==0){
            classfalse=false;
        }
        else{
            String class2=String.valueOf(jcbclass.getSelectedItem());
            try{
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str1="SELECT * FROM FEE_DETAILS WHERE CLASS='"+class2+"'";
                rs=stmt.executeQuery(str1);
                rs.last();
                String roll=rs.getString(1);
                classfalse=true;
                
                
            }
            catch (SQLException ex) {
                  classfalse=false;
            }
//        boolean flag=false;
//        if (jcbclass.getSelectedItem().equals("Select")) {
//            jList1.setEnabled(false);
//            jList2.setEnabled(false);
//            rbisc.setEnabled(false);
//            rbarts.setEnabled(false);
//            rbcom.setEnabled(false);
//            rbmath.setEnabled(false);
//            rbbio.setEnabled(false);
//
//        } else if (jcbclass.getSelectedIndex() < 15) {
//            if (rbisc.isEnabled() || rbarts.isEnabled() || rbcom.isEnabled() || rbmath.isEnabled() || rbbio.isEnabled()) {
//                jList1.setListData(obj);
//            }
//            jList1.setEnabled(true);
//            jList2.setEnabled(true);
//            rbisc.setEnabled(false);
//            rbarts.setEnabled(false);
//            rbcom.setEnabled(false);
//            rbmath.setEnabled(false);
//            rbbio.setEnabled(false);
//            jList2.setListData(obj4);
//
//        } else {
//
//            jList1.setEnabled(true);
//            jList2.setEnabled(true);
//            rbisc.setSelected(true);
//            rbisc.setEnabled(true);
//            rbarts.setEnabled(true);
//            rbcom.setEnabled(true);
//            rbmath.setEnabled(true);
//            rbbio.setEnabled(true);
//            jList1.setListData(obj);
//            jList2.setListData(obj1);
//        }
        if(jcbclass.getSelectedIndex()==0){
//            txtadmfee.setText("");
              txtroll.setText("");
        }
        else{
            String class1=String.valueOf(jcbclass.getSelectedItem());
//            try {
////                java.sql.Connection con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMIT", "123");
//                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
//                String str1="SELECT ADM_FEE FROM FEE_DETAILS WHERE CLASS='"+class1+"'";
//                rs=stmt.executeQuery(str1);
//                while(rs.next()){
//                    txtadmfee.setText(rs.getString(1));
//                    flag=true;
//                    break;
//                }
//            }
//            catch (SQLException ex) {
//                  txtadmfee.setText("");
//                //JOptionPane.showMessageDialog(rootPane, ex);
//            }
            try{
                stmt = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_UPDATABLE);
                String str="SELECT MAX(ROLL_NO) FROM NEWADMISSION WHERE CLASS='"+class1+"'";
                rs=stmt.executeQuery(str);
                rs.next();
                int rowCount = rs.getInt(1);
                ++rowCount;
                txtroll.setText(String.valueOf(rowCount));
            }
            catch (SQLException ex) {
                  txtroll.setText("1");
//                JOptionPane.showMessageDialog(this, ex);
            }
            flag2=false;
//            if(flag==false){
//                txtadmfee.setText("");
//            }
//        }
        }
        }
    }//GEN-LAST:event_jcbclassActionPerformed
public static String dateFormat(String slm) {
        String st = slm;//"12/03/2014"
        String d1="";
        String d2="";
        String d3="";
        if(st.length()==3){
            d2=st;
        }
        else if(st.length()==11){
         d1 = st.substring(0, 2);//01-jan-1990
         d2 = st.substring(3, 6);
         d3 = st.substring(7, 11);
        }
        switch (d2) {
            case "Jan":
                d2 = "01";
                break;
            case "Feb":
                d2 = "02";
                break;
            case "Mar":
                d2 = "03";
                break;
            case "Apr":
                d2 = "04";
                break;
            case "May":
                d2 = "05";
                break;
            case "Jun":
                d2 = "06";
                break;
            case "Jul":
                d2 = "07";
                break;
            case "Aug":
                d2 = "08";
                break;
            case "Sep":
                d2 = "09";
                break;
            case "Oct":
                d2 = "10";
                break;
            case "Nov":
                d2 = "11";
                break;
            default:
                d2 = "12";
                break;
        }
        String d4 = d1.concat("-").concat(d2).concat("-").concat(d3);
        if(st.length()==3){
            return d2;
        }
        else{
        return d4;
        }
    } public static class ImageFilters extends javax.swing.filechooser.FileFilter{

        @Override
        public boolean accept(java.io.File f) {
          if(f.isDirectory()) {return true;}
          String name=f.getName();
          if(name.matches("(.*((.jpg)|(.JPG)|(.gif)|(.GIF)|(.png)|(.PNG)))")){ return true;}
          else return false;
          
        }

        @Override
        public String getDescription() {
           return "Image files(*.jpg,*.gif,*.png)";
        }
            
        }
    public static int dateSubstraction(String d,String m,String y){
    if(d.equals("")||m.equals("")||y.equals("")){
    
    }
    else{
        int dd=0,mm=0,yy=0;
    String strdate1 = NewJPanel.lbldate.getText().substring(5, 15);
    String strdate3=d.concat("-").concat(m).concat("-").concat(y);
    String strdate2=dateFormat(strdate3);
        //01-02-2016
       // 06-11-1991
        int dd1=Integer.parseInt(strdate1.substring(0,2));
        int mm1=Integer.parseInt(strdate1.substring(3,5));
        int yy1=Integer.parseInt(strdate1.substring(6,10));
        int dd2=Integer.parseInt(strdate2.substring(0,2));
        int mm2=Integer.parseInt(strdate2.substring(3,5));
        int yy2=Integer.parseInt(strdate2.substring(6,10));      
if(dd1>=dd2){
   dd=dd1-dd2;
}
else{
    switch(mm1){
        case 1:
           dd1=dd1+31;
           dd=dd1-dd2;
           mm1--;
            break;
        case 2:
            if(yy1%4==0&&yy1%100!=0||yy1%400==0){
                dd1=dd1+29;
                dd=dd1-dd2;
                mm1--;
                break;
            }
            else{
                dd1=dd1+28;
                dd=dd1-dd2;
                mm1--;
                break;
            }
        case 3:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;
        case 4:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;
        case 5:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;
        case 6:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;
        case 7:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;    
         case 8:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;   
         case 9:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 10:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 11:
           dd1=dd1+30;
           dd=dd1-dd2;
            mm1--;
            break;  
         case 12:
           dd1=dd1+31;
           dd=dd1-dd2;
            mm1--;
            break;  
    }
}
if(mm1>=mm2){
    mm=mm1-mm2;
}
else{
    mm1=mm1+12;
    mm=mm1-mm2;
    yy1--;
}
yy=yy1-yy2;
year=yy;
        }
    return(year);
}
    private void dcb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dcb1ActionPerformed
        // TODO add your handling code here:
        if(dcb1.getSelectedIndex()==0){
            year=0;
            dd="";
            txtage.setText("");
        }
        else{
            dd=String.valueOf(dcb1.getSelectedItem());
           int year1= dateSubstraction(dd,mm,yy);
           if(year1==0)
               txtage.setText("");
           else
            txtage.setText(String.valueOf(year1));
        }
    }//GEN-LAST:event_dcb1ActionPerformed

    private void mcb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mcb2ActionPerformed
        // TODO add your handling code here:
        if(mcb2.getSelectedIndex()==0){
            year=0;
            mm="";
            txtage.setText("");
        }
        else{
            mm=String.valueOf(mcb2.getSelectedItem());
            int year1=dateSubstraction(dd,mm,yy);
            if(year1==0)
               txtage.setText("");
           else
            txtage.setText(String.valueOf(year1));
        }
    }//GEN-LAST:event_mcb2ActionPerformed

    private void ycb3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ycb3ActionPerformed
        // TODO add your handling code here:
        if(ycb3.getSelectedIndex()==0){
            year=0;
            yy="";
            txtage.setText("");
        }
        else{
            yy=String.valueOf(ycb3.getSelectedItem());
         int year1=dateSubstraction(dd,mm,yy);
            if(year1==0)
               txtage.setText("");
           else
            txtage.setText(String.valueOf(year1));
        }
    }//GEN-LAST:event_ycb3ActionPerformed

    private void txtfcompadd1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtfcompadd1FocusLost
        // TODO add your handling code here:
        if(txtfcompadd1.getText().length()>100){
            txtfcompadd1.setText("");
        }
    }//GEN-LAST:event_txtfcompadd1FocusLost

    private void txtmcompadd1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmcompadd1FocusLost
        // TODO add your handling code here:
        if(txtmcompadd1.getText().length()>100){
            txtmcompadd1.setText("");
        }
    }//GEN-LAST:event_txtmcompadd1FocusLost

    private void txtcasteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcasteActionPerformed
        // TODO add your handling code here:
        jcbgen.grabFocus();
    }//GEN-LAST:event_txtcasteActionPerformed

    private void txtcasteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcasteFocusLost
        // TODO add your handling code here:
//        if (txtcaste.getText().matches("[a-zA-Z- ]*")) {
//        } else {
//            txtcaste.setText("");
//        }
        if (txtcaste.getText().length() > 30) {
            txtcaste.setText("");
        }
    }//GEN-LAST:event_txtcasteFocusLost

    private void txtmarkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmarkActionPerformed
        // TODO add your handling code here:
        jcbregl.grabFocus();
    }//GEN-LAST:event_txtmarkActionPerformed

    private void txtmarkFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmarkFocusLost
        // TODO add your handling code here:
        if (txtmark.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtmark.setText("");
        }
        if (txtmark.getText().length() > 30) {
            txtmark.setText("");
        }
    }//GEN-LAST:event_txtmarkFocusLost

    private void txtstdaddFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtstdaddFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstdaddFocusLost

    private void txtcont1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcont1ActionPerformed
        // TODO add your handling code here:
        txtfdesig.grabFocus();
    }//GEN-LAST:event_txtcont1ActionPerformed

    private void txtcontActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcontActionPerformed
        // TODO add your handling code here:
        txtmdesig.grabFocus();
    }//GEN-LAST:event_txtcontActionPerformed

    private void lblimageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblimageMouseClicked
        // TODO add your handling code here:
        NewJDialog njd=new NewJDialog(AdmissionOpen.admop,true);
        njd.jFileChooser1.setFileFilter(new ImageFilters());
        njd.setBounds(400, 20, 590, 490);
        njd.setVisible(true);
        if(NewJDialog.chk==1){
            java.awt.Toolkit kit=java.awt.Toolkit.getDefaultToolkit();
            java.awt.Image image=kit.getImage(NewJDialog.image.toString());
            image=image.getScaledInstance(130, 150, java.awt.Image.SCALE_AREA_AVERAGING);
            lblimage.setIcon(new javax.swing.ImageIcon(image));
        String ph=NewJDialog.image.toString();
        if(ph.startsWith("file:/")){
            String substring = ph.substring(6, ph.length());
            photo1=substring;
        }
        else{
        photo1=NewJDialog.image.toString().replace('\\', '/');
        }
        }
        
//        javax.swing.JFileChooser jc=new javax.swing.JFileChooser();
//        jc.setFileFilter(new ImageFilters());
//        jc.showOpenDialog(this);
    }//GEN-LAST:event_lblimageMouseClicked

    private void txtsectionFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtsectionFocusLost
        // TODO add your handling code here:
        if(txtsection.getText().length()>1){
            txtsection.setText("");
        }
        if (txtsection.getText().matches("[a-zA-Z- ]*")) {
        } else {
            txtsection.setText("");
        }
    }//GEN-LAST:event_txtsectionFocusLost

    private void txtsectionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsectionKeyReleased
        // TODO add your handling code here:
        txtsection.setText(txtsection.getText().toUpperCase());
    }//GEN-LAST:event_txtsectionKeyReleased

    private void btnprint1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprint1ActionPerformed
        // TODO add your handling code here:
//        int yearno=Integer.parseInt(NewJPanel.year);
//                int yearno1=yearno+1;
//                String setyear=String.valueOf(yearno).concat("-").concat(String.valueOf(yearno1));
                String r = JOptionPane.showInputDialog(this.getParent(), "Please Enter ADMISSION No.");
            if(r==null){
            }
            else{
            if (r.equals("")) {
            } else {
                printAdmissionForm(r);
                IdentityCard idcard=new IdentityCard(AdmissionOpen.admop,true,r);
                
            }
        }
    }//GEN-LAST:event_btnprint1ActionPerformed

    private void txtsectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsectionActionPerformed
        // TODO add your handling code here:
        txtblood.grabFocus();
    }//GEN-LAST:event_txtsectionActionPerformed
    public static AdmPreviousStudy prvdp;
    public static AdmissionFee admf;
    public static PrintDialog prd;
    public static PrintAdmissionForm pradmf;
    public static int num = 0,num2 = 0;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton btnclear;
    public static javax.swing.JButton btnexit;
    public static javax.swing.JButton btnprint;
    public static javax.swing.JButton btnprint1;
    public static javax.swing.JButton btnsave;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    public static javax.swing.JComboBox dcb1;
    public static javax.swing.JLabel head1;
    private javax.swing.JLabel head2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    public static javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    public static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel37;
    public static javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public static javax.swing.JList jList1;
    public static javax.swing.JList jList2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private static javax.swing.JComboBox jcbclass;
    private javax.swing.JComboBox jcbgen;
    private javax.swing.JComboBox jcbregl;
    public static javax.swing.JLabel lblimage;
    private javax.swing.JLabel lblsize;
    public static javax.swing.JComboBox mcb2;
    public static javax.swing.JRadioButton rbarts;
    public static javax.swing.JRadioButton rbbio;
    public static javax.swing.JRadioButton rbcom;
    public static javax.swing.JRadioButton rbisc;
    public static javax.swing.JRadioButton rbmath;
    private static javax.swing.JTextField txtadmfee;
    public static javax.swing.JTextField txtadno;
    public static javax.swing.JTextField txtage;
    public static javax.swing.JComboBox txtblood;
    public static javax.swing.JTextField txtcaste;
    private javax.swing.JTextField txtcont;
    private javax.swing.JTextField txtcont1;
    private javax.swing.JTextArea txtfcompadd1;
    public static javax.swing.JTextField txtfcompname;
    public static javax.swing.JTextField txtfdesig;
    public static javax.swing.JTextField txtfname;
    public static javax.swing.JComboBox txtfoccup;
    public static javax.swing.JComboBox txtfquali;
    public static javax.swing.JTextField txtmark;
    private javax.swing.JTextArea txtmcompadd1;
    public static javax.swing.JTextField txtmcompname;
    public static javax.swing.JTextField txtmdesig;
    public static javax.swing.JTextField txtmname;
    public static javax.swing.JComboBox txtmoccup;
    public static javax.swing.JComboBox txtmquali;
    public static javax.swing.JTextField txtname;
    public static javax.swing.JTextField txtroll;
    public static javax.swing.JTextField txtsection;
    private javax.swing.JTextArea txtstdadd;
    public static javax.swing.JComboBox ycb3;
    // End of variables declaration//GEN-END:variables
}
