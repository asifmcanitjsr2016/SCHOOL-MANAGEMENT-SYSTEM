/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;



public class ExeQuery {
    Connection con;
    Statement stmt;
    ResultSet rs;
   
    
    public ExeQuery () {
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "AMAN", "123");
            stmt=  con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        }catch(ClassNotFoundException| SQLException e){System.out.print("error");
        }
    }
    
    public int countstaff()
    {
        int rows= 0;
        try {
            rs=  stmt.executeQuery("select * from Staff where srno is not null");
            rs.last();
            rows= rs.getRow();
            rs.close();
           } catch (SQLException ex) {}
          
        return rows;
    }
    
    public String[] getStaffDetails()
    {
        int rows = countstaff();
        String data[]= new String[rows];
        int i= 0;
        try{
            rs= stmt.executeQuery("select * from staff where srno is not null");
            while(rs.next())
            {
                data[i] = ""+rs.getString("srno")+"\t"+rs.getString("sname")+"\t"+rs.getString("stype")+"\t"+rs.getString("mobile");
                i++;
            }
        }catch(SQLException ex){}
        return data;
    }
    
    public boolean confirmTodayAttn(String today)
    {
        String date ="";
        boolean flag = false;// false = no attendence for this date 
        try{
            rs = stmt.executeQuery("select attn_date from attendence where attn_date ='"+today+"'");
            rs.first();
            date = rs.getString("attn_date");
            if(date.equals(today)) flag = true;
        }catch(SQLException ex){}
        return  flag;
    }
    
    /**
     * this method takes 
     */
    public void makeAttn(String date, String absStaffList)
    {
        try{
            stmt.executeQuery("insert into attendence values('"+date+"','"+absStaffList+"')");
        } catch(SQLException e){}   
        
    }
    
  
   
    
    public void disconnect()
    {
        try{
            rs.close();
        stmt.close(); con.close();
        }catch(SQLException e){}
        
    }
    
   public String getYears()
   {
       String yrs ="";
       try{
       rs = stmt.executeQuery("select attn_date from attendence");
       while(rs.next())
       {
           yrs = yrs+rs.getString("attn_date").substring(7)+";";
       }
       }catch(SQLException ex){}
       return  yrs;
   }

  public String distinctElement( String arr)
   {
       String yrs[] = arr.split(";");
       String yr ="",temp="";
       for(int i =0;i<yrs.length;i++){
            temp = yrs[i];
           for(int j =0;j<yrs.length;j++)
               if(yrs[j].equals(temp))yrs[j]="";
           if(!temp.equals(""))
           yr = yr +temp+";";        
       }
            return yr;
         }
  
  
  public String getMonths(String yr)
  {
      String mnths ="";
      try{
      rs = stmt.executeQuery("select attn_date from attendence where attn_date like '%"+yr+"'");
      while(rs.next())
          mnths = mnths+ rs.getString("attn_date").substring(3, 6)+";";
      }catch(SQLException ex){ex.printStackTrace();}
      return mnths;//
  }

  public String getDates(String mmmYYYY){
      String dd = "";
      try{
         rs = stmt.executeQuery("select attn_date from attendence where attn_date like '%"+mmmYYYY+"'");
         while(rs.next())
             dd = dd+rs.getString("attn_date").substring(0, 2)+";";
      }catch(SQLException ex){ex.printStackTrace();}
      return  dd;
  }
  
  public String getStaffAttendenceForMonth(String MmYY)
  {
   return null;
  }
          // 

   
  public void commit()
  {
        try {
            con.commit();
        } catch (SQLException ex) {
            Logger.getLogger(ExeQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
  }
    public static void main(String[] args) {
        ExeQuery eq= new ExeQuery();
      /* int r =  eq.countstaff();
        System.out.println("total no. of rows: "+r);
        String data[]= eq.getStaffDetails();
        for(int i= 0 ; i<data.length;i++)
            System.out.println(data[i]);
        eq.disconnect();
        */
       // eq.addToday("08/Jun/2016");
     // String n=  eq.getMonths("2016");System.out.println(n);
    String n=   eq.getDates("Jun/2016");// eq.distinctElement( eq.getMonths("2016"));
    System.out.println(n);
     eq.disconnect();
       
        
    }
}
