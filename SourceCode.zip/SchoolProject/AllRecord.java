/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SchoolProject;

import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author ASIF
 */

public class AllRecord extends JPanel{
    private JScrollPane jScrollPane1;
    AllRecord() {
        String str="";
            setLayout(new BorderLayout());
            setOpaque(true);
            setBackground(new java.awt.Color(102, 0, 102));
            if(AdmissionOpen.count25==1){
            str="SELECT * FROM VEHICLES_DETAILS";
            AllRecordPanel.vehicleRecord(str);
            }
            else if(AdmissionOpen.count1==1){
            str = "SELECT * FROM NEWADMISSION ORDER BY ADMISSION_NO ASC";
            AllRecordPanel.admrecord(str);
            }
            else if(AdmissionOpen.count27==1){
            str = "SELECT * FROM NOC_RECORD";
            AllRecordPanel.nocRecord(str);
            } 
            jScrollPane1 = new JScrollPane(AllRecordPanel.jTable1);
            add(jScrollPane1);
         if (AllRecordPanel.flag==false) {
                JOptionPane.showMessageDialog(this.getParent(), "No Reccords Found.", "All Records", JOptionPane.ERROR_MESSAGE);
        }
    }
}
