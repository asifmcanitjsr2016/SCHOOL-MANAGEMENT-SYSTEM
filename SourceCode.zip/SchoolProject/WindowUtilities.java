package SchoolProject;

import javax.swing.UIManager;

/**
 * A few utilities that simplify using windows in Swing. 1998-99 Marty Hall,
 * http://www.apl.jhu.edu/~hall/java/
 */
public class WindowUtilities {

    /**
     * Tell system to use native look and feel, as in previous releases. Metal
     * (Java) LAF is the default otherwise.
     */
    public static void setNativeLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("Error setting native LAF: " + e);
        }
    }
    /**
     * A simplified way to see a JPanel or other Container. Pops up a JFrame
     * with specified Container as the content pane.
     */
}
